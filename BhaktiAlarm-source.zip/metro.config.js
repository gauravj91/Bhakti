const path = require('path');
const { getDefaultConfig } = require('expo/metro-config');
const config = getDefaultConfig(__dirname);
// Web preview only: swap Android-only packages for stubs. Android builds are unaffected.
const webStubs = { 'react-native-share': path.resolve(__dirname, 'web-stubs/react-native-share.js') };
const upstream = config.resolver.resolveRequest;
config.resolver.resolveRequest = (ctx, name, platform) => {
  if (platform === 'web' && webStubs[name]) return { type: 'sourceFile', filePath: webStubs[name] };
  return upstream ? upstream(ctx, name, platform) : ctx.resolveRequest(ctx, name, platform);
};
module.exports = config;
