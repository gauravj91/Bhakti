#!/usr/bin/env node
/**
 * Shrinks big uploaded images before they are bundled (run by sync-assets.js).
 * Any image over 350 KB under assets/deities, assets/templates or assets/temples is
 * resized to at most 1600 px on its long side and saved as a quality-82 JPEG
 * (a 3 MB PNG becomes ~250-400 KB with no visible difference on a phone).
 * Generated placeholders (scripts/placeholders.json) are left untouched.
 */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
let sharp;
try { sharp = require('sharp'); } catch (e) { console.log('optimize-images: sharp not installed, skipping'); process.exit(0); }

const A = path.join(__dirname, '..', 'assets');
let PH = {};
try { PH = require('./placeholders.json'); } catch (e) {}
const IMG = /\.(jpe?g|png|webp)$/i;
const LIMIT = 350 * 1024, MAX = 1600;

const walk = (d) => (fs.existsSync(d) ? fs.readdirSync(d).flatMap((f) => {
  const p = path.join(d, f);
  return fs.statSync(p).isDirectory() ? walk(p) : [p];
}) : []);

(async () => {
  let before = 0, after = 0, n = 0;
  for (const root of ['deities', 'templates', 'temples']) {
    for (const p of walk(path.join(A, root)).filter((f) => IMG.test(f))) {
      const buf = fs.readFileSync(p);
      if (buf.length <= LIMIT) continue;
      if (PH[crypto.createHash('md5').update(buf).digest('hex')]) continue;
      const out = await sharp(buf).rotate()
        .resize({ width: MAX, height: MAX, fit: 'inside', withoutEnlargement: true })
        .flatten({ background: '#FFF8E7' })
        .jpeg({ quality: 82, mozjpeg: true }).toBuffer();
      if (out.length >= buf.length) continue;
      const dest = p.replace(/\.[^.]+$/, '.jpg');
      fs.writeFileSync(dest, out);
      if (dest !== p) fs.unlinkSync(p);
      before += buf.length; after += out.length; n++;
      console.log(`  ${path.relative(A, p)}: ${(buf.length / 1e6).toFixed(1)} MB -> ${(out.length / 1e6).toFixed(2)} MB`);
    }
  }
  console.log(`optimize-images: ${n} files, ${(before / 1e6).toFixed(1)} MB -> ${(after / 1e6).toFixed(1)} MB`);
})().catch((e) => { console.error('optimize-images failed (continuing):', e.message); process.exit(0); });
