import { registerRootComponent } from 'expo';
import { Platform } from 'react-native';
import App from './src/App';

if (Platform.OS === 'android') {
  // Home-screen Panchang widget (runs headless, even when the app is closed).
  const { registerWidgetTaskHandler } = require('react-native-android-widget');
  const { widgetTaskHandler } = require('./src/widget/handler');
  registerWidgetTaskHandler(widgetTaskHandler);
}
registerRootComponent(App);
