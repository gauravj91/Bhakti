// Unity LevelPlay needs these Play Services libraries in the app module (see unity-levelplay-mediation README).
const { withAppBuildGradle } = require('expo/config-plugins');

const DEPS = `
// --- LevelPlay (plugins/withLevelPlay.js) ---
dependencies {
    implementation 'com.google.android.gms:play-services-appset:16.0.2'
    implementation 'com.google.android.gms:play-services-ads-identifier:18.0.1'
    implementation 'com.google.android.gms:play-services-basement:18.3.0'
}
`;

module.exports = (config) =>
  withAppBuildGradle(config, (c) => {
    if (!c.modResults.contents.includes('withLevelPlay')) c.modResults.contents += DEPS;
    return c;
  });
