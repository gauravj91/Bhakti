// Gives Gradle enough heap to package the release AAB (bundletool ran out of heap with the larger v1.1 assets).
const { withGradleProperties } = require('expo/config-plugins');

const PROPS = {
  'org.gradle.jvmargs': '-Xmx6g -XX:MaxMetaspaceSize=1g -XX:+HeapDumpOnOutOfMemoryError -Dfile.encoding=UTF-8',
};

module.exports = (config) =>
  withGradleProperties(config, (c) => {
    for (const [key, value] of Object.entries(PROPS)) {
      const i = c.modResults.findIndex((p) => p.type === 'property' && p.key === key);
      if (i >= 0) c.modResults[i].value = value;
      else c.modResults.push({ type: 'property', key, value });
    }
    return c;
  });
