// Signs release builds (APK + AAB) with the upload key when the CI provides it via env vars.
// Without the env vars, builds stay signed with the debug key (fine for sideload testing).
const { withAppBuildGradle } = require('expo/config-plugins');

const BLOCK = `
// --- Bhakti Alarm release signing (plugins/withReleaseSigning.js) ---
def bhaktiKs = System.getenv('BHAKTI_KEYSTORE_PATH')
if (bhaktiKs && file(bhaktiKs).exists()) {
    android.signingConfigs.create('upload') {
        storeFile file(bhaktiKs)
        storeType 'pkcs12'
        storePassword System.getenv('BHAKTI_KEYSTORE_PASSWORD')
        keyAlias System.getenv('BHAKTI_KEY_ALIAS') ?: 'upload'
        keyPassword System.getenv('BHAKTI_KEYSTORE_PASSWORD')
    }
    android.buildTypes.release.signingConfig = android.signingConfigs.upload
}
def bhaktiVc = System.getenv('BHAKTI_VERSION_CODE')
if (bhaktiVc) { android.defaultConfig.versionCode = bhaktiVc.toInteger() }
`;

module.exports = (config) =>
  withAppBuildGradle(config, (c) => {
    if (!c.modResults.contents.includes('withReleaseSigning')) c.modResults.contents += BLOCK;
    return c;
  });
