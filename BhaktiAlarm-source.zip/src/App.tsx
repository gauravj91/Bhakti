import React, { useEffect, useState, useCallback } from 'react';
import { AppState, View, Text } from 'react-native';
import { NavigationContainer, DefaultTheme, createNavigationContainerRef } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import * as SplashScreen from 'expo-splash-screen';
import * as Notifications from 'expo-notifications';
// Import single weights only: the package index bundles all 27 font files (~5 MB).
import { useFonts } from 'expo-font';
import { NotoSans_400Regular } from '@expo-google-fonts/noto-sans/400Regular';
import { NotoSans_500Medium } from '@expo-google-fonts/noto-sans/500Medium';
import { NotoSans_700Bold } from '@expo-google-fonts/noto-sans/700Bold';
import { NotoSansDevanagari_400Regular } from '@expo-google-fonts/noto-sans-devanagari/400Regular';
import { NotoSansDevanagari_700Bold } from '@expo-google-fonts/noto-sans-devanagari/700Bold';

import './lib/textScale';
import { setTextScale } from './lib/textScale';
import './i18n/all';
import { setLanguage } from './i18n';
import { PrefsProvider, usePrefs } from './lib/prefs';
import { initAds } from './lib/ads';
import { getRinging, Ringing, addRingingListener } from './lib/alarms';
import { s } from './i18n';
import { colors, fonts } from './theme';
import OnboardingScreen from './screens/OnboardingScreen';
import HomeScreen from './screens/HomeScreen';
import RashifalScreen from './screens/RashifalScreen';
import KundaliScreen from './screens/KundaliScreen';
import MulankScreen from './screens/MulankScreen';
import { mulankTitle } from './content/mulank';
import WallpaperScreen from './screens/WallpaperScreen';
import RadioScreen from './screens/RadioScreen';
import { x } from './i18n/extra';
import { previewParam } from './lib/webPreview';
import AlarmListScreen from './screens/AlarmListScreen';
import AlarmEditScreen from './screens/AlarmEditScreen';
import RingtonePickerScreen from './screens/RingtonePickerScreen';
import StudioScreen from './screens/StudioScreen';
import StudioEditorScreen from './screens/StudioEditorScreen';
import VideoMakerScreen from './screens/VideoMakerScreen';
import CalendarScreen from './screens/CalendarScreen';
import TempleListScreen from './screens/TempleListScreen';
import DarshanScreen from './screens/DarshanScreen';
import MoreScreen from './screens/MoreScreen';
import WakeScreen from './screens/WakeScreen';
import JaapScreen from './screens/JaapScreen';
import LyricsListScreen from './screens/LyricsListScreen';
import LyricsReaderScreen from './screens/LyricsReaderScreen';
import LiveDarshanScreen from './screens/LiveDarshanScreen';
import VratGuideScreen from './screens/VratGuideScreen';
import TodayDarshanScreen from './screens/TodayDarshanScreen';
import FamilyScreen, { greetingFor } from './screens/FamilyScreen';
import { FESTIVALS } from './content/catalog';
import { vratFor } from './content/devotion';
import { refreshDailyDarshan } from './lib/dailyDarshan';
import { refreshTithiReminders } from './lib/tithiReminders';
import { updatePanchangWidget } from './widget/update';

let tithiRefreshedOn = '';
function dailyBackgroundRefresh(p: any, force = false) {
  const today = new Date().toDateString();
  updatePanchangWidget().catch(() => {});
  if (!force && tithiRefreshedOn === today) return;
  tithiRefreshedOn = today;
  refreshTithiReminders(p).catch(() => {});
}
import { ensureNotificationPermission } from './lib/reminders';
import { registerForPush, pushData, PUSH_ROUTES } from './lib/push';

SplashScreen.preventAutoHideAsync().catch(() => {});
const navRef = createNavigationContainerRef<any>();
const Tab = createBottomTabNavigator();
const Stack = createNativeStackNavigator();

const stackOpts = {
  headerStyle: { backgroundColor: colors.cream }, headerTintColor: colors.maroon, headerShadowVisible: false,
  headerTitleStyle: { fontFamily: fonts.bold, fontSize: 20 }, contentStyle: { backgroundColor: colors.cream },
};

function HomeStack() {
  return (
    <Stack.Navigator screenOptions={stackOpts} initialRouteName={(previewParam('screen') as any) || 'HomeMain'}>
      <Stack.Screen name="HomeMain" component={HomeScreen} options={{ headerShown: false }} />
      <Stack.Screen name="AlarmList" component={AlarmListScreen} options={{ title: '' }} />
      <Stack.Screen name="LiveDarshan" component={LiveDarshanScreen} options={{ title: s().live.title }} />
      <Stack.Screen name="Rashifal" component={RashifalScreen} options={{ title: x().rashifal.title }} />
      <Stack.Screen name="Kundali" component={KundaliScreen} options={{ title: x().kundali.title }} />
      <Stack.Screen name="Mulank" component={MulankScreen} options={{ title: mulankTitle() }} />
      <Stack.Screen name="Wallpaper" component={WallpaperScreen} options={{ title: x().wallpaper.title }} />
      <Stack.Screen name="Radio" component={RadioScreen} options={{ title: x().radio.title }} />
      <Stack.Screen name="AlarmEdit" component={AlarmEditScreen} options={{ title: '' }} />
      <Stack.Screen name="RingtonePicker" component={RingtonePickerScreen} options={{ title: '' }} />
    </Stack.Navigator>
  );
}
function CreateStack() {
  return (
    <Stack.Navigator screenOptions={stackOpts}>
      <Stack.Screen name="Studio" component={StudioScreen} options={{ headerShown: false }} />
      <Stack.Screen name="StudioEditor" component={StudioEditorScreen} options={{ title: '' }} />
      <Stack.Screen name="VideoMaker" component={VideoMakerScreen} options={{ title: s().video.title }} />
    </Stack.Navigator>
  );
}
function TempleStack() {
  return (
    <Stack.Navigator screenOptions={stackOpts}>
      <Stack.Screen name="TempleList" component={TempleListScreen} options={{ headerShown: false }} />
      <Stack.Screen name="Darshan" component={DarshanScreen} options={{ headerShown: false, animation: 'fade' }} />
      <Stack.Screen name="LiveDarshan" component={LiveDarshanScreen} options={{ title: s().live.title }} />
      <Stack.Screen name="Jaap" component={JaapScreen} options={{ title: s().jaap.title, headerStyle: { backgroundColor: '#3A0A00' }, headerTintColor: '#FFE2B8' }} />
      <Stack.Screen name="LyricsList" component={LyricsListScreen} options={{ title: '' }} />
      <Stack.Screen name="LyricsReader" component={LyricsReaderScreen} options={{ title: '' }} />
      <Stack.Screen name="Wallpaper" component={WallpaperScreen} options={{ title: x().wallpaper.title }} />
      <Stack.Screen name="Radio" component={RadioScreen} options={{ title: x().radio.title }} />
      <Stack.Screen name="TodayDarshan" component={TodayDarshanScreen} options={{ title: '' }} />
    </Stack.Navigator>
  );
}

const ICONS: Record<string, string> = { Home: '🏠', Create: '🎨', Calendar: '📅', Temple: '🛕', More: '☰' };

function CalendarStack() {
  return (
    <Stack.Navigator screenOptions={stackOpts}>
      <Stack.Screen name="CalendarHome" component={CalendarScreen} options={{ headerShown: false }} />
      <Stack.Screen name="VratGuide" component={VratGuideScreen} options={{ title: '' }} />
      <Stack.Screen name="TodayDarshan" component={TodayDarshanScreen} options={{ title: '' }} />
    </Stack.Navigator>
  );
}
function MoreStack() {
  return (
    <Stack.Navigator screenOptions={stackOpts}>
      <Stack.Screen name="MoreHome" component={MoreScreen} options={{ headerShown: false }} />
      <Stack.Screen name="Family" component={FamilyScreen} options={{ title: '' }} />
      <Stack.Screen name="VratGuide" component={VratGuideScreen} options={{ title: '' }} />
    </Stack.Navigator>
  );
}

function Tabs() {
  const t = s().tabs;
  const labels: Record<string, string> = { Home: x().tabHome, Create: t.create, Calendar: t.calendar, Temple: t.temple, More: t.more };
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarActiveTintColor: colors.maroon,
        tabBarInactiveTintColor: colors.textSoft,
        tabBarStyle: { backgroundColor: '#FFFDF6', minHeight: 72, paddingTop: 6, borderTopColor: colors.border },
        tabBarLabel: ({ color }) => <Text style={{ fontFamily: fonts.bold, fontSize: 14, color }}>{labels[route.name]}</Text>,
        tabBarIcon: ({ focused }) => <Text style={{ fontSize: 26, opacity: focused ? 1 : 0.6 }}>{ICONS[route.name]}</Text>,
      })}>
      <Tab.Screen name="Home" component={HomeStack} />
      <Tab.Screen name="Create" component={CreateStack} />
      <Tab.Screen name="Calendar" component={CalendarStack} />
      <Tab.Screen name="Temple" component={TempleStack} />
      <Tab.Screen name="More" component={MoreStack} />
    </Tab.Navigator>
  );
}

function Root() {
  const { prefs, ready, update } = usePrefs();
  const prefsRef = React.useRef(prefs); prefsRef.current = prefs;
  // Language and text size apply app-wide; the key below re-renders everything when they change.
  setLanguage(prefs.language); setTextScale(prefs.textScale);
  const [ringing, setRinging] = useState<Ringing | null>(null);
  const check = useCallback(() => setRinging(getRinging()), []);

  useEffect(() => {
    check();
    const sub = AppState.addEventListener('change', (st) => {
      if (st !== 'active') return;
      check();
      // Keeps the 14-day "Aaj ka darshan" window rolling; cheap when nothing changed.
      const p = prefsRef.current;
      if (p.onboarded) { refreshDailyDarshan(p, p.dailyDarshanEnabled); dailyBackgroundRefresh(p); }
    });
    const ev = addRingingListener(check);
    return () => { sub.remove(); ev?.remove(); };
  }, []);

  useEffect(() => { if (ready && prefs.onboarded) initAds(); }, [ready, prefs.onboarded]);

  // Monthly tithi reminders + home-screen widget: whenever their inputs change (and once a day on open).
  useEffect(() => {
    if (!ready || !prefs.onboarded) return;
    const id = setTimeout(() => dailyBackgroundRefresh(prefsRef.current, true), 2500);
    return () => clearTimeout(id);
  }, [ready, prefs.onboarded, prefs.tithiReminders.join(','), prefs.tithiReminderTime, prefs.region, prefs.language]);

  // Daily darshan: ask for notifications once, gently, right after onboarding (or on the first open
  // after this update), then (re)schedule whenever the setting or anything in the text changes.
  useEffect(() => {
    if (!ready || !prefs.onboarded) return;
    let cancelled = false;
    (async () => {
      if (!prefsRef.current.notifPermAsked) {
        await update({ notifPermAsked: true });
        await new Promise((r) => setTimeout(r, 1500)); // let the home screen appear first
        if (cancelled) return;
        if (prefsRef.current.dailyDarshanEnabled) await ensureNotificationPermission().catch(() => false);
      }
      if (!cancelled) refreshDailyDarshan(prefsRef.current, prefsRef.current.dailyDarshanEnabled);
      if (!cancelled) registerForPush({ channel: x().push.channel }).catch(() => null);
    })();
    return () => { cancelled = true; };
  }, [ready, prefs.onboarded, prefs.dailyDarshanEnabled, prefs.dailyDarshanHour, prefs.language, prefs.region, prefs.familyDeity]);

  // Notification tap -> the right screen (greeting editor, vrat guide, or Aaj ka darshan).
  const handled = React.useRef<string | null>(null);
  const onResponse = useCallback((r: Notifications.NotificationResponse) => {
    const rid = `${r.notification.request.identifier}|${r.notification.date}`;
    if (handled.current === rid) return;
    const d: any = pushData(r);
    if (!navRef.isReady() || !prefsRef.current.onboarded) return;
    handled.current = rid;
    if (d?.screen && PUSH_ROUTES[d.screen]) {
      const p = PUSH_ROUTES[d.screen];
      navRef.navigate(p.tab as any, { screen: p.screen, initial: false } as any);
      return;
    }
    if (d?.dailyDarshan) {
      navRef.navigate('Temple', { screen: 'TodayDarshan', params: { date: d.date, deityId: d.deityId }, initial: false });
      return;
    }
    if (d?.familyId) {
      const f = prefsRef.current.family.find((x) => x.id === d.familyId);
      if (f) navRef.navigate('Create', { screen: 'StudioEditor', params: { festivalSlug: 'general', ...greetingFor(f) }, initial: false });
      return;
    }
    if (d?.vratFestivalId) {
      const fe = FESTIVALS.find((x) => x.id === d.vratFestivalId);
      const g = fe && vratFor(fe);
      if (g) navRef.navigate('Calendar', { screen: 'VratGuide', params: { key: g.key }, initial: false });
      return;
    }
    if (d?.greetingCategory) {
      navRef.navigate('Create', { screen: 'StudioEditor', params: { festivalSlug: d.greetingCategory, festivalName: d.name }, initial: false });
    }
  }, []);
  useEffect(() => {
    const sub = Notifications.addNotificationResponseReceivedListener(onResponse);
    return () => sub.remove();
  }, []);
  // Cold start from a notification tap: handle it once the navigator is ready.
  const onNavReady = useCallback(() => {
    try {
      const last = Notifications.getLastNotificationResponse();
      if (last) { onResponse(last); Notifications.clearLastNotificationResponse(); }
    } catch {}
  }, []);

  if (!ready) return null;
  return (
    <View style={{ flex: 1 }}>
      <NavigationContainer key={`${prefs.language}-${prefs.textScale}`} ref={navRef} onReady={onNavReady} theme={{ ...DefaultTheme, colors: { ...DefaultTheme.colors, background: colors.cream, primary: colors.saffron } }}>
        {prefs.onboarded ? <Tabs /> : <OnboardingScreen />}
      </NavigationContainer>
      {ringing ? <WakeScreen ringing={ringing} region={prefs.region} onDone={() => setRinging(null)} /> : null}
    </View>
  );
}

export default function App() {
  const [loaded] = useFonts({ NotoSans_400Regular, NotoSans_500Medium, NotoSans_700Bold, NotoSansDevanagari_400Regular, NotoSansDevanagari_700Bold });
  useEffect(() => { if (loaded) SplashScreen.hideAsync().catch(() => {}); }, [loaded]);
  if (!loaded) return null;
  return (
    <SafeAreaProvider>
      <StatusBar style="dark" />
      <PrefsProvider><Root /></PrefsProvider>
    </SafeAreaProvider>
  );
}
