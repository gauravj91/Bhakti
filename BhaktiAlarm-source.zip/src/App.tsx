import React, { useEffect, useState, useCallback } from 'react';
import { AppState, View, Text } from 'react-native';
import { NavigationContainer, DefaultTheme, createNavigationContainerRef } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import * as SplashScreen from 'expo-splash-screen';
import * as Notifications from 'expo-notifications';
import { useFonts, NotoSans_400Regular, NotoSans_500Medium, NotoSans_700Bold } from '@expo-google-fonts/noto-sans';
import { NotoSansDevanagari_400Regular, NotoSansDevanagari_700Bold } from '@expo-google-fonts/noto-sans-devanagari';

import { PrefsProvider, usePrefs } from './lib/prefs';
import { initAds } from './lib/ads';
import { getRinging, Ringing, addRingingListener } from './lib/alarms';
import { s } from './i18n';
import { colors, fonts } from './theme';
import OnboardingScreen from './screens/OnboardingScreen';
import AlarmListScreen from './screens/AlarmListScreen';
import AlarmEditScreen from './screens/AlarmEditScreen';
import RingtonePickerScreen from './screens/RingtonePickerScreen';
import StudioScreen from './screens/StudioScreen';
import StudioEditorScreen from './screens/StudioEditorScreen';
import CalendarScreen from './screens/CalendarScreen';
import TempleListScreen from './screens/TempleListScreen';
import DarshanScreen from './screens/DarshanScreen';
import MoreScreen from './screens/MoreScreen';
import WakeScreen from './screens/WakeScreen';

SplashScreen.preventAutoHideAsync().catch(() => {});
const navRef = createNavigationContainerRef<any>();
const Tab = createBottomTabNavigator();
const Stack = createNativeStackNavigator();

const stackOpts = {
  headerStyle: { backgroundColor: colors.cream }, headerTintColor: colors.maroon, headerShadowVisible: false,
  headerTitleStyle: { fontFamily: fonts.bold, fontSize: 20 }, contentStyle: { backgroundColor: colors.cream },
};

function AlarmStack() {
  return (
    <Stack.Navigator screenOptions={stackOpts}>
      <Stack.Screen name="AlarmList" component={AlarmListScreen} options={{ headerShown: false }} />
      <Stack.Screen name="AlarmEdit" component={AlarmEditScreen} options={{ title: '' }} />
      <Stack.Screen name="RingtonePicker" component={RingtonePickerScreen} options={{ title: '' }} />
    </Stack.Navigator>
  );
}
function CreateStack() {
  return (
    <Stack.Navigator screenOptions={stackOpts}>
      <Stack.Screen name="Studio" component={StudioScreen} options={{ headerShown: false }} />
      <Stack.Screen name="StudioEditor" component={StudioEditorScreen} options={{ title: '' }} />
    </Stack.Navigator>
  );
}
function TempleStack() {
  return (
    <Stack.Navigator screenOptions={stackOpts}>
      <Stack.Screen name="TempleList" component={TempleListScreen} options={{ headerShown: false }} />
      <Stack.Screen name="Darshan" component={DarshanScreen} options={{ headerShown: false, animation: 'fade' }} />
    </Stack.Navigator>
  );
}

const ICONS: Record<string, string> = { Alarm: '⏰', Create: '🎨', Calendar: '📅', Temple: '🛕', More: '☰' };

function Tabs() {
  const t = s().tabs;
  const labels: Record<string, string> = { Alarm: t.alarm, Create: t.create, Calendar: t.calendar, Temple: t.temple, More: t.more };
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarActiveTintColor: colors.maroon,
        tabBarInactiveTintColor: colors.textSoft,
        tabBarStyle: { backgroundColor: '#FFFDF6', minHeight: 72, paddingTop: 6, borderTopColor: colors.border },
        tabBarLabel: ({ color }) => <Text style={{ fontFamily: fonts.bold, fontSize: 14, color }}>{labels[route.name]}</Text>,
        tabBarIcon: ({ focused }) => <Text style={{ fontSize: 26, opacity: focused ? 1 : 0.6 }}>{ICONS[route.name]}</Text>,
      })}>
      <Tab.Screen name="Alarm" component={AlarmStack} />
      <Tab.Screen name="Create" component={CreateStack} />
      <Tab.Screen name="Calendar" component={CalendarScreen} />
      <Tab.Screen name="Temple" component={TempleStack} />
      <Tab.Screen name="More" component={MoreScreen} />
    </Tab.Navigator>
  );
}

function Root() {
  const { prefs, ready } = usePrefs();
  const [ringing, setRinging] = useState<Ringing | null>(null);
  const check = useCallback(() => setRinging(getRinging()), []);

  useEffect(() => {
    check();
    const sub = AppState.addEventListener('change', (st) => { if (st === 'active') check(); });
    const ev = addRingingListener(check);
    return () => { sub.remove(); ev?.remove(); };
  }, []);

  useEffect(() => { if (ready && prefs.onboarded) initAds(); }, [ready, prefs.onboarded]);

  // Festival reminder tap -> greeting editor for that festival.
  useEffect(() => {
    const sub = Notifications.addNotificationResponseReceivedListener((r) => {
      const d: any = r.notification.request.content.data;
      if (d?.greetingCategory && navRef.isReady()) {
        navRef.navigate('Create', { screen: 'StudioEditor', params: { festivalSlug: d.greetingCategory, festivalName: d.name }, initial: false });
      }
    });
    return () => sub.remove();
  }, []);

  if (!ready) return null;
  return (
    <View style={{ flex: 1 }}>
      <NavigationContainer ref={navRef} theme={{ ...DefaultTheme, colors: { ...DefaultTheme.colors, background: colors.cream, primary: colors.saffron } }}>
        {prefs.onboarded ? <Tabs /> : <OnboardingScreen />}
      </NavigationContainer>
      {ringing ? <WakeScreen ringing={ringing} region={prefs.region} onDone={() => setRinging(null)} /> : null}
    </View>
  );
}

export default function App() {
  const [loaded] = useFonts({ NotoSans_400Regular, NotoSans_500Medium, NotoSans_700Bold, NotoSansDevanagari_400Regular, NotoSansDevanagari_700Bold });
  useEffect(() => { if (loaded) SplashScreen.hideAsync().catch(() => {}); }, [loaded]);
  if (!loaded) return null;
  return (
    <SafeAreaProvider>
      <StatusBar style="dark" />
      <PrefsProvider><Root /></PrefsProvider>
    </SafeAreaProvider>
  );
}
