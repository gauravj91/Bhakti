import { readsHindi } from '../i18n';
export const mulankTitle = () => (readsHindi() ? 'मूलांक · अंक ज्योतिष' : 'Mulank · Numerology');

// Ank jyotish (numerology): mulank from birth day, bhagyank from full date of birth.
// Daily reading compares the day's number with the person's mulank (planet friendship).
// For guidance and entertainment only (same disclaimer as Rashifal).

export const reduce = (n: number): number => {
  let v = Math.abs(n);
  while (v > 9) v = String(v).split('').reduce((a, c) => a + Number(c), 0);
  return v;
};
export const mulankOf = (d: number) => reduce(d);
export const bhagyankOf = (y: number, m: number, d: number) => reduce(`${y}${m}${d}`.split('').reduce((a, c) => a + Number(c), 0));

type L = 'en' | 'hi';
type Info = {
  planet: Record<L, string>; deity: Record<L, string>; day: Record<L, string>; color: Record<L, string>;
  trait: Record<L, string>; upay: Record<L, string>; friends: number[]; enemies: number[];
};

export const MULANK: Record<number, Info> = {
  1: { planet: { en: 'Surya (Sun)', hi: 'सूर्य' }, deity: { en: 'Surya Dev', hi: 'सूर्य देव' }, day: { en: 'Sunday', hi: 'रविवार' }, color: { en: 'Golden, orange', hi: 'सुनहरा, नारंगी' },
    trait: { en: 'A natural leader: confident, self-reliant and full of new ideas.', hi: 'स्वाभाविक नेता: आत्मविश्वासी, आत्मनिर्भर और नए विचारों से भरे।' },
    upay: { en: 'Offer water to Surya Dev at sunrise.', hi: 'सूर्योदय पर सूर्य देव को जल अर्पित करें।' }, friends: [1, 2, 3, 9], enemies: [8] },
  2: { planet: { en: 'Chandra (Moon)', hi: 'चंद्र' }, deity: { en: 'Shiv ji', hi: 'शिव जी' }, day: { en: 'Monday', hi: 'सोमवार' }, color: { en: 'White, silver', hi: 'सफ़ेद, चाँदी' },
    trait: { en: 'Gentle, caring and imaginative, with strong intuition.', hi: 'कोमल, स्नेही और कल्पनाशील, गहरी अंतर्ज्ञान शक्ति।' },
    upay: { en: 'Offer water or milk on the Shivling.', hi: 'शिवलिंग पर जल या दूध चढ़ाएँ।' }, friends: [1, 2, 3, 5], enemies: [8] },
  3: { planet: { en: 'Guru (Jupiter)', hi: 'गुरु (बृहस्पति)' }, deity: { en: 'Vishnu ji', hi: 'विष्णु जी' }, day: { en: 'Thursday', hi: 'गुरुवार' }, color: { en: 'Yellow', hi: 'पीला' },
    trait: { en: 'Wise, disciplined and respected, a good guide for others.', hi: 'ज्ञानी, अनुशासित और सम्मानित, दूसरों के अच्छे मार्गदर्शक।' },
    upay: { en: 'Light a diya for Vishnu ji and offer yellow flowers.', hi: 'विष्णु जी के आगे दीया जलाएँ और पीले फूल चढ़ाएँ।' }, friends: [1, 2, 3, 9], enemies: [6] },
  4: { planet: { en: 'Rahu', hi: 'राहु' }, deity: { en: 'Durga Maa', hi: 'दुर्गा माँ' }, day: { en: 'Saturday', hi: 'शनिवार' }, color: { en: 'Blue, grey', hi: 'नीला, स्लेटी' },
    trait: { en: 'Hard-working and practical, sees things differently from others.', hi: 'मेहनती और व्यावहारिक, चीज़ों को अलग नज़र से देखते हैं।' },
    upay: { en: 'Read Durga Chalisa or chant “Om Dum Durgayei Namah”.', hi: 'दुर्गा चालीसा पढ़ें या “ॐ दुं दुर्गायै नमः” जपें।' }, friends: [1, 5, 6, 7], enemies: [2, 9] },
  5: { planet: { en: 'Budh (Mercury)', hi: 'बुध' }, deity: { en: 'Ganesh ji', hi: 'गणेश जी' }, day: { en: 'Wednesday', hi: 'बुधवार' }, color: { en: 'Green', hi: 'हरा' },
    trait: { en: 'Quick-witted, a good talker and quick to learn.', hi: 'तेज़ बुद्धि, बातचीत में कुशल और जल्दी सीखने वाले।' },
    upay: { en: 'Offer durva grass to Ganesh ji.', hi: 'गणेश जी को दूर्वा अर्पित करें।' }, friends: [1, 4, 5, 6], enemies: [3] },
  6: { planet: { en: 'Shukra (Venus)', hi: 'शुक्र' }, deity: { en: 'Lakshmi Maa', hi: 'लक्ष्मी माँ' }, day: { en: 'Friday', hi: 'शुक्रवार' }, color: { en: 'White, pink', hi: 'सफ़ेद, गुलाबी' },
    trait: { en: 'Loving and graceful, cares for family and beauty.', hi: 'प्रेमपूर्ण और सौम्य, परिवार और सुंदरता का ध्यान रखते हैं।' },
    upay: { en: 'Light a ghee diya for Lakshmi Maa in the evening.', hi: 'शाम को लक्ष्मी माँ के आगे घी का दीया जलाएँ।' }, friends: [4, 5, 6, 8], enemies: [3] },
  7: { planet: { en: 'Ketu', hi: 'केतु' }, deity: { en: 'Ganesh ji', hi: 'गणेश जी' }, day: { en: 'Monday', hi: 'सोमवार' }, color: { en: 'Light green, cream', hi: 'हल्का हरा, क्रीम' },
    trait: { en: 'Thoughtful and spiritual, loves calm and deep thinking.', hi: 'विचारशील और आध्यात्मिक, शांति और गहन चिंतन पसंद।' },
    upay: { en: 'Chant “Om Gan Ganapataye Namah” 11 times.', hi: '“ॐ गं गणपतये नमः” 11 बार जपें।' }, friends: [2, 4, 6, 7], enemies: [9] },
  8: { planet: { en: 'Shani (Saturn)', hi: 'शनि' }, deity: { en: 'Hanuman ji', hi: 'हनुमान जी' }, day: { en: 'Saturday', hi: 'शनिवार' }, color: { en: 'Dark blue', hi: 'गहरा नीला' },
    trait: { en: 'Patient and determined, success comes through steady effort.', hi: 'धैर्यवान और दृढ़, लगातार मेहनत से सफलता।' },
    upay: { en: 'Read Hanuman Chalisa and help someone in need.', hi: 'हनुमान चालीसा पढ़ें और किसी ज़रूरतमंद की मदद करें।' }, friends: [4, 5, 6, 8], enemies: [1, 2] },
  9: { planet: { en: 'Mangal (Mars)', hi: 'मंगल' }, deity: { en: 'Hanuman ji', hi: 'हनुमान जी' }, day: { en: 'Tuesday', hi: 'मंगलवार' }, color: { en: 'Red', hi: 'लाल' },
    trait: { en: 'Brave and energetic, protects family and friends.', hi: 'साहसी और ऊर्जावान, परिवार और मित्रों की रक्षा करने वाले।' },
    upay: { en: 'Offer sindoor or a red flower to Hanuman ji.', hi: 'हनुमान जी को सिंदूर या लाल फूल चढ़ाएँ।' }, friends: [1, 2, 3, 9], enemies: [5] },
};

const TEXT: Record<'good' | 'ok' | 'care', Record<L, string[]>> = {
  good: {
    en: ['A favourable day. Start the work you have been putting off.', 'Your number is in harmony with today. Good for meetings and family plans.', 'Luck supports your effort today. Speak up and take the first step.'],
    hi: ['शुभ दिन है। जो काम टाल रहे थे, उसे आज शुरू करें।', 'आज का अंक आपके मूलांक से मेल खाता है। मुलाक़ात और पारिवारिक योजना के लिए अच्छा।', 'आज भाग्य आपकी मेहनत का साथ देगा। आगे बढ़कर पहल करें।'],
  },
  ok: {
    en: ['A steady, ordinary day. Finish pending tasks calmly.', 'Mixed energy today. Plan well and avoid hurry.', 'A balanced day. Small steps will bring good results.'],
    hi: ['सामान्य, स्थिर दिन। अधूरे काम शांति से पूरे करें।', 'आज मिली-जुली ऊर्जा है। सोच-समझकर योजना बनाएँ, जल्दबाज़ी न करें।', 'संतुलित दिन। छोटे कदम अच्छे परिणाम देंगे।'],
  },
  care: {
    en: ['Go slowly today. Avoid arguments and big money decisions.', 'Patience is your strength today. Postpone risky work if you can.', 'A day to stay calm. Double-check plans and keep your words soft.'],
    hi: ['आज धीरे चलें। बहस और बड़े पैसों के फ़ैसलों से बचें।', 'आज धैर्य ही आपकी ताक़त है। जोखिम भरा काम हो सके तो टालें।', 'शांत रहने का दिन। योजनाएँ दोबारा जाँचें और बोली मीठी रखें।'],
  },
};

export type MulankDaily = { dayNumber: number; score: number; kind: 'good' | 'ok' | 'care'; text: string; luckyNumber: number; upay: string };

export function mulankDaily(mulank: number, date: Date, l: L): MulankDaily {
  const dayNumber = reduce(date.getDate() + date.getMonth() + 1 + date.getFullYear());
  const info = MULANK[mulank];
  const kind = dayNumber === mulank || info.friends.includes(dayNumber) ? 'good' : info.enemies.includes(dayNumber) ? 'care' : 'ok';
  const seed = date.getFullYear() * 400 + (date.getMonth() + 1) * 32 + date.getDate() + mulank;
  const text = TEXT[kind][l][seed % 3];
  const luckyNumber = info.friends[seed % info.friends.length];
  const score = kind === 'good' ? 4 + (seed % 2) : kind === 'ok' ? 3 : 2;
  return { dayNumber, score, kind, text, luckyNumber, upay: info.upay[l] };
}
