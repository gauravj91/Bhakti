// Rashifal from Vedic gochar (transits counted from the reader's Moon sign), generated on the phone.
// Classical rule set (Chandra/Surya/Guru/Shani gochar) phrased as gentle guidance. For entertainment and guidance only.
import { moonSign, sidLon, signOf, houseFrom, RASHI_LORD } from '../lib/astro';

type Bi = { en: string; hi: string };
export type Lang = 'en' | 'hi';
const pick = <T,>(xs: T[], seed: number) => xs[Math.abs(seed) % xs.length];
const hash = (...n: number[]) => n.reduce((h, x) => ((h * 31 + x) | 0), 7);
const dayKey = (d: Date) => { const x = ist(d); return x.getUTCFullYear() * 400 + x.getUTCMonth() * 32 + x.getUTCDate(); };
/** The given moment shifted to IST, read with getUTC*. */
const ist = (d: Date) => new Date(d.getTime() + 5.5 * 3600e3);
/** Noon IST of the civil day containing d. */
export const noonIST = (d: Date) => { const x = ist(d); return new Date(Date.UTC(x.getUTCFullYear(), x.getUTCMonth(), x.getUTCDate(), 12) - 5.5 * 3600e3); };
export const addDays = (d: Date, n: number) => new Date(d.getTime() + n * 86400e3);

// Score of the Moon's transit house from the natal Moon sign (1 = tough, 5 = excellent).
const MOON_SCORE = [0, 3, 3, 5, 2, 3, 5, 4, 1, 3, 5, 5, 2];

// Moon transit, house 1..12: two phrasings each.
const MOON: Record<number, Bi[]> = {
  1: [{ en: 'The Moon is in your own sign today. You feel emotional and sensitive, and family support stays strong. Eat light and keep your mind calm.', hi: 'आज चंद्रमा आपकी ही राशि में है। मन भावुक रहेगा, पर परिवार का साथ मिलेगा। हल्का भोजन करें और मन शांत रखें।' },
      { en: 'A day for self-care. Your feelings guide you, so pause before you react. Simple pleasures and time at home will refresh you.', hi: 'आज अपना ध्यान रखने का दिन है। भावनाएँ हावी रह सकती हैं, इसलिए प्रतिक्रिया से पहले रुकें। घर पर समय बिताना सुकून देगा।' }],
  2: [{ en: 'Watch your words and your wallet today. Small expenses can add up. Speak sweetly with family and avoid lending money.', hi: 'आज वाणी और खर्च पर ध्यान दें। छोटे-छोटे खर्च बढ़ सकते हैं। परिवार से मीठा बोलें और उधार देने से बचें।' },
      { en: 'Money matters need a careful eye. Good food and family talks bring joy, but postpone big purchases.', hi: 'धन के मामलों में सावधानी रखें। अच्छा भोजन और परिवार की बातें खुशी देंगी, पर बड़ी खरीदारी टाल दें।' }],
  3: [{ en: 'An energetic, successful day. Your efforts pay off, short trips go well and siblings or friends help you. Take that bold step.', hi: 'ऊर्जा से भरा, सफल दिन। मेहनत रंग लाएगी, छोटी यात्राएँ शुभ रहेंगी और भाई-बहन या मित्र साथ देंगे। हिम्मत से कदम बढ़ाएँ।' },
      { en: 'Courage and confidence are high. Good day for calls, messages, paperwork and starting something new.', hi: 'साहस और आत्मविश्वास ऊँचा रहेगा। फ़ोन, संदेश, कागज़ी काम और नई शुरुआत के लिए अच्छा दिन है।' }],
  4: [{ en: 'You may feel a little restless at home. Avoid arguments with relatives and take care of your mother’s health. Evening prayer brings peace.', hi: 'घर में मन थोड़ा बेचैन रह सकता है। रिश्तेदारों से बहस न करें और माता के स्वास्थ्य का ध्यान रखें। शाम की आरती शांति देगी।' },
      { en: 'Keep travel short and drive carefully. Comfort at home matters most today, so do not take on too much.', hi: 'यात्रा कम रखें और वाहन सावधानी से चलाएँ। आज घर का सुख ही सबसे ज़रूरी है, ज़्यादा काम न लें।' }],
  5: [{ en: 'A mixed day. Children may need your attention, and decisions about money or studies need thought. Prayer and patience help.', hi: 'मिला-जुला दिन। बच्चों पर ध्यान देना पड़ेगा, पैसे या पढ़ाई के फ़ैसले सोच-समझकर लें। पूजा और धैर्य से लाभ होगा।' },
      { en: 'Your mind is creative but a little unsettled. Avoid risky investments, and spend time on devotion or a hobby.', hi: 'मन रचनात्मक पर थोड़ा अस्थिर रहेगा। जोखिम वाले निवेश से बचें, भक्ति या किसी शौक में समय दें।' }],
  6: [{ en: 'A winning day. Health improves, pending work gets done and opponents step back. Good day to clear debts or visit a doctor.', hi: 'जीत का दिन। स्वास्थ्य सुधरेगा, अटके काम पूरे होंगे और विरोधी पीछे हटेंगे। कर्ज़ चुकाने या डॉक्टर से मिलने के लिए अच्छा दिन।' },
      { en: 'You handle problems with ease today. Service, routine work and helping others bring satisfaction and respect.', hi: 'आज आप समस्याओं को आसानी से सुलझा लेंगे। सेवा, नियमित काम और दूसरों की मदद से संतोष और सम्मान मिलेगा।' }],
  7: [{ en: 'Happy moments with your spouse and partners. Meetings, deals and social outings go well. A pleasant, sociable day.', hi: 'जीवनसाथी और साझेदारों के साथ सुखद पल। मुलाक़ात, सौदे और मेल-जोल अच्छे रहेंगे। खुशनुमा दिन।' },
      { en: 'Relationships bring joy today. Good for business talks, visiting relatives and planning together as a couple.', hi: 'आज रिश्तों से खुशी मिलेगी। व्यापार की बातचीत, रिश्तेदारों से मिलने और साथ मिलकर योजना बनाने के लिए अच्छा।' }],
  8: [{ en: 'A day to go slow. Avoid risky decisions, long drives and quarrels. Rest well, and remember Bhagwan in the evening.', hi: 'धीरे चलने का दिन। जोखिम वाले फ़ैसले, लंबी ड्राइव और झगड़ों से बचें। आराम करें और शाम को भगवान का स्मरण करें।' },
      { en: 'Things may feel delayed. Keep important documents safe, eat on time and do not start anything new today.', hi: 'काम में देरी महसूस हो सकती है। ज़रूरी कागज़ सँभालकर रखें, समय पर भोजन करें और आज कुछ नया शुरू न करें।' }],
  9: [{ en: 'Luck supports you moderately. Elders and teachers give good advice. A fine day for a temple visit or charity.', hi: 'भाग्य का साथ मिलेगा। बड़े-बुज़ुर्ग और गुरु अच्छी सलाह देंगे। मंदिर जाने या दान करने के लिए अच्छा दिन।' },
      { en: 'Faith gives you strength today. Plans for travel or pilgrimage come up. Avoid over-promising at work.', hi: 'आज आस्था से बल मिलेगा। यात्रा या तीर्थ की योजना बन सकती है। काम में ज़्यादा वादे न करें।' }],
  10: [{ en: 'Excellent for work. Seniors notice your effort, and business brings gains. Finish important tasks before evening.', hi: 'काम के लिए बहुत अच्छा दिन। अधिकारी आपकी मेहनत देखेंगे और व्यापार में लाभ होगा। ज़रूरी काम शाम से पहले पूरे करें।' },
       { en: 'Respect and recognition come your way. A strong day for interviews, meetings and important decisions.', hi: 'मान-सम्मान मिलेगा। इंटरव्यू, मीटिंग और ज़रूरी फ़ैसलों के लिए मज़बूत दिन।' }],
  11: [{ en: 'A day of gains. Income, good news and help from friends arrive. Wishes you have held for a while may come true.', hi: 'लाभ का दिन। आमदनी, शुभ समाचार और मित्रों की मदद मिलेगी। लंबे समय की इच्छा पूरी हो सकती है।' },
       { en: 'Everything flows in your favour. Meet friends, follow up on payments and enjoy the evening with family.', hi: 'सब कुछ आपके पक्ष में रहेगा। मित्रों से मिलें, बकाया पैसे की बात करें और शाम परिवार के साथ आनंद लें।' }],
  12: [{ en: 'Expenses and tiredness may rise. Sleep well, avoid lending and spend some quiet time in prayer or meditation.', hi: 'खर्च और थकान बढ़ सकती है। अच्छी नींद लें, उधार न दें और कुछ समय पूजा या ध्यान में बिताएँ।' },
       { en: 'A good day for spiritual work and charity, less so for money matters. Travel plans need care.', hi: 'आध्यात्मिक काम और दान के लिए अच्छा, पर पैसों के मामले में कमज़ोर दिन। यात्रा में सावधानी रखें।' }],
};

const AREA: Record<'career' | 'money' | 'family' | 'health', Record<'good' | 'mid' | 'low', Bi[]>> = {
  career: {
    good: [{ en: 'Work moves fast and your ideas are valued.', hi: 'काम तेज़ी से होगा और आपके विचारों की क़द्र होगी।' }, { en: 'A good time to ask for support from seniors.', hi: 'वरिष्ठों से सहयोग माँगने का अच्छा समय।' }],
    mid: [{ en: 'Steady day. Stick to your routine.', hi: 'सामान्य दिन। अपनी दिनचर्या पर टिके रहें।' }, { en: 'Double-check details before you submit work.', hi: 'काम जमा करने से पहले एक बार जाँच लें।' }],
    low: [{ en: 'Avoid clashes at work and do not rush decisions.', hi: 'काम पर टकराव से बचें और जल्दबाज़ी में फ़ैसले न लें।' }, { en: 'Delays are possible. Keep patience.', hi: 'देरी हो सकती है, धैर्य रखें।' }],
  },
  money: {
    good: [{ en: 'Gains are likely, maybe from an old source.', hi: 'लाभ के योग, शायद किसी पुराने स्रोत से।' }, { en: 'A good day for saving and planning.', hi: 'बचत और योजना के लिए अच्छा दिन।' }],
    mid: [{ en: 'Income and expenses stay balanced.', hi: 'आमदनी और खर्च संतुलित रहेंगे।' }, { en: 'Spend only on what is needed.', hi: 'ज़रूरत भर ही खर्च करें।' }],
    low: [{ en: 'Avoid lending, loans and big purchases.', hi: 'उधार, कर्ज़ और बड़ी खरीदारी से बचें।' }, { en: 'Unplanned expenses may come up.', hi: 'अचानक खर्च आ सकते हैं।' }],
  },
  family: {
    good: [{ en: 'Warm moments with family and your spouse.', hi: 'परिवार और जीवनसाथी के साथ प्यार भरे पल।' }, { en: 'Good news from relatives is possible.', hi: 'रिश्तेदारों से शुभ समाचार मिल सकता है।' }],
    mid: [{ en: 'Listen more and the day stays peaceful.', hi: 'ज़्यादा सुनें, दिन शांति से बीतेगा।' }, { en: 'Spend some time with elders.', hi: 'बड़ों के साथ कुछ समय बिताएँ।' }],
    low: [{ en: 'Small misunderstandings are possible. Stay soft-spoken.', hi: 'छोटी-मोटी ग़लतफ़हमी हो सकती है, नरमी से बोलें।' }, { en: 'Do not let ego spoil a happy moment.', hi: 'अहं को खुशी के पल ख़राब न करने दें।' }],
  },
  health: {
    good: [{ en: 'Energy is good. A walk in the morning will help.', hi: 'ऊर्जा अच्छी रहेगी। सुबह की सैर लाभ देगी।' }, { en: 'You feel fresh and active.', hi: 'आप ताज़गी और फुर्ती महसूस करेंगे।' }],
    mid: [{ en: 'Drink enough water and sleep on time.', hi: 'पर्याप्त पानी पिएँ और समय पर सोएँ।' }, { en: 'Balance rest with work.', hi: 'काम के साथ आराम भी करें।' }],
    low: [{ en: 'Take care of digestion and avoid outside food.', hi: 'पाचन का ध्यान रखें और बाहर का खाना न खाएँ।' }, { en: 'Tiredness or headache possible. Rest early.', hi: 'थकान या सिरदर्द हो सकता है, जल्दी आराम करें।' }],
  },
};

// Remedy by the sign lord (index into astro PLANETS).
const UPAY: Record<number, Bi> = {
  0: { en: 'Offer water to the rising Sun (Surya arghya).', hi: 'उगते सूर्य को जल चढ़ाएँ (सूर्य अर्घ्य)।' },
  1: { en: 'Offer water or milk on a Shivling.', hi: 'शिवलिंग पर जल या दूध चढ़ाएँ।' },
  2: { en: 'Read the Hanuman Chalisa.', hi: 'हनुमान चालीसा का पाठ करें।' },
  3: { en: 'Offer durva grass to Shri Ganesh.', hi: 'श्री गणेश को दूर्वा अर्पित करें।' },
  4: { en: 'Offer yellow flowers to Shri Vishnu and do the Guruvar aarti.', hi: 'श्री विष्णु को पीले फूल चढ़ाएँ और आरती करें।' },
  5: { en: 'Do Maa Lakshmi’s aarti and offer white sweets.', hi: 'माँ लक्ष्मी की आरती करें और सफ़ेद मिठाई का भोग लगाएँ।' },
  6: { en: 'Light a mustard oil diya under a peepal tree in the evening.', hi: 'शाम को पीपल के नीचे सरसों के तेल का दीया जलाएँ।' },
};
const COLORS: Bi[] = [
  { en: 'Red', hi: 'लाल' }, { en: 'White', hi: 'सफ़ेद' }, { en: 'Orange', hi: 'नारंगी' }, { en: 'Green', hi: 'हरा' },
  { en: 'Yellow', hi: 'पीला' }, { en: 'Pink', hi: 'गुलाबी' }, { en: 'Blue', hi: 'नीला' }, { en: 'Cream', hi: 'क्रीम' }, { en: 'Maroon', hi: 'मैरून' },
];
const LUCKY_NUM = [9, 6, 5, 2, 1, 5, 6, 9, 3, 8, 8, 3];

const level = (score: number) => (score >= 4 ? 'good' : score >= 3 ? 'mid' : 'low') as 'good' | 'mid' | 'low';
const tr = (b: Bi, l: Lang) => b[l];

export type Daily = { score: number; text: string; career: string; money: string; family: string; health: string; color: string; number: number; upay: string; moonHouse: number };

/** Rashifal for the civil day (IST) that contains `day`. */
export function dailyRashifal(rashi: number, day: Date, l: Lang): Daily {
  const at = noonIST(day);
  const h = houseFrom(rashi, moonSign(at));
  const k = dayKey(at);
  // Sun and Venus soften or lift the day a little.
  const sunH = houseFrom(rashi, signOf(sidLon(0, at)));
  const venH = houseFrom(rashi, signOf(sidLon(5, at)));
  let score = MOON_SCORE[h] + ([3, 6, 10, 11].includes(sunH) ? 0.5 : 0) + ([1, 2, 3, 4, 5, 8, 9, 11, 12].includes(venH) ? 0.25 : -0.25);
  score = Math.max(1, Math.min(5, Math.round(score)));
  const s = hash(k, rashi);
  const lv = level(score);
  const famLv = [7, 11, 1, 3].includes(h) ? 'good' : [4, 8, 12].includes(h) ? 'low' : 'mid';
  const monLv = [2, 12, 8].includes(h) ? 'low' : [11, 10, 6].includes(h) ? 'good' : 'mid';
  const hltLv = [6, 3, 11].includes(h) ? 'good' : [8, 12, 1].includes(h) ? 'low' : 'mid';
  return {
    score, moonHouse: h,
    text: tr(pick(MOON[h], s), l),
    career: tr(pick(AREA.career[lv], s + 1), l),
    money: tr(pick(AREA.money[monLv], s + 2), l),
    family: tr(pick(AREA.family[famLv], s + 3), l),
    health: tr(pick(AREA.health[hltLv], s + 4), l),
    color: tr(COLORS[Math.abs(hash(k, rashi, 5)) % COLORS.length], l),
    number: ((LUCKY_NUM[rashi] + (Math.abs(s) % 3) * 3 - 1) % 9) + 1,
    upay: tr(UPAY[RASHI_LORD[rashi]], l),
  };
}

const DAY_NAMES: Record<Lang, string[]> = {
  en: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
  hi: ['रवि', 'सोम', 'मंगल', 'बुध', 'गुरु', 'शुक्र', 'शनि'],
};
const fmtDay = (d: Date, l: Lang) => { const x = ist(d); return `${DAY_NAMES[l][x.getUTCDay()]} ${x.getUTCDate()}`; };

// Slow planets: gochar from the Moon sign.
const SLOW: { i: number; good: number[]; good_t: Bi; bad_t: Bi }[] = [
  { i: 0, good: [3, 6, 10, 11], good_t: { en: 'The Sun supports your career and reputation.', hi: 'सूर्य करियर और मान-सम्मान में साथ देगा।' }, bad_t: { en: 'The Sun asks you to keep ego in check and look after your health.', hi: 'सूर्य कहता है कि अहं पर नियंत्रण रखें और सेहत का ध्यान रखें।' } },
  { i: 2, good: [3, 6, 11], good_t: { en: 'Mars gives you courage and helps you win over obstacles.', hi: 'मंगल साहस देगा और बाधाओं पर जीत दिलाएगा।' }, bad_t: { en: 'Mars can bring anger or haste. Drive carefully and avoid disputes.', hi: 'मंगल ग़ुस्सा या जल्दबाज़ी ला सकता है। वाहन सावधानी से चलाएँ, विवाद से बचें।' } },
  { i: 5, good: [1, 2, 3, 4, 5, 8, 9, 11, 12], good_t: { en: 'Venus brings comfort, love and pleasant moments at home.', hi: 'शुक्र सुख, प्रेम और घर में सुखद पल लाएगा।' }, bad_t: { en: 'Venus is weak for you. Keep spending on luxuries in control.', hi: 'शुक्र कमज़ोर है। शौक़ और ऐशो-आराम पर खर्च सीमित रखें।' } },
  { i: 4, good: [2, 5, 7, 9, 11], good_t: { en: 'Jupiter blesses you with growth, good advice and family happiness.', hi: 'गुरु उन्नति, अच्छी सलाह और पारिवारिक सुख का आशीर्वाद देंगे।' }, bad_t: { en: 'Jupiter asks for patience. Progress is slow but steady with honest effort.', hi: 'गुरु धैर्य माँगते हैं। ईमानदार मेहनत से धीरे-धीरे प्रगति होगी।' } },
  { i: 6, good: [3, 6, 11], good_t: { en: 'Saturn rewards your hard work and discipline.', hi: 'शनि आपकी मेहनत और अनुशासन का फल देंगे।' }, bad_t: { en: 'Saturn tests your patience. Work hard, stay humble and help the needy.', hi: 'शनि धैर्य की परीक्षा लेंगे। मेहनत करें, विनम्र रहें और ज़रूरतमंदों की मदद करें।' } },
];

export type Period = { score: number; text: string; best: string[]; careful: string[]; planets: string[]; upay: string };

function periodFor(rashi: number, start: Date, days: number, l: Lang, slowIdx: number[]): Period {
  const scores: { d: Date; s: number }[] = [];
  for (let n = 0; n < days; n++) { const d = addDays(noonIST(start), n); scores.push({ d, s: MOON_SCORE[houseFrom(rashi, moonSign(d))] }); }
  const mid = addDays(noonIST(start), Math.floor(days / 2));
  const planets = SLOW.filter((p) => slowIdx.includes(p.i)).map((p) => {
    const h = houseFrom(rashi, signOf(sidLon(p.i, mid)));
    return { good: p.good.includes(h), t: tr(p.good.includes(h) ? p.good_t : p.bad_t, l) };
  });
  const goodCount = planets.filter((p) => p.good).length;
  const avg = scores.reduce((a, b) => a + b.s, 0) / scores.length;
  const score = Math.max(1, Math.min(5, Math.round(avg * 0.6 + (1 + (4 * goodCount) / Math.max(1, planets.length)) * 0.4)));
  const best = scores.filter((x) => x.s >= 5).map((x) => fmtDay(x.d, l));
  const careful = scores.filter((x) => x.s <= 1).map((x) => fmtDay(x.d, l));
  const intro = score >= 4
    ? (l === 'hi' ? 'यह समय आपके लिए शुभ है। मेहनत का अच्छा फल मिलेगा और मन प्रसन्न रहेगा।' : 'A favourable period. Your efforts bring good results and your mind stays cheerful.')
    : score >= 3
      ? (l === 'hi' ? 'मिला-जुला समय है। योजना बनाकर चलें तो अच्छे परिणाम मिलेंगे।' : 'A mixed period. Plan well and the results will be good.')
      : (l === 'hi' ? 'धैर्य रखने का समय है। बड़े फ़ैसले शुभ दिनों में ही लें और भक्ति से मन मज़बूत रखें।' : 'A time for patience. Take big decisions on your good days and let devotion keep you strong.');
  return { score, text: intro, best, careful, planets: planets.map((p) => p.t), upay: tr(UPAY[RASHI_LORD[rashi]], l) };
}

/** Week starting Monday of the current week. */
export function weeklyRashifal(rashi: number, today: Date, l: Lang): Period & { from: Date; to: Date } {
  const x = ist(today); const back = (x.getUTCDay() + 6) % 7;
  const from = addDays(noonIST(today), -back);
  return { ...periodFor(rashi, from, 7, l, [0, 5, 4]), from, to: addDays(from, 6) };
}
/** The calendar month containing today. */
export function monthlyRashifal(rashi: number, today: Date, l: Lang): Period & { from: Date; to: Date } {
  const x = ist(today);
  const from = new Date(Date.UTC(x.getUTCFullYear(), x.getUTCMonth(), 1, 12) - 5.5 * 3600e3);
  const days = new Date(Date.UTC(x.getUTCFullYear(), x.getUTCMonth() + 1, 0)).getUTCDate();
  return { ...periodFor(rashi, from, days, l, [0, 2, 5, 4, 6]), from, to: addDays(from, days - 1) };
}
