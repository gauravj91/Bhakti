// Devotional radio stations that stream openly on the web (found via radio-browser.info, checked 2026-11-09).
// Permission requests to each station are pending; remove a station if it asks us to.
export type Station = { id: string; name: string; lang: string; desc: string; url: string; pls?: string; site: string };

export const STATIONS: Station[] = [
  { id: 'mahakatha', name: 'Mahakatha Radio', lang: 'Hindi · Sanskrit', desc: 'Mantra, chanting & bhajan', url: 'https://mahakatharadio.com/api/station/live.mp3', site: 'mahakatharadio.com' },
  { id: 'svbc', name: 'SVBC TTD Radio', lang: 'Telugu', desc: 'Sri Venkateswara, Tirumala', url: 'https://radio.mslivecdn.com:6278/stream', site: 'svbcttd.com' },
  { id: 'sai_asia', name: 'Radio Sai Global Harmony', lang: 'Bhajan · English', desc: 'Bhajans & discourses', url: 'http://stream.radiosai.net:8002/', site: 'radiosai.org' },
  { id: 'sai_gayatri', name: 'Radio Sai: Gayatri Mantra', lang: 'Sanskrit', desc: 'Gayatri mantra, nonstop', url: 'http://stream.radiosai.net:8006/', site: 'radiosai.org' },
  { id: 'sai_shiva', name: 'Radio Sai: Om Namah Shivaya', lang: 'Sanskrit', desc: 'Shiva Panchakshari chanting', url: 'http://stream.radiosai.net:8012/', site: 'radiosai.org' },
  { id: 'sai_vedam', name: 'Radio Sai: Vedam', lang: 'Sanskrit', desc: 'Vedic chanting, Rudram', url: 'http://stream.radiosai.net:8010/', site: 'radiosai.org' },
  { id: 'shaiva', name: 'Shaiva Lahari', lang: 'Tamil', desc: 'Thevaram & Shiva bhakti', url: 'https://26343.live.streamtheworld.com/SP_R2925215_SC', pls: 'https://samcloud.spacial.com/api/listen?sid=107886&rid=186750&f=mp3,any&br=128000,any&m=pls&t=ssl', site: 'shaivam.org' },
];

// Shaiva Lahari's direct server changes; resolve its playlist first, fall back to the last known URL.
export async function streamUrl(st: Station): Promise<string> {
  if (!st.pls) return st.url;
  try {
    const r = await fetch(st.pls);
    const m = (await r.text()).match(/^File1=(.+)$/m);
    if (m) return m[1].trim();
  } catch (e) {}
  return st.url;
}
