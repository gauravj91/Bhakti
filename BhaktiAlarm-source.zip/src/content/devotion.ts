import lyricsData from '../data/lyrics.json';
import vratData from '../data/vrats.json';
import liveData from '../data/live-darshan.json';
import type { Festival } from './catalog';

export type Verse = { hi: string; en: string };
export type Lyric = { id: string; title: string; titleHi: string; kind: 'chalisa' | 'aarti' | 'bhajan'; deity: string; author: string; verses: Verse[] };
export type Bi = { en: string; hi: string };
export type BiList = { en: string[]; hi: string[] };
export type VratGuide = { key: string; name: string; nameHi: string; deity: string | null; about: Bi; rules: BiList; eat: BiList; avoid: BiList; puja: BiList; katha: Bi };
export type LiveTemple = { id: string; name: string; nameHi: string; place: string; deity: string | null; channelId: string; channelUrl: string; schedule?: string };

export const LYRICS: Lyric[] = (lyricsData as any).items || [];
export const VRATS: VratGuide[] = (vratData as any).items || [];
export const LIVE: LiveTemple[] = (liveData as any).items || [];

export const lyricById = (id: string) => LYRICS.find((l) => l.id === id);
export const vratByKey = (k: string) => VRATS.find((v) => v.key === k);

/** Map a calendar entry to its vrat guide (by id/name pattern). */
export function vratFor(f: Pick<Festival, 'id' | 'name' | 'type'>): VratGuide | undefined {
  const id = f.id.toLowerCase();
  const rules: [RegExp, string][] = [
    [/ekadashi/, 'ekadashi'], [/pradosh/, 'pradosh-vrat'], [/sankashti/, 'sankashti-chaturthi'],
    [/karva-chauth|karwa-chauth/, 'karva-chauth'], [/ahoi/, 'ahoi-ashtami'], [/maha-shivaratri|mahashivratri/, 'maha-shivaratri'],
    [/navratri/, 'navratri'], [/janmashtami/, 'janmashtami'], [/sheetala/, 'sheetala-ashtami'], [/gangaur/, 'gangaur'],
    [/hartalika/, 'hartalika-teej'], [/vat-savitri/, 'vat-savitri'], [/chhath/, 'chhath'],
    [/purnima/, 'purnima'], [/amavasya/, 'amavasya'],
  ];
  for (const [re, key] of rules) if (re.test(id)) { const g = vratByKey(key); if (g) return g; }
  return undefined;
}
