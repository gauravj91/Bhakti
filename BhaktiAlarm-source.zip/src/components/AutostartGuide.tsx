import React from 'react';
import { View, Linking } from 'react-native';
import { Card, T, Button } from './ui';
import { Oem } from '../lib/oem';
import { s, fmt } from '../i18n';
import { colors } from '../theme';

/** Friendly card: allow Autostart + no battery restrictions, with brand steps and a settings button. */
export default function AutostartGuide({ oem, onDone }: { oem: Oem; onDone: () => void }) {
  const t = s().oem;
  const steps = t.steps[oem.key];
  return (
    <Card style={{ marginBottom: 16, backgroundColor: '#FFF1DE', borderColor: colors.saffron, borderWidth: 2 }}>
      <T bold big style={{ color: colors.maroon }}>🔔 {t.title}</T>
      <T style={{ marginTop: 6 }}>{t.body}</T>
      {oem.brand ? <T bold style={{ marginTop: 12 }}>{fmt(t.stepsFor, { brand: oem.brand })}</T> : null}
      <View style={{ marginTop: oem.brand ? 4 : 12 }}>
        {steps.map((x, i) => (
          <View key={i} style={{ flexDirection: 'row', marginTop: 6 }}>
            <T bold style={{ color: colors.saffronDark, width: 28 }}>{i + 1}.</T>
            <T style={{ flex: 1 }}>{x}</T>
          </View>
        ))}
      </View>
      <Button icon="⚙️" label={t.open} onPress={() => Linking.openSettings().catch(() => {})} style={{ marginTop: 16 }} />
      <Button kind="ghost" label={t.done} onPress={onDone} style={{ marginTop: 6 }} />
    </Card>
  );
}
