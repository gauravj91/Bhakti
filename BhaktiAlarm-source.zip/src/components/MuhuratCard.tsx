import React, { useMemo, useState } from 'react';
import { View, Text, StyleSheet, Pressable } from 'react-native';
import { panchangFor, cityFor, fmtSpan, Span } from '../lib/panchang';
import { s, fmt, getLanguage } from '../i18n';
import { colors, fonts, radius } from '../theme';

const ymd = (x: Date) => `${x.getFullYear()}-${String(x.getMonth() + 1).padStart(2, '0')}-${String(x.getDate()).padStart(2, '0')}`;
const QCOLOR = { good: '#1E7B34', neutral: '#8A6D00', bad: '#B3261E' } as const;
const QBG = { good: '#E7F5EA', neutral: '#FFF6D6', bad: '#FDECEA' } as const;

export default function MuhuratCard({ region }: { region: string | null }) {
  const t = s().muhurat;
  const hi = getLanguage() !== 'en';
  const p = useMemo(() => panchangFor(new Date(), cityFor(region)), [region, ymd(new Date())]);
  const [more, setMore] = useState(false);
  const m = p.muhurat;
  if (!m) return null;
  const now = Date.now();
  const isNow = (x: Span) => x[0].getTime() <= now && now < x[1].getTime();

  const Line = ({ k, v, q, sub, live }: { k: string; v: string; q: 'good' | 'neutral' | 'bad'; sub?: string; live?: boolean }) => (
    <View style={[st.row, { backgroundColor: QBG[q] }]}>
      <View style={{ flex: 1 }}>
        <Text style={[st.k, { color: QCOLOR[q] }]}>{k}{live ? `  · ${t.now}` : ''}</Text>
        {sub ? <Text style={st.sub}>{sub}</Text> : null}
      </View>
      <Text style={[st.v, { color: QCOLOR[q] }]}>{v}</Text>
    </View>
  );

  return (
    <View style={st.card}>
      <Text style={st.title}>✨ {t.title}</Text>
      <Line k={t.brahma} v={fmtSpan(m.brahma)} q="good" live={isNow(m.brahma)} />
      <Line k={t.abhijit} v={fmtSpan(m.abhijit)} q={m.abhijitOk ? 'good' : 'neutral'} sub={m.abhijitOk ? undefined : t.abhijitWed} live={isNow(m.abhijit)} />
      <Text style={st.section}>⚠️ {t.avoid}</Text>
      <Line k={t.rahu} v={fmtSpan(m.rahu)} q="bad" live={isNow(m.rahu)} />
      {more ? (
        <>
          <Line k={t.yamaganda} v={fmtSpan(m.yamaganda)} q="bad" live={isNow(m.yamaganda)} />
          <Line k={t.gulika} v={fmtSpan(m.gulika)} q="bad" live={isNow(m.gulika)} />
          <Text style={st.section}>🕉️ {t.choghadiya}</Text>
          {m.choghadiya.map((c, i) => (
            <Line key={i} k={`${hi ? c.nameHi : c.name} · ${t[c.quality]}`} v={fmtSpan(c.span)} q={c.quality} live={isNow(c.span)} />
          ))}
          <Text style={st.note}>{fmt(t.note, { city: p.city.name })}</Text>
        </>
      ) : null}
      <Pressable onPress={() => setMore(!more)} style={st.more} accessibilityRole="button">
        <Text style={st.moreT}>{more ? t.showLess : t.showMore} {more ? '▲' : '▼'}</Text>
      </Pressable>
    </View>
  );
}

const st = StyleSheet.create({
  card: { backgroundColor: colors.white, borderRadius: radius.md, padding: 16, marginBottom: 20, borderWidth: 1, borderColor: colors.border },
  title: { fontFamily: fonts.bold, fontSize: 22, color: colors.maroon, marginBottom: 10 },
  section: { fontFamily: fonts.bold, fontSize: 16, color: colors.text, marginTop: 12, marginBottom: 6 },
  row: { flexDirection: 'row', alignItems: 'center', paddingVertical: 10, paddingHorizontal: 12, borderRadius: 10, marginBottom: 6 },
  k: { fontFamily: fonts.bold, fontSize: 16 },
  sub: { fontFamily: fonts.regular, fontSize: 13, color: colors.textSoft },
  v: { fontFamily: fonts.bold, fontSize: 16, marginLeft: 8 },
  note: { fontFamily: fonts.regular, fontSize: 13, color: colors.textSoft, marginTop: 8 },
  more: { alignItems: 'center', paddingVertical: 10, marginTop: 4 },
  moreT: { fontFamily: fonts.bold, fontSize: 16, color: colors.saffron },
});
