import React, { useState } from 'react';
import { Pressable, Text, Alert } from 'react-native';
import { ExpoSpeechRecognitionModule, useSpeechRecognitionEvent } from 'expo-speech-recognition';
import { ttsLang } from '../lib/voice';
import { colors } from '../theme';

/** Tap, speak, and the words land in the field. For people who find typing hard. */
export default function MicButton({ onText }: { onText: (t: string) => void }) {
  const [on, setOn] = useState(false);
  useSpeechRecognitionEvent('result', (e) => { if (on && e.results?.[0]?.transcript) onText(e.results[0].transcript); });
  useSpeechRecognitionEvent('end', () => setOn(false));
  useSpeechRecognitionEvent('error', () => setOn(false));

  const start = async () => {
    if (on) { ExpoSpeechRecognitionModule.stop(); return; }
    try {
      const p = await ExpoSpeechRecognitionModule.requestPermissionsAsync();
      if (!p.granted) { Alert.alert('🎤', 'Please allow the microphone to speak instead of typing.'); return; }
      setOn(true);
      ExpoSpeechRecognitionModule.start({ lang: ttsLang(), interimResults: true, continuous: false });
    } catch { setOn(false); }
  };
  return (
    <Pressable onPress={start} accessibilityRole="button" accessibilityLabel="Speak"
      style={{ width: 56, height: 56, borderRadius: 28, marginLeft: 8, alignItems: 'center', justifyContent: 'center', backgroundColor: on ? colors.maroon : colors.saffron }}>
      <Text style={{ fontSize: 24 }}>{on ? '⏺️' : '🎤'}</Text>
    </Pressable>
  );
}
