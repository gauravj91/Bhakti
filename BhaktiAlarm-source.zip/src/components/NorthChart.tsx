import React from 'react';
import { View } from 'react-native';
import Svg, { Rect, Line, Polygon, Text as SvgText } from 'react-native-svg';
import { colors } from '../theme';

// North Indian (diamond) chart. House 1 is the top centre diamond, counted anticlockwise.
const CENTERS: [number, number][] = [
  [0.5, 0.27], [0.25, 0.11], [0.11, 0.25], [0.27, 0.5], [0.11, 0.75], [0.25, 0.89],
  [0.5, 0.73], [0.75, 0.89], [0.89, 0.75], [0.73, 0.5], [0.89, 0.25], [0.75, 0.11],
];
// Where the sign number sits (towards the centre of the chart).
const SIGN_AT: [number, number][] = [
  [0.5, 0.44], [0.25, 0.2], [0.2, 0.25], [0.44, 0.5], [0.2, 0.75], [0.25, 0.8],
  [0.5, 0.56], [0.75, 0.8], [0.8, 0.75], [0.56, 0.5], [0.8, 0.25], [0.75, 0.2],
];

export default function NorthChart({ size, lagnaSign, houses }: { size: number; lagnaSign: number; houses: string[][] }) {
  const S = size;
  return (
    <View style={{ width: S, height: S }}>
      <Svg width={S} height={S}>
        <Rect x={1} y={1} width={S - 2} height={S - 2} fill="#FFFDF6" stroke={colors.maroon} strokeWidth={2} />
        <Line x1={0} y1={0} x2={S} y2={S} stroke={colors.maroon} strokeWidth={1.5} />
        <Line x1={S} y1={0} x2={0} y2={S} stroke={colors.maroon} strokeWidth={1.5} />
        <Polygon points={`${S / 2},1 ${S - 1},${S / 2} ${S / 2},${S - 1} 1,${S / 2}`} fill="none" stroke={colors.maroon} strokeWidth={1.5} />
        {SIGN_AT.map(([x, y], h) => (
          <SvgText key={'s' + h} x={x * S} y={y * S + 4} fontSize={S * 0.035} fill={colors.saffronDark} textAnchor="middle" fontWeight="bold">
            {((lagnaSign + h) % 12) + 1}
          </SvgText>
        ))}
        {CENTERS.map(([x, y], h) => {
          const items = houses[h] || [];
          const lh = S * 0.045;
          const top = y * S - ((items.length - 1) * lh) / 2 + 4;
          return items.map((p, j) => (
            <SvgText key={`p${h}-${j}`} x={x * S} y={top + j * lh} fontSize={S * 0.04} fill={colors.maroon} textAnchor="middle" fontWeight="bold">{p}</SvgText>
          ));
        })}
      </Svg>
    </View>
  );
}
