import React, { useMemo, useRef, useState } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { captureRef } from 'react-native-view-shot';
import Share from 'react-native-share';
import { Button } from './ui';
import { panchangFor, cityFor, fmtIST, fmtISTWithDay } from '../lib/panchang';
import { speak, stopSpeaking } from '../lib/voice';
import { FESTIVALS } from '../content/catalog';
import { playLink } from '../lib/config';
import { s, fmt, getLanguage } from '../i18n';
import { colors, fonts, radius, shadow } from '../theme';

const ymd = (x: Date) => `${x.getFullYear()}-${String(x.getMonth() + 1).padStart(2, '0')}-${String(x.getDate()).padStart(2, '0')}`;

export default function PanchangCard({ region }: { region: string | null }) {
  const t = s().panchang;
  const hi = getLanguage() !== 'en';
  const p = useMemo(() => panchangFor(new Date(), cityFor(region)), [region, ymd(new Date())]);
  const todays = FESTIVALS.filter((f) => f.date === ymd(new Date())).map((f) => f.name);
  const ref = useRef<View>(null);
  const [talking, setTalking] = useState(false);

  const paksha = p.paksha === 'Shukla' ? t.shukla : t.krishna;
  const tithi = hi ? p.tithiHi : p.tithi;
  const rows: [string, string][] = [
    [t.tithi, `${tithi} · ${paksha}\n${fmt(t.till, { t: fmtISTWithDay(p.tithiEnd, new Date(), t.days) })}`],
    [t.month, hi ? p.monthHi : p.month],
    [t.nakshatra, `${hi ? p.nakshatraHi : p.nakshatra}\n${fmt(t.till, { t: fmtISTWithDay(p.nakshatraEnd, new Date(), t.days) })}`],
    [t.yoga, hi ? p.yogaHi : p.yoga],
    [t.sunrise, `${fmtIST(p.sunrise)}   ·   ${t.sunset} ${fmtIST(p.sunset)}`],
    [t.rahu, p.rahuKaal ? `${fmtIST(p.rahuKaal[0])} – ${fmtIST(p.rahuKaal[1])}` : '—'],
  ];
  const dateLabel = new Date().toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });

  const share = async () => {
    try {
      const uri = await captureRef(ref, { format: 'jpg', quality: 0.95, width: 1080, result: 'tmpfile' });
      await Share.open({ url: uri, type: 'image/jpeg', message: fmt(t.shareCaption, { link: playLink('panchang') }), failOnCancel: false });
    } catch {}
  };
  const listen = () => {
    if (talking) { stopSpeaking(); setTalking(false); return; }
    setTalking(true);
    speak(`${t.title}. ${dateLabel}. ${rows.map(([k, v]) => `${k}: ${v}`).join('. ')}`, { onDone: () => setTalking(false) });
  };

  return (
    <View style={{ marginBottom: 20 }}>
      <View ref={ref} collapsable={false} style={st.card}>
        <Text style={st.title}>🪔 {t.title}</Text>
        <Text style={st.date}>{dateLabel}</Text>
        {todays.length ? <Text style={st.fest}>{fmt(t.todayFest, { f: todays.join(', ') })}</Text> : null}
        <View style={{ marginTop: 10 }}>
          {rows.map(([k, v]) => (
            <View key={k} style={st.row}>
              <Text style={st.k}>{k}</Text>
              <Text style={st.v}>{v}</Text>
            </View>
          ))}
        </View>
        <Text style={st.city}>{fmt(t.forCity, { city: p.city.name })} · Bhakti Alarm</Text>
      </View>
      <View style={{ flexDirection: 'row', marginTop: 10 }}>
        <Button icon="💬" label={t.share} onPress={share} style={{ flex: 1, marginRight: 8, backgroundColor: '#25A244' }} />
        <Button kind="secondary" icon={talking ? '⏹️' : '🔊'} label={talking ? s().lyrics.stop : t.listen} onPress={listen} style={{ flex: 0.8 }} />
      </View>
    </View>
  );
}

const st = StyleSheet.create({
  card: { backgroundColor: '#7A1400', borderRadius: radius.md, padding: 18, ...shadow },
  title: { fontFamily: fonts.bold, fontSize: 24, color: '#FFE2B8' },
  date: { fontFamily: fonts.medium, fontSize: 16, color: '#FFF3D6', marginTop: 2 },
  fest: { fontFamily: fonts.bold, fontSize: 17, color: '#FFD27A', marginTop: 8 },
  row: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 7, borderBottomWidth: 1, borderBottomColor: 'rgba(255,226,184,0.15)' },
  k: { fontFamily: fonts.medium, fontSize: 16, color: '#FFD9A8', flex: 0.9 },
  v: { fontFamily: fonts.bold, fontSize: 16, color: '#FFFFFF', flex: 1.4, textAlign: 'right' },
  city: { fontFamily: fonts.regular, fontSize: 12, color: 'rgba(255,226,184,0.7)', marginTop: 10 },
});
