import React from 'react';
import { Pressable, Text, View, StyleSheet, ViewStyle, TextStyle, StyleProp, ScrollView } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { colors, fonts, size, radius, shadow } from '../theme';

export function Screen({ children, scroll = true, style }: { children: React.ReactNode; scroll?: boolean; style?: StyleProp<ViewStyle> }) {
  return (
    <SafeAreaView edges={['top']} style={{ flex: 1, backgroundColor: colors.cream }}>
      {scroll ? (
        <ScrollView contentContainerStyle={[{ padding: 20, paddingBottom: 40 }, style]} keyboardShouldPersistTaps="handled">{children}</ScrollView>
      ) : (<View style={[{ flex: 1 }, style]}>{children}</View>)}
    </SafeAreaView>
  );
}

export function Title({ children, sub }: { children: React.ReactNode; sub?: string }) {
  return (
    <View style={{ marginBottom: 18 }}>
      <Text style={st.title}>{children}</Text>
      {sub ? <Text style={st.sub}>{sub}</Text> : null}
      <View style={st.rule} />
    </View>
  );
}

export function T({ children, style, bold, soft, big }: { children: React.ReactNode; style?: StyleProp<TextStyle>; bold?: boolean; soft?: boolean; big?: boolean }) {
  return <Text style={[{ fontFamily: bold ? fonts.bold : fonts.regular, fontSize: big ? size.h2 : size.body, color: soft ? colors.textSoft : colors.text, lineHeight: (big ? size.h2 : size.body) * 1.4 }, style]}>{children}</Text>;
}

type BtnProps = { label: string; onPress: () => void; kind?: 'primary' | 'secondary' | 'ghost' | 'danger'; icon?: string; style?: StyleProp<ViewStyle>; disabled?: boolean; big?: boolean };
export function Button({ label, onPress, kind = 'primary', icon, style, disabled, big }: BtnProps) {
  const bg = kind === 'primary' ? colors.saffron : kind === 'danger' ? colors.maroon : kind === 'secondary' ? colors.white : 'transparent';
  const fg = kind === 'secondary' || kind === 'ghost' ? colors.maroon : colors.white;
  return (
    <Pressable
      accessibilityRole="button" accessibilityLabel={label} disabled={disabled} onPress={onPress}
      style={({ pressed }) => [
        st.btn, { backgroundColor: bg, opacity: disabled ? 0.5 : pressed ? 0.85 : 1, minHeight: big ? 68 : size.tap },
        kind === 'secondary' && { borderWidth: 2, borderColor: colors.saffron }, kind !== 'ghost' && shadow, style,
      ]}>
      {icon ? <Text style={{ fontSize: big ? 26 : 22, marginRight: 10 }}>{icon}</Text> : null}
      <Text style={{ color: fg, fontFamily: fonts.bold, fontSize: big ? 22 : size.body }}>{label}</Text>
    </Pressable>
  );
}

export function Card({ children, style, onPress }: { children: React.ReactNode; style?: StyleProp<ViewStyle>; onPress?: () => void }) {
  const inner = <View style={[st.card, style]}>{children}</View>;
  return onPress ? <Pressable onPress={onPress} style={({ pressed }) => ({ opacity: pressed ? 0.85 : 1 })}>{inner}</Pressable> : inner;
}

export function Chip({ label, selected, onPress, style }: { label: string; selected?: boolean; onPress: () => void; style?: StyleProp<ViewStyle> }) {
  return (
    <Pressable onPress={onPress} accessibilityState={{ selected }} style={[st.chip, selected && { backgroundColor: colors.saffron, borderColor: colors.saffron }, style]}>
      <Text style={{ fontFamily: fonts.medium, fontSize: size.small, color: selected ? colors.white : colors.text }}>{label}</Text>
    </Pressable>
  );
}

export function Row({ label, value, onPress, right }: { label: string; value?: string; onPress?: () => void; right?: React.ReactNode }) {
  return (
    <Pressable onPress={onPress} disabled={!onPress} style={({ pressed }) => [st.row, pressed && { backgroundColor: colors.creamDeep }]}>
      <View style={{ flex: 1, paddingRight: 8 }}>
        <T bold>{label}</T>
        {value ? <T soft style={{ fontSize: size.small }}>{value}</T> : null}
      </View>
      {right ?? (onPress ? <Text style={{ fontSize: 26, color: colors.saffron }}>›</Text> : null)}
    </Pressable>
  );
}

export function Toggle({ value, onChange }: { value: boolean; onChange: (v: boolean) => void }) {
  return (
    <Pressable onPress={() => onChange(!value)} accessibilityRole="switch" accessibilityState={{ checked: value }}
      style={[st.toggle, { backgroundColor: value ? colors.saffron : '#D9C7AE' }]}>
      <View style={[st.knob, { alignSelf: value ? 'flex-end' : 'flex-start' }]} />
    </Pressable>
  );
}

const st = StyleSheet.create({
  title: { fontFamily: fonts.bold, fontSize: size.title, color: colors.maroon },
  sub: { fontFamily: fonts.regular, fontSize: size.small, color: colors.textSoft, marginTop: 4 },
  rule: { height: 3, width: 56, backgroundColor: colors.gold, borderRadius: 2, marginTop: 10 },
  btn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', borderRadius: radius.lg, paddingHorizontal: 22 },
  card: { backgroundColor: colors.card, borderRadius: radius.md, padding: 16, ...shadow, borderWidth: 1, borderColor: colors.border },
  chip: { paddingHorizontal: 16, minHeight: 44, justifyContent: 'center', borderRadius: 22, borderWidth: 1.5, borderColor: colors.border, backgroundColor: colors.white, marginRight: 8, marginBottom: 8 },
  row: { flexDirection: 'row', alignItems: 'center', paddingVertical: 16, paddingHorizontal: 4, minHeight: 64, borderBottomWidth: 1, borderBottomColor: colors.border },
  toggle: { width: 64, height: 36, borderRadius: 18, padding: 4, justifyContent: 'center' },
  knob: { width: 28, height: 28, borderRadius: 14, backgroundColor: colors.white },
});
