import * as Speech from 'expo-speech';
import { getLanguage } from '../i18n';

const TTS_LANG: Record<string, string> = { en: 'en-IN', hi: 'hi-IN', gu: 'gu-IN', mr: 'mr-IN', pa: 'pa-IN', bn: 'bn-IN', ta: 'ta-IN' };
export const ttsLang = (lang?: string) => TTS_LANG[lang || getLanguage()] || 'hi-IN';

/** Read text aloud, slowly and clearly. Detects Devanagari and uses a Hindi voice for it. */
export function speak(text: string, opts: { lang?: string; onDone?: () => void } = {}) {
  Speech.stop();
  const lang = opts.lang || (/[\u0900-\u097F]/.test(text) ? 'hi-IN' : ttsLang());
  Speech.speak(text, { language: lang, rate: 0.9, pitch: 1.0, onDone: opts.onDone, onStopped: opts.onDone, onError: opts.onDone as any });
}
export const stopSpeaking = () => Speech.stop();
export const isSpeaking = () => Speech.isSpeakingAsync();
