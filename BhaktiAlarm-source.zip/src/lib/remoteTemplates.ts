// Extra greeting backgrounds hosted on the app website, so new pictures arrive without an app update.
// The bundled ones still work offline; these fill in once the list has been fetched (cached for a day).
import { useEffect, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import type { Template } from '../content/catalog';

export const REMOTE_BASE = 'https://bhaktialarm.vercel.app/greetings/';
const KEY = 'bhakti.remoteTemplates.v1';
type Item = { id: string; category: Template['category']; festival?: string | null; file: string };

let remote: Template[] = [];
let loading: Promise<Template[]> | null = null;
const listeners = new Set<(t: Template[]) => void>();

const toTemplates = (items: Item[]): Template[] => items.map((i) => ({
  id: i.id, category: i.category, festival: i.festival ?? null, header: null, footer: null, regions: [], deityId: null,
  source: { uri: REMOTE_BASE + i.file } as any,
}));

export const getRemoteTemplates = () => remote;

export function loadRemoteTemplates(): Promise<Template[]> {
  if (loading) return loading;
  loading = (async () => {
    let cached: { at: number; items: Item[] } | null = null;
    try { const raw = await AsyncStorage.getItem(KEY); if (raw) cached = JSON.parse(raw); } catch {}
    if (cached) { remote = toTemplates(cached.items); listeners.forEach((l) => l(remote)); }
    if (!cached || Date.now() - cached.at > 24 * 3600e3) {
      try {
        const res = await fetch(REMOTE_BASE + 'index.json', { headers: { 'Cache-Control': 'no-cache' } });
        if (res.ok) {
          const j = await res.json();
          const items: Item[] = Array.isArray(j.items) ? j.items : [];
          await AsyncStorage.setItem(KEY, JSON.stringify({ at: Date.now(), items }));
          remote = toTemplates(items); listeners.forEach((l) => l(remote));
        }
      } catch {}
    }
    return remote;
  })();
  return loading;
}

export function useRemoteTemplates() {
  const [list, setList] = useState<Template[]>(remote);
  useEffect(() => {
    listeners.add(setList);
    loadRemoteTemplates().then(setList);
    return () => { listeners.delete(setList); };
  }, []);
  return list;
}
