import React from 'react';
import { View, Linking } from 'react-native';
import mobileAds, { AdsConsent, AdsConsentPrivacyOptionsRequirementStatus, BannerAd, BannerAdSize, InterstitialAd, AdEventType } from 'react-native-google-mobile-ads';
import { AD_UNITS, ADS_ENABLED, INTERSTITIAL_MIN_GAP_MS, PRIVACY_POLICY_URL } from './config';
import { colors } from '../theme';

let initialised = false;
let canRequest = false;
let interstitial: InterstitialAd | null = null;
let loaded = false;
let lastShown = 0;
const listeners = new Set<(v: boolean) => void>();

function loadInterstitial() {
  if (!AD_UNITS.interstitial || !canRequest) return;
  try {
    interstitial = InterstitialAd.createForAdRequest(AD_UNITS.interstitial, { requestNonPersonalizedAdsOnly: true });
    interstitial.addAdEventListener(AdEventType.LOADED, () => { loaded = true; });
    interstitial.addAdEventListener(AdEventType.CLOSED, () => { loaded = false; loadInterstitial(); });
    interstitial.addAdEventListener(AdEventType.ERROR, () => { loaded = false; });
    interstitial.load();
  } catch {}
}

/** UMP consent first (GDPR/EEA message from the AdMob console), then the SDK. Ads only when consent allows. */
export async function initAds() {
  if (initialised) return;
  initialised = true;
  try {
    const info = await AdsConsent.gatherConsent();
    canRequest = !!info.canRequestAds;
  } catch {
    // Consent form failed (offline etc.): still allowed if a previous session obtained consent.
    try { canRequest = !!(await AdsConsent.getConsentInfo()).canRequestAds; } catch { canRequest = false; }
  }
  if (!canRequest || !ADS_ENABLED) return;
  try { await mobileAds().initialize(); listeners.forEach((l) => l(true)); loadInterstitial(); } catch {}
}

/** True when the user must be offered a "Privacy settings" entry (EEA/UK users). */
export async function privacyOptionsRequired(): Promise<boolean> {
  try {
    const info = await AdsConsent.getConsentInfo();
    return info.privacyOptionsRequirementStatus === AdsConsentPrivacyOptionsRequirementStatus.REQUIRED;
  } catch { return false; }
}

/** Privacy settings: the UMP privacy options form where required, otherwise the privacy policy. */
export async function openPrivacySettings() {
  if (await privacyOptionsRequired()) {
    try {
      const info = await AdsConsent.showPrivacyOptionsForm();
      canRequest = !!info.canRequestAds;
      return;
    } catch {}
  }
  Linking.openURL(PRIVACY_POLICY_URL).catch(() => {});
}

/** Only call at natural break points (after a download, between temple visits). Never on alarm/darshan screens. */
export function maybeShowInterstitial() {
  const now = Date.now();
  if (!canRequest || !interstitial || !loaded || now - lastShown < INTERSTITIAL_MIN_GAP_MS) return;
  lastShown = now;
  try { interstitial.show(); } catch {}
}

/** Takes no space until an ad actually loads, so no blank strip when AdMob has nothing to show. */
export function Banner() {
  const [ready, setReady] = React.useState(canRequest && ADS_ENABLED);
  const [shown, setShown] = React.useState(false);
  React.useEffect(() => { listeners.add(setReady); return () => { listeners.delete(setReady); }; }, []);
  if (!ready || !AD_UNITS.banner) return null;
  return (
    <View style={{ alignItems: 'center', backgroundColor: colors.cream, minHeight: shown ? 50 : 0 }}>
      <BannerAd unitId={AD_UNITS.banner} size={BannerAdSize.ANCHORED_ADAPTIVE_BANNER} requestOptions={{ requestNonPersonalizedAdsOnly: true }}
        onAdLoaded={() => setShown(true)} onAdFailedToLoad={() => setShown(false)} />
    </View>
  );
}
