import React from 'react';
import { View, Linking, useWindowDimensions } from 'react-native';
import { AdsConsent, AdsConsentPrivacyOptionsRequirementStatus } from 'react-native-google-mobile-ads';
import {
  LevelPlay, LevelPlayInitRequest, LevelPlayPrivacySettings, LevelPlayInterstitialAd, LevelPlayBannerAdView, LevelPlayAdSize,
  type LevelPlayBannerAdViewMethods,
} from 'unity-levelplay-mediation';
import { LEVELPLAY, INTERSTITIAL_MIN_GAP_MS, PRIVACY_POLICY_URL } from './config';
import { colors } from '../theme';

// Consent: Google's UMP message (configured in the AdMob console) runs first; its answer is passed to LevelPlay.
// Ads: Unity LevelPlay serves banner + interstitial. Debug builds run LevelPlay's test suite-safe defaults.

let initialised = false;
let canRequest = false;
let sdkReady = false;
let interstitial: LevelPlayInterstitialAd | null = null;
let loaded = false;
let lastShown = 0;
const listeners = new Set<(v: boolean) => void>();

function loadInterstitial() {
  if (!sdkReady || !LEVELPLAY.interstitial) return;
  try {
    if (!interstitial) {
      interstitial = new LevelPlayInterstitialAd(LEVELPLAY.interstitial);
      interstitial.setListener({
        onAdLoaded: () => { loaded = true; },
        onAdLoadFailed: () => { loaded = false; setTimeout(loadInterstitial, 60_000); },
        onAdInfoChanged: () => {},
        onAdDisplayed: () => {},
        onAdDisplayFailed: () => { loaded = false; loadInterstitial(); },
        onAdClicked: () => {},
        onAdClosed: () => { loaded = false; loadInterstitial(); },
      });
    }
    interstitial.loadAd();
  } catch {}
}

async function passConsentToLevelPlay() {
  try {
    const gdpr = await AdsConsent.getGdprApplies();
    if (!gdpr) { await LevelPlayPrivacySettings.setGDPRConsent(true); return; }
    const c = await AdsConsent.getUserChoices();
    await LevelPlayPrivacySettings.setGDPRConsent(!!(c.storeAndAccessInformationOnDevice && c.selectPersonalisedAds));
  } catch {
    try { await LevelPlayPrivacySettings.setGDPRConsent(false); } catch {}
  }
  try { await LevelPlayPrivacySettings.setCOPPA(false); } catch {}
}

/** UMP consent first, then LevelPlay. Ads only when consent allows requesting them. */
export async function initAds() {
  if (initialised) return;
  initialised = true;
  try {
    const info = await AdsConsent.gatherConsent();
    canRequest = !!info.canRequestAds;
  } catch {
    try { canRequest = !!(await AdsConsent.getConsentInfo()).canRequestAds; } catch { canRequest = false; }
  }
  if (!canRequest || !LEVELPLAY.appKey) return;
  await passConsentToLevelPlay();
  try {
    const req = LevelPlayInitRequest.builder(LEVELPLAY.appKey).build();
    await LevelPlay.init(req, {
      onInitSuccess: () => { sdkReady = true; listeners.forEach((l) => l(true)); loadInterstitial(); },
      onInitFailed: () => { sdkReady = false; },
    });
  } catch {}
}

/** True when the user must be offered a "Privacy settings" entry (EEA/UK users). */
export async function privacyOptionsRequired(): Promise<boolean> {
  try {
    const info = await AdsConsent.getConsentInfo();
    return info.privacyOptionsRequirementStatus === AdsConsentPrivacyOptionsRequirementStatus.REQUIRED;
  } catch { return false; }
}

/** Privacy settings: the UMP privacy options form where required, otherwise the privacy policy. */
export async function openPrivacySettings() {
  if (await privacyOptionsRequired()) {
    try {
      const info = await AdsConsent.showPrivacyOptionsForm();
      canRequest = !!info.canRequestAds;
      if (sdkReady) await passConsentToLevelPlay();
      return;
    } catch {}
  }
  Linking.openURL(PRIVACY_POLICY_URL).catch(() => {});
}

/** Only call at natural break points (after a download, between temple visits). Never on alarm/darshan screens. */
export function maybeShowInterstitial() {
  const now = Date.now();
  if (!canRequest || !sdkReady || !interstitial || !loaded || now - lastShown < INTERSTITIAL_MIN_GAP_MS) return;
  lastShown = now;
  loaded = false;
  interstitial.showAd().catch(() => {});
}

/** Standard 320x50 banner. Takes no space until an ad actually loads. */
export function Banner() {
  const [ready, setReady] = React.useState(sdkReady);
  const [shown, setShown] = React.useState(false);
  const ref = React.useRef<LevelPlayBannerAdViewMethods>(null);
  const { width } = useWindowDimensions();
  React.useEffect(() => { listeners.add(setReady); return () => { listeners.delete(setReady); }; }, []);
  React.useEffect(() => () => { try { ref.current?.destroy(); } catch {} }, []);
  if (!ready || !LEVELPLAY.banner) return null;
  const size = LevelPlayAdSize.BANNER;
  return (
    <View style={{ alignItems: 'center', backgroundColor: colors.cream, height: shown ? size.height : 1, overflow: 'hidden' }}>
      <LevelPlayBannerAdView
        ref={ref}
        adUnitId={LEVELPLAY.banner}
        adSize={size}
        placementName={null}
        style={{ width: Math.min(size.width, width), height: size.height }}
        listener={{
          onAdLoaded: () => setShown(true),
          onAdLoadFailed: () => setShown(false),
          onAdDisplayed: () => {},
          onAdDisplayFailed: () => {},
          onAdClicked: () => {},
          onAdExpanded: () => {},
          onAdCollapsed: () => {},
          onAdLeftApplication: () => {},
        }}
        onLayout={() => ref.current?.loadAd()}
      />
    </View>
  );
}
