import React from 'react';
import { View } from 'react-native';
import mobileAds, { BannerAd, BannerAdSize, InterstitialAd, AdEventType } from 'react-native-google-mobile-ads';
import { AD_UNITS, INTERSTITIAL_MIN_GAP_MS } from './config';
import { colors } from '../theme';

let initialised = false;
let interstitial: InterstitialAd | null = null;
let loaded = false;
let lastShown = 0;

function loadInterstitial() {
  try {
    interstitial = InterstitialAd.createForAdRequest(AD_UNITS.interstitial, { requestNonPersonalizedAdsOnly: true });
    interstitial.addAdEventListener(AdEventType.LOADED, () => { loaded = true; });
    interstitial.addAdEventListener(AdEventType.CLOSED, () => { loaded = false; loadInterstitial(); });
    interstitial.addAdEventListener(AdEventType.ERROR, () => { loaded = false; });
    interstitial.load();
  } catch {}
}

export async function initAds() {
  if (initialised) return;
  initialised = true;
  try { await mobileAds().initialize(); loadInterstitial(); } catch {}
}

/** Only call at natural break points (after a download, between temple visits). Never on alarm/darshan screens. */
export function maybeShowInterstitial() {
  const now = Date.now();
  if (!interstitial || !loaded || now - lastShown < INTERSTITIAL_MIN_GAP_MS) return;
  lastShown = now;
  try { interstitial.show(); } catch {}
}

export function Banner() {
  return (
    <View style={{ alignItems: 'center', backgroundColor: colors.cream, minHeight: 50 }}>
      <BannerAd unitId={AD_UNITS.banner} size={BannerAdSize.ANCHORED_ADAPTIVE_BANNER} requestOptions={{ requestNonPersonalizedAdsOnly: true }} />
    </View>
  );
}
