// Monthly tithi reminders (every Ekadashi, Purnima, ...). Dates come from festivals.json where it lists
// that observance (Drik Panchang, New Delhi); otherwise from the tithi at sunrise computed on the phone.
// We keep a rolling 60-day window of DATE notifications and refresh it on every app open.
import * as Notifications from 'expo-notifications';
import { Platform } from 'react-native';
import { FESTIVALS } from '../content/catalog';
import { panchangFor, cityFor, fmtISTWithDay, tithiIndexAt } from './panchang';
import type { Prefs } from './prefs';
import { s, fmt, readsHindi } from '../i18n';

export type TithiKey = 'ekadashi' | 'purnima' | 'amavasya' | 'sankashti' | 'vinayaka' | 'pradosh' | 'shivratri' | 'durgashtami';
type Opt = { key: TithiKey; tithis: number[]; data?: RegExp };
// tithi index 0..29: 0 = Shukla Pratipada ... 14 = Purnima, 15 = Krishna Pratipada ... 29 = Amavasya
export const TITHI_OPTIONS: Opt[] = [
  { key: 'ekadashi', tithis: [10, 25], data: /ekadashi/i },
  { key: 'purnima', tithis: [14], data: /purnima/i },
  { key: 'amavasya', tithis: [29], data: /amavasya/i },
  { key: 'sankashti', tithis: [18], data: /sankashti/i },
  { key: 'pradosh', tithis: [12, 27], data: /pradosh/i },
  { key: 'vinayaka', tithis: [3] },
  { key: 'shivratri', tithis: [28] },
  { key: 'durgashtami', tithis: [7] },
];
export const CHANNEL = 'tithi-reminders';
const WINDOW_DAYS = 60;
const DATA_END = FESTIVALS.reduce((m, f) => (f.date > m ? f.date : m), '');

const ymd = (x: Date) => `${x.getFullYear()}-${String(x.getMonth() + 1).padStart(2, '0')}-${String(x.getDate()).padStart(2, '0')}`;
const noonIST = (date: string) => { const [y, m, d] = date.split('-').map(Number); return new Date(Date.UTC(y, m - 1, d, 6, 30)); };

/** Dates ('YYYY-MM-DD') in [from, to] when this observance falls. */
export function datesFor(opt: Opt, from: string, to: string, region?: string | null): string[] {
  const out = new Set<string>();
  if (opt.data) {
    for (const f of FESTIVALS) if (opt.data.test(f.name) && f.date >= from && f.date <= to) out.add(f.date);
  }
  // Compute days the data does not cover (or every day for options without data).
  const city = cityFor(region);
  const [y, m, d] = from.split('-').map(Number);
  for (let i = 0; i < 400; i++) {
    const dd = new Date(Date.UTC(y, m - 1, d + i));
    const date = dd.toISOString().slice(0, 10);
    if (date > to) break;
    if (opt.data && date <= DATA_END) continue;
    if (opt.tithis.includes(panchangFor(noonIST(date), city).tithiIndex)) out.add(date);
  }
  // Purnima/Ekadashi can be listed on two days (vrat and snan / smarta and vaishnava): keep the first.
  const sorted = [...out].sort();
  return sorted.filter((x, i) => i === 0 || Date.parse(x) - Date.parse(sorted[i - 1]) > 86400e3);
}

function label(key: string) { return (s().tithiRem.options as Record<string, string>)[key] || key; }

async function ensureChannel() {
  if (Platform.OS !== 'android') return;
  await Notifications.setNotificationChannelAsync(CHANNEL, { name: s().tithiRem.channel, importance: Notifications.AndroidImportance.DEFAULT });
}

/** Cancel and re-create the next 60 days of tithi reminders. Safe to call often. */
export async function refreshTithiReminders(prefs: Pick<Prefs, 'tithiReminders' | 'tithiReminderTime' | 'region'>) {
  const all = await Notifications.getAllScheduledNotificationsAsync();
  await Promise.all(all.filter((n) => (n.content.data as any)?.tithiReminder).map((n) => Notifications.cancelScheduledNotificationAsync(n.identifier)));
  const keys = prefs.tithiReminders || [];
  if (!keys.length) return;
  if (!(await Notifications.getPermissionsAsync()).granted) return;
  await ensureChannel();
  const t = s().tithiRem, tp = s().panchang;
  const now = new Date();
  const from = ymd(now), to = ymd(new Date(now.getTime() + WINDOW_DAYS * 86400e3));
  const city = cityFor(prefs.region);
  const deva = readsHindi();
  for (const key of keys) {
    const opt = TITHI_OPTIONS.find((o) => o.key === key);
    if (!opt) continue;
    for (const date of datesFor(opt, from, to, prefs.region)) {
      const [y, m, d] = date.split('-').map(Number);
      const when = prefs.tithiReminderTime === 'morn' ? new Date(y, m - 1, d, 6, 0) : new Date(y, m - 1, d - 1, 18, 0);
      if (when.getTime() <= Date.now()) continue;
      // Tithi start / end around that day's sunrise, for the body text.
      const p = panchangFor(noonIST(date), city);
      const at = p.sunrise || noonIST(date);
      let startT = new Date(at.getTime() - 30 * 3600e3);
      // walk forward to the start of the running tithi (end of the previous one)
      const idx = tithiIndexAt(at);
      let lo = startT.getTime(), hi = at.getTime();
      if (tithiIndexAt(new Date(lo)) !== idx) {
        for (let i = 0; i < 24; i++) { const mid = (lo + hi) / 2; if (tithiIndexAt(new Date(mid)) === idx) hi = mid; else lo = mid; }
        startT = new Date(hi);
      }
      const ref = new Date(Date.UTC(y, m - 1, d, 6, 30));
      const body = fmt(t.body, {
        tithi: deva ? p.tithiHi : p.tithi,
        start: fmtISTWithDay(startT, ref, tp.days), end: fmtISTWithDay(p.tithiEnd, ref, tp.days),
      });
      await Notifications.scheduleNotificationAsync({
        content: { title: fmt(prefs.tithiReminderTime === 'morn' ? t.titleMorn : t.titleEve, { name: label(key) }), body, data: { tithiReminder: true, key, date } },
        trigger: { type: Notifications.SchedulableTriggerInputTypes.DATE, date: when, channelId: CHANNEL },
      });
    }
  }
}
