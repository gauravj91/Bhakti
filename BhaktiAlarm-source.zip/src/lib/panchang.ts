// Daily panchang computed on device (no network). Times are for the chosen city, shown in IST.
// Accuracy: tithi / nakshatra / yoga at sunrise with Lahiri ayanamsa; usually matches published
// panchangs, but can differ near a boundary. Adhik maas is not detected.
import * as A from 'astronomy-engine';

export const TITHIS = ['Pratipada', 'Dwitiya', 'Tritiya', 'Chaturthi', 'Panchami', 'Shashthi', 'Saptami', 'Ashtami', 'Navami', 'Dashami', 'Ekadashi', 'Dwadashi', 'Trayodashi', 'Chaturdashi', 'Purnima'];
export const TITHIS_HI = ['प्रतिपदा', 'द्वितीया', 'तृतीया', 'चतुर्थी', 'पंचमी', 'षष्ठी', 'सप्तमी', 'अष्टमी', 'नवमी', 'दशमी', 'एकादशी', 'द्वादशी', 'त्रयोदशी', 'चतुर्दशी', 'पूर्णिमा'];
export const NAKSHATRAS = ['Ashwini', 'Bharani', 'Krittika', 'Rohini', 'Mrigashira', 'Ardra', 'Punarvasu', 'Pushya', 'Ashlesha', 'Magha', 'Purva Phalguni', 'Uttara Phalguni', 'Hasta', 'Chitra', 'Swati', 'Vishakha', 'Anuradha', 'Jyeshtha', 'Mula', 'Purva Ashadha', 'Uttara Ashadha', 'Shravana', 'Dhanishta', 'Shatabhisha', 'Purva Bhadrapada', 'Uttara Bhadrapada', 'Revati'];
export const NAKSHATRAS_HI = ['अश्विनी', 'भरणी', 'कृत्तिका', 'रोहिणी', 'मृगशिरा', 'आर्द्रा', 'पुनर्वसु', 'पुष्य', 'आश्लेषा', 'मघा', 'पूर्वा फाल्गुनी', 'उत्तरा फाल्गुनी', 'हस्त', 'चित्रा', 'स्वाति', 'विशाखा', 'अनुराधा', 'ज्येष्ठा', 'मूल', 'पूर्वाषाढ़ा', 'उत्तराषाढ़ा', 'श्रवण', 'धनिष्ठा', 'शतभिषा', 'पूर्वा भाद्रपद', 'उत्तरा भाद्रपद', 'रेवती'];
export const YOGAS = ['Vishkambha', 'Priti', 'Ayushman', 'Saubhagya', 'Shobhana', 'Atiganda', 'Sukarma', 'Dhriti', 'Shula', 'Ganda', 'Vriddhi', 'Dhruva', 'Vyaghata', 'Harshana', 'Vajra', 'Siddhi', 'Vyatipata', 'Variyana', 'Parigha', 'Shiva', 'Siddha', 'Sadhya', 'Shubha', 'Shukla', 'Brahma', 'Indra', 'Vaidhriti'];
export const YOGAS_HI = ['विष्कम्भ', 'प्रीति', 'आयुष्मान', 'सौभाग्य', 'शोभन', 'अतिगण्ड', 'सुकर्मा', 'धृति', 'शूल', 'गण्ड', 'वृद्धि', 'ध्रुव', 'व्याघात', 'हर्षण', 'वज्र', 'सिद्धि', 'व्यतीपात', 'वरीयान', 'परिघ', 'शिव', 'सिद्ध', 'साध्य', 'शुभ', 'शुक्ल', 'ब्रह्म', 'इन्द्र', 'वैधृति'];
// Lunar month named by the sidereal sign of the sun at the new moon that starts it (amanta).
export const MONTHS = ['Vaishakha', 'Jyeshtha', 'Ashadha', 'Shravana', 'Bhadrapada', 'Ashwin', 'Kartika', 'Margashirsha', 'Pausha', 'Magha', 'Phalguna', 'Chaitra'];
export const MONTHS_HI = ['वैशाख', 'ज्येष्ठ', 'आषाढ़', 'श्रावण', 'भाद्रपद', 'आश्विन', 'कार्तिक', 'मार्गशीर्ष', 'पौष', 'माघ', 'फाल्गुन', 'चैत्र'];

export type City = { name: string; lat: number; lon: number };
export const REGION_CITY: Record<string, City> = {
  gujarat: { name: 'Ahmedabad', lat: 23.0225, lon: 72.5714 },
  maharashtra: { name: 'Mumbai', lat: 19.076, lon: 72.8777 },
  'west-bengal': { name: 'Kolkata', lat: 22.5726, lon: 88.3639 },
  'tamil-nadu': { name: 'Chennai', lat: 13.0827, lon: 80.2707 },
  'uttar-pradesh': { name: 'Lucknow', lat: 26.8467, lon: 80.9462 },
  bihar: { name: 'Patna', lat: 25.5941, lon: 85.1376 },
  rajasthan: { name: 'Jaipur', lat: 26.9124, lon: 75.7873 },
  punjab: { name: 'Chandigarh', lat: 30.7333, lon: 76.7794 },
  haryana: { name: 'Chandigarh', lat: 30.7333, lon: 76.7794 },
  delhi: { name: 'New Delhi', lat: 28.6139, lon: 77.209 },
  'madhya-pradesh': { name: 'Bhopal', lat: 23.2599, lon: 77.4126 },
  karnataka: { name: 'Bengaluru', lat: 12.9716, lon: 77.5946 },
  kerala: { name: 'Thiruvananthapuram', lat: 8.5241, lon: 76.9366 },
  'andhra-pradesh': { name: 'Vijayawada', lat: 16.5062, lon: 80.648 },
  telangana: { name: 'Hyderabad', lat: 17.385, lon: 78.4867 },
  odisha: { name: 'Bhubaneswar', lat: 20.2961, lon: 85.8245 },
  assam: { name: 'Guwahati', lat: 26.1445, lon: 91.7362 },
};
export const cityFor = (region?: string | null): City => (region && REGION_CITY[region]) || REGION_CITY.delhi;

const norm = (x: number) => ((x % 360) + 360) % 360;
function ayanamsa(d: Date) { // Lahiri, linear approximation (good to ~0.01° this century)
  const years = (d.getTime() - Date.UTC(2000, 0, 1, 12)) / (365.25 * 86400e3);
  return 23.85306 + years * 0.0139694;
}
function lons(d: Date) {
  const sun = A.SunPosition(d).elon;
  const moon = A.EclipticGeoMoon(d).lon;
  const ay = ayanamsa(d);
  return { sun, moon, sunSid: norm(sun - ay), moonSid: norm(moon - ay) };
}

export type Panchang = {
  date: Date; city: City;
  sunrise: Date | null; sunset: Date | null;
  paksha: 'Shukla' | 'Krishna'; tithiIndex: number; tithi: string; tithiHi: string;
  nakshatraIndex: number; nakshatra: string; nakshatraHi: string;
  yoga: string; yogaHi: string;
  month: string; monthHi: string;           // purnimanta (North Indian) month
  rahuKaal: [Date, Date] | null; abhijit: [Date, Date] | null;
};

/** Panchang for the given civil day (IST) at the given city. */
export function panchangFor(day: Date, city: City): Panchang {
  const obs = new A.Observer(city.lat, city.lon, 0);
  // Midnight IST of that day.
  const ist = new Date(day.getTime() + 5.5 * 3600e3);
  const start = new Date(Date.UTC(ist.getUTCFullYear(), ist.getUTCMonth(), ist.getUTCDate()) - 5.5 * 3600e3);
  const rise = A.SearchRiseSet(A.Body.Sun, obs, +1, start, 1)?.date ?? null;
  const set = A.SearchRiseSet(A.Body.Sun, obs, -1, start, 1)?.date ?? null;
  const at = rise || new Date(start.getTime() + 6 * 3600e3);
  const L = lons(at);

  const elong = norm(L.moon - L.sun);
  const t = Math.floor(elong / 12); // 0..29
  const paksha = t < 15 ? 'Shukla' : 'Krishna';
  const ti = t < 15 ? t : t - 15; // 0..14 (14 = Purnima / Amavasya)
  const isAmavasya = t === 29;
  const nk = Math.floor(L.moonSid / (360 / 27));
  const yg = Math.floor(norm(L.sunSid + L.moonSid) / (360 / 27));

  // Month: sun's sidereal sign at the previous new moon gives the amanta month.
  const nm = A.SearchMoonPhase(0, new Date(at.getTime() - 32 * 86400e3), 40);
  let prevNew = nm?.date ?? at;
  // make sure we have the latest new moon before `at`
  for (let i = 0; i < 2; i++) {
    const nxt = A.SearchMoonPhase(0, new Date(prevNew.getTime() + 86400e3), 40);
    if (nxt && nxt.date.getTime() <= at.getTime()) prevNew = nxt.date; else break;
  }
  const sign = Math.floor(lons(prevNew).sunSid / 30); // 0 = Mesha
  let m = sign; // Mesha -> Vaishakha (index 0)
  if (paksha === 'Krishna') m = (m + 1) % 12; // purnimanta: dark half belongs to the next month

  let rahu: [Date, Date] | null = null, abh: [Date, Date] | null = null;
  if (rise && set) {
    const len = set.getTime() - rise.getTime();
    const wd = new Date(start.getTime() + 12 * 3600e3 + 5.5 * 3600e3).getUTCDay(); // weekday in IST
    const part = [8, 2, 7, 5, 6, 4, 3][wd] - 1;
    rahu = [new Date(rise.getTime() + (len / 8) * part), new Date(rise.getTime() + (len / 8) * (part + 1))];
    abh = [new Date(rise.getTime() + (len / 15) * 7), new Date(rise.getTime() + (len / 15) * 8)];
  }

  return {
    date: start, city, sunrise: rise, sunset: set,
    paksha, tithiIndex: t,
    tithi: isAmavasya ? 'Amavasya' : TITHIS[ti], tithiHi: isAmavasya ? 'अमावस्या' : TITHIS_HI[ti],
    nakshatraIndex: nk, nakshatra: NAKSHATRAS[nk], nakshatraHi: NAKSHATRAS_HI[nk],
    yoga: YOGAS[yg], yogaHi: YOGAS_HI[yg],
    month: MONTHS[m], monthHi: MONTHS_HI[m],
    rahuKaal: rahu, abhijit: abh,
  };
}

export function fmtIST(d: Date | null) {
  if (!d) return '—';
  const x = new Date(d.getTime() + 5.5 * 3600e3);
  let h = x.getUTCHours(); const mm = String(x.getUTCMinutes()).padStart(2, '0');
  const ap = h < 12 ? 'AM' : 'PM'; h = h % 12 || 12;
  return `${h}:${mm} ${ap}`;
}
