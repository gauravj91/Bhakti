import { TestIds } from 'react-native-google-mobile-ads';

/** Replace with the real Play Store link once the listing is live. */
export const PLAY_STORE_LINK = 'https://play.google.com/store/apps/details?id=com.gauravj.bhaktialarm';
export const PLAY_STORE_SHORT = 'play.google.com/store/apps/details?id=com.gauravj.bhaktialarm';

/** Real AdMob unit ids. Empty until AdMob finishes reviewing the live app; while empty, release builds show no ads. */
const REAL_UNITS = {
  banner: '',
  interstitial: '',
};
/** Debug builds always use Google's test units; release uses the real ones (or none). */
export const AD_UNITS = __DEV__
  ? { banner: TestIds.ADAPTIVE_BANNER, interstitial: TestIds.INTERSTITIAL }
  : REAL_UNITS;
export const ADS_ENABLED = !!(AD_UNITS.banner || AD_UNITS.interstitial);
export const PRIVACY_POLICY_URL = 'https://docs.google.com/document/d/e/2PACX-1vQ0S91TSlohXuPUb6tK0DRqTyUMjfFa_PG3JzHLAgcsUlqWvN1WJGVx1jbyIVqdhxVlD92VyQ02vtBx/pub';
/** Minimum gap between interstitials, so ads never feel spammy. */
export const INTERSTITIAL_MIN_GAP_MS = 3 * 60 * 1000;
