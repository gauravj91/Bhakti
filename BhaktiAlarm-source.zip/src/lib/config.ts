import { TestIds } from 'react-native-google-mobile-ads';

/** Replace with the real Play Store link once the listing is live. */
export const PLAY_STORE_LINK = 'https://play.google.com/store/apps/details?id=com.bhaktialarm.app';
/** Play link tagged with where the share came from, so Play Console > Acquisition shows which shares bring installs. */
export const playLink = (campaign: string) =>
  `${PLAY_STORE_LINK}&referrer=${encodeURIComponent(`utm_source=bhakti_app&utm_medium=share&utm_campaign=${campaign}`)}`;
/** Feedback inbox (public business address, same as the website). */
export const FEEDBACK_EMAIL = 'solutions@techcruisers.com';
export const PLAY_STORE_SHORT = 'play.google.com/store/apps/details?id=com.bhaktialarm.app';

/** Real AdMob unit ids. Empty until AdMob finishes reviewing the live app; while empty, release builds show no ads. */
const REAL_UNITS = {
  banner: '',
  interstitial: '',
};
/** Debug builds always use Google's test units; release uses the real ones (or none). */
export const AD_UNITS = __DEV__
  ? { banner: TestIds.ADAPTIVE_BANNER, interstitial: TestIds.INTERSTITIAL }
  : REAL_UNITS;
export const ADS_ENABLED = !!(AD_UNITS.banner || AD_UNITS.interstitial);

/** Unity LevelPlay (live ad provider while AdMob reviews the app). Org 6872903714608, app "Bhakti Alarm". */
export const LEVELPLAY = {
  appKey: '28e623c4d',
  banner: '64lhx8s052bq0iqu',
  interstitial: '735i8f44lqakg45f',
};
export const PRIVACY_POLICY_URL = 'https://docs.google.com/document/d/e/2PACX-1vQ0S91TSlohXuPUb6tK0DRqTyUMjfFa_PG3JzHLAgcsUlqWvN1WJGVx1jbyIVqdhxVlD92VyQ02vtBx/pub';
/** Minimum gap between interstitials, so ads never feel spammy. */
export const INTERSTITIAL_MIN_GAP_MS = 3 * 60 * 1000;
