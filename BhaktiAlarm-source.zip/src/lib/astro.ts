// Vedic (sidereal, Lahiri) positions computed on the phone with astronomy-engine.
// Used for Rashifal (gochar from the Moon sign) and Kundali (birth chart). For guidance only.
import * as A from 'astronomy-engine';

export const RASHIS = ['Mesh', 'Vrishabh', 'Mithun', 'Kark', 'Simha', 'Kanya', 'Tula', 'Vrishchik', 'Dhanu', 'Makar', 'Kumbh', 'Meen'];
export const RASHIS_HI = ['मेष', 'वृषभ', 'मिथुन', 'कर्क', 'सिंह', 'कन्या', 'तुला', 'वृश्चिक', 'धनु', 'मकर', 'कुंभ', 'मीन'];
export const RASHIS_EN = ['Aries', 'Taurus', 'Gemini', 'Cancer', 'Leo', 'Virgo', 'Libra', 'Scorpio', 'Sagittarius', 'Capricorn', 'Aquarius', 'Pisces'];
export const RASHI_SYMBOL = ['♈', '♉', '♊', '♋', '♌', '♍', '♎', '♏', '♐', '♑', '♒', '♓'];
/** Traditional naam akshar (first sound of the name) for each rashi. */
export const RASHI_AKSHAR = [
  'चू चे चो ला ली लू ले लो अ', 'इ उ ए ओ वा वी वू वे वो', 'का की कू घ ङ छ के को हा', 'ही हू हे हो डा डी डू डे डो',
  'मा मी मू मे मो टा टी टू टे', 'टो पा पी पू ष ण ठ पे पो', 'रा री रू रे रो ता ती तू ते', 'तो ना नी नू ने नो या यी यू',
  'ये यो भा भी भू धा फा ढा भे', 'भो जा जी खी खू खे खो गा गी', 'गू गे गो सा सी सू से सो दा', 'दी दू थ झ ञ दे दो चा ची',
];
export const RASHI_AKSHAR_EN = [
  'Chu Che Cho La Li Lu Le Lo A', 'I U E O Va Vi Vu Ve Vo', 'Ka Ki Ku Gha Chha Ke Ko Ha', 'Hi Hu He Ho Da Di Du De Do',
  'Ma Mi Mu Me Mo Ta Ti Tu Te', 'To Pa Pi Pu Sha Na Tha Pe Po', 'Ra Ri Ru Re Ro Ta Ti Tu Te', 'To Na Ni Nu Ne No Ya Yi Yu',
  'Ye Yo Bha Bhi Bhu Dha Pha Dha Bhe', 'Bho Ja Ji Khi Khu Khe Kho Ga Gi', 'Gu Ge Go Sa Si Su Se So Da', 'Di Du Tha Jha Na De Do Cha Chi',
];
/** Lord of each sign: index into PLANETS. */
export const RASHI_LORD = [2, 5, 3, 1, 0, 3, 5, 2, 4, 6, 6, 4];

export const PLANETS = ['Sun', 'Moon', 'Mars', 'Mercury', 'Jupiter', 'Venus', 'Saturn', 'Rahu', 'Ketu'] as const;
export const PLANETS_HI = ['सूर्य', 'चंद्र', 'मंगल', 'बुध', 'गुरु', 'शुक्र', 'शनि', 'राहु', 'केतु'];
export const PLANET_ABBR = ['Su', 'Mo', 'Ma', 'Me', 'Ju', 'Ve', 'Sa', 'Ra', 'Ke'];
export const PLANET_ABBR_HI = ['सू', 'चं', 'मं', 'बु', 'गु', 'शु', 'श', 'रा', 'के'];
export type Planet = (typeof PLANETS)[number];

export const NAKSHATRAS = ['Ashwini', 'Bharani', 'Krittika', 'Rohini', 'Mrigashira', 'Ardra', 'Punarvasu', 'Pushya', 'Ashlesha', 'Magha', 'Purva Phalguni', 'Uttara Phalguni', 'Hasta', 'Chitra', 'Swati', 'Vishakha', 'Anuradha', 'Jyeshtha', 'Mula', 'Purva Ashadha', 'Uttara Ashadha', 'Shravana', 'Dhanishta', 'Shatabhisha', 'Purva Bhadrapada', 'Uttara Bhadrapada', 'Revati'];
export const NAKSHATRAS_HI = ['अश्विनी', 'भरणी', 'कृत्तिका', 'रोहिणी', 'मृगशिरा', 'आर्द्रा', 'पुनर्वसु', 'पुष्य', 'आश्लेषा', 'मघा', 'पूर्वा फाल्गुनी', 'उत्तरा फाल्गुनी', 'हस्त', 'चित्रा', 'स्वाति', 'विशाखा', 'अनुराधा', 'ज्येष्ठा', 'मूल', 'पूर्वाषाढ़ा', 'उत्तराषाढ़ा', 'श्रवण', 'धनिष्ठा', 'शतभिषा', 'पूर्वा भाद्रपद', 'उत्तरा भाद्रपद', 'रेवती'];

const norm = (x: number) => ((x % 360) + 360) % 360;
const rad = Math.PI / 180;
const centuries = (d: Date) => (d.getTime() - Date.UTC(2000, 0, 1, 12)) / (36525 * 86400e3);

/** Lahiri ayanamsa, linear approximation (good to ~0.01° for 1900-2100). */
export function ayanamsa(d: Date) {
  const years = (d.getTime() - Date.UTC(2000, 0, 1, 12)) / (365.25 * 86400e3);
  return 23.85306 + years * 0.0139694;
}

function tropicalLon(i: number, d: Date): number {
  switch (i) {
    case 0: return A.SunPosition(d).elon;
    case 1: return A.EclipticGeoMoon(d).lon;
    case 7: { // mean lunar node (Rahu)
      const T = centuries(d);
      return norm(125.04452 - 1934.136261 * T + 0.0020708 * T * T);
    }
    case 8: return norm(tropicalLon(7, d) + 180);
    default: {
      const body = [null, null, A.Body.Mars, A.Body.Mercury, A.Body.Jupiter, A.Body.Venus, A.Body.Saturn][i]!;
      return A.Ecliptic(A.GeoVector(body, d, true)).elon;
    }
  }
}
/** Sidereal longitude (0..360) of planet index i. */
export const sidLon = (i: number, d: Date) => norm(tropicalLon(i, d) - ayanamsa(d));
export const signOf = (lon: number) => Math.floor(norm(lon) / 30);
export const moonSign = (d: Date) => signOf(sidLon(1, d));

/** House counted from `from` sign to `to` sign, 1..12 (1 = same sign). */
export const houseFrom = (from: number, to: number) => ((to - from + 12) % 12) + 1;

/** Sidereal ascendant (lagna) longitude for a moment and place. */
export function ascendant(d: Date, lat: number, lon: number) {
  const T = centuries(d);
  const eps = (23.4392911 - 0.0130042 * T) * rad;
  const lst = norm(A.SiderealTime(d) * 15 + lon) * rad; // RAMC
  const asc = Math.atan2(Math.cos(lst), -(Math.sin(lst) * Math.cos(eps) + Math.tan(lat * rad) * Math.sin(eps))) / rad;
  return norm(norm(asc) - ayanamsa(d));
}

export type PlanetPos = { i: number; lon: number; sign: number; deg: number; nak: number; pada: number; retro: boolean; house: number };
export type Kundali = {
  birth: Date; lat: number; lon: number;
  lagna: number; lagnaSign: number;
  planets: PlanetPos[];
  moonSign: number; moonNak: number; moonPada: number;
  manglik: boolean;
  dashas: Dasha[];
};
export type Dasha = { lord: number; start: Date; end: Date; antar: { lord: number; start: Date; end: Date }[] };

const NAK = 360 / 27;
// Vimshottari: lords (planet index) and years, starting from Ketu.
const VIM_LORDS = [8, 5, 0, 1, 2, 7, 4, 6, 3];
const VIM_YEARS = [7, 20, 6, 10, 7, 18, 16, 19, 17];
const YEAR_MS = 365.25 * 86400e3;

function vimshottari(birth: Date, moonLon: number): Dasha[] {
  const nak = Math.floor(moonLon / NAK);
  const frac = (moonLon - nak * NAK) / NAK; // part of the nakshatra already passed
  let k = nak % 9;
  let t = birth.getTime() - frac * VIM_YEARS[k] * YEAR_MS; // dasha started before birth
  const out: Dasha[] = [];
  for (let n = 0; n < 10; n++) {
    const lord = VIM_LORDS[k], len = VIM_YEARS[k] * YEAR_MS;
    const antar = [] as Dasha['antar'];
    let a = t;
    for (let j = 0; j < 9; j++) {
      const kk = (k + j) % 9;
      const al = (len * VIM_YEARS[kk]) / 120;
      antar.push({ lord: VIM_LORDS[kk], start: new Date(a), end: new Date(a + al) });
      a += al;
    }
    out.push({ lord, start: new Date(t), end: new Date(t + len), antar });
    t += len; k = (k + 1) % 9;
  }
  return out;
}

export function kundaliFor(birth: Date, lat: number, lon: number): Kundali {
  const lagna = ascendant(birth, lat, lon);
  const lagnaSign = signOf(lagna);
  const later = new Date(birth.getTime() + 86400e3);
  const planets: PlanetPos[] = PLANETS.map((_, i) => {
    const l = sidLon(i, birth);
    let retro = false;
    if (i >= 2 && i <= 6) retro = norm(sidLon(i, later) - l + 180) - 180 < 0;
    if (i >= 7) retro = true; // nodes always move backwards
    const sign = signOf(l);
    const nak = Math.floor(l / NAK);
    return { i, lon: l, sign, deg: l - sign * 30, nak, pada: Math.floor((l - nak * NAK) / (NAK / 4)) + 1, retro, house: houseFrom(lagnaSign, sign) };
  });
  const moon = planets[1];
  const marsH = planets[2].house;
  const marsFromMoon = houseFrom(moon.sign, planets[2].sign);
  const bad = [1, 4, 7, 8, 12];
  return {
    birth, lat, lon, lagna, lagnaSign, planets,
    moonSign: moon.sign, moonNak: moon.nak, moonPada: moon.pada,
    manglik: bad.includes(marsH) || bad.includes(marsFromMoon),
    dashas: vimshottari(birth, moon.lon),
  };
}

/** The maha and antar dasha running at `at`. */
export function currentDasha(k: Kundali, at = new Date()) {
  const maha = k.dashas.find((d) => d.start <= at && at < d.end);
  const antar = maha?.antar.find((d) => d.start <= at && at < d.end);
  return { maha, antar };
}

/** Moment in UTC for a local civil date-time at a fixed UTC offset (hours). */
export function birthMoment(y: number, m: number, d: number, hh: number, mm: number, offsetHours: number) {
  return new Date(Date.UTC(y, m - 1, d, hh, mm) - offsetHours * 3600e3);
}
