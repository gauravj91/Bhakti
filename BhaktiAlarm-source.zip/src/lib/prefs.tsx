import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

export type Prefs = {
  onboarded: boolean;
  region: string | null;
  familyDeity: string | null;
  footer: string | null;          // remembered footer text, e.g. "— Ramesh & Family"
  footerAskedFor: string | null;  // last footer we asked about (avoid nagging)
  lastFooters: string[];          // recent footers used, to detect repeats
  reminders: string[];            // festival ids with day-before reminder
  reminderNotifIds: Record<string, string>;
  language: string;               // 'en' | 'hi' | ...
  languageChosen: boolean;        // asked on first launch
  textScale: number;              // 1, 1.2, 1.4
  jaap: { mantraId: string; today: string; todayCount: number; total: number; target: number };
  path: { last: string | null; streak: number; best: number; done: string[] }; // daily aarti/chalisa habit
  family: FamilyDate[];
  familyNotifIds: Record<string, string>;
  vratReminders: boolean;         // evening-before reminders for vrats
  dailyDarshanEnabled: boolean;   // "Aaj ka darshan" morning notification
  dailyDarshanHour: number;       // 5 | 6 | 7 | 8 (local time)
  notifPermAsked: boolean;        // asked once for notification permission after onboarding
  autostartGuideDismissed: boolean; // OEM autostart / battery guide on the Alarm list
  tithiReminders: string[];        // TithiKey[]: monthly tithi reminders
  tithiReminderTime: 'eve' | 'morn';
};
export type FamilyDate = { id: string; name: string; relation: string; kind: 'birthday' | 'anniversary'; month: number; day: number };
const DEFAULTS: Prefs = { onboarded: false, region: null, familyDeity: null, footer: null, footerAskedFor: null, lastFooters: [], reminders: [], reminderNotifIds: {},
  language: 'en', languageChosen: false, textScale: 1,
  jaap: { mantraId: 'ram', today: '', todayCount: 0, total: 0, target: 108 },
  path: { last: null, streak: 0, best: 0, done: [] },
  family: [], familyNotifIds: {}, vratReminders: false,
  dailyDarshanEnabled: true, dailyDarshanHour: 7, notifPermAsked: false, autostartGuideDismissed: false, tithiReminders: [], tithiReminderTime: 'eve' };
const KEY = 'bhakti.prefs.v1';

type Ctx = { prefs: Prefs; ready: boolean; update: (p: Partial<Prefs>) => Promise<void> };
const PrefsContext = createContext<Ctx>({ prefs: DEFAULTS, ready: false, update: async () => {} });

export function PrefsProvider({ children }: { children: React.ReactNode }) {
  const [prefs, setPrefs] = useState<Prefs>(DEFAULTS);
  const [ready, setReady] = useState(false);
  useEffect(() => {
    AsyncStorage.getItem(KEY).then((raw) => {
      if (raw) { try { setPrefs({ ...DEFAULTS, ...JSON.parse(raw) }); } catch {} }
      setReady(true);
    });
  }, []);
  const update = useCallback(async (p: Partial<Prefs>) => {
    setPrefs((prev) => {
      const next = { ...prev, ...p };
      AsyncStorage.setItem(KEY, JSON.stringify(next));
      return next;
    });
  }, []);
  return <PrefsContext.Provider value={{ prefs, ready, update }}>{children}</PrefsContext.Provider>;
}
export const usePrefs = () => useContext(PrefsContext);
