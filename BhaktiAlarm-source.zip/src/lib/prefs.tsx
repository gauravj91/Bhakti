import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

export type Prefs = {
  onboarded: boolean;
  region: string | null;
  familyDeity: string | null;
  footer: string | null;          // remembered footer text, e.g. "— Ramesh & Family"
  footerAskedFor: string | null;  // last footer we asked about (avoid nagging)
  lastFooters: string[];          // recent footers used, to detect repeats
  reminders: string[];            // festival ids with day-before reminder
  reminderNotifIds: Record<string, string>;
};
const DEFAULTS: Prefs = { onboarded: false, region: null, familyDeity: null, footer: null, footerAskedFor: null, lastFooters: [], reminders: [], reminderNotifIds: {} };
const KEY = 'bhakti.prefs.v1';

type Ctx = { prefs: Prefs; ready: boolean; update: (p: Partial<Prefs>) => Promise<void> };
const PrefsContext = createContext<Ctx>({ prefs: DEFAULTS, ready: false, update: async () => {} });

export function PrefsProvider({ children }: { children: React.ReactNode }) {
  const [prefs, setPrefs] = useState<Prefs>(DEFAULTS);
  const [ready, setReady] = useState(false);
  useEffect(() => {
    AsyncStorage.getItem(KEY).then((raw) => {
      if (raw) { try { setPrefs({ ...DEFAULTS, ...JSON.parse(raw) }); } catch {} }
      setReady(true);
    });
  }, []);
  const update = useCallback(async (p: Partial<Prefs>) => {
    setPrefs((prev) => {
      const next = { ...prev, ...p };
      AsyncStorage.setItem(KEY, JSON.stringify(next));
      return next;
    });
  }, []);
  return <PrefsContext.Provider value={{ prefs, ready, update }}>{children}</PrefsContext.Provider>;
}
export const usePrefs = () => useContext(PrefsContext);
