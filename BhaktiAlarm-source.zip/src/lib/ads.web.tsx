// Web preview only: shows where the banner sits.
import React from 'react';
import { View, Text } from 'react-native';
export async function initAds() {}
export function maybeShowInterstitial() {}
export function Banner() {
  return (
    <View style={{ alignItems: 'center', justifyContent: 'center', backgroundColor: '#EEE', height: 50, borderTopWidth: 1, borderColor: '#DDD' }}>
      <Text style={{ color: '#999', fontSize: 12 }}>Ad banner (test)</Text>
    </View>
  );
}
