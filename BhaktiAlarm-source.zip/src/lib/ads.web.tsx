// Web preview only: shows where the banner sits.
import React from 'react';
import { View, Text } from 'react-native';
export async function initAds() {}
export function maybeShowInterstitial() {}
export function Banner() {
  // Store screenshots: hide the placeholder when ?shots=1 (or localStorage flag) is set.
  if (typeof window !== 'undefined' && (window.location.search.includes('shots=1') || window.localStorage?.getItem('bhakti.shots') === '1')) return null;
  return (
    <View style={{ alignItems: 'center', justifyContent: 'center', backgroundColor: '#EEE', height: 50, borderTopWidth: 1, borderColor: '#DDD' }}>
      <Text style={{ color: '#999', fontSize: 12 }}>Ad banner (test)</Text>
    </View>
  );
}
export async function privacyOptionsRequired() { return false; }
export async function openPrivacySettings() {}
