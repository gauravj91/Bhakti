// "Aaj ka darshan": one gentle morning notification per day with the deity of the day,
// the tithi (computed on the phone for the user's region city, at sunrise) and any festival.
// We keep a rolling 14-day window of DATE notifications; refreshing is cheap and idempotent.
import * as Notifications from 'expo-notifications';
import { Platform } from 'react-native';
import { FESTIVALS, Festival, deityById, prominence } from '../content/catalog';
import { panchangFor, cityFor, Panchang } from './panchang';
import { ensureNotificationPermission } from './reminders';
import type { Prefs } from './prefs';
import { s, fmt, readsHindi } from '../i18n';

export const DARSHAN_CHANNEL = 'daily-darshan';
const DAYS = 14;
export const DARSHAN_HOURS = [5, 6, 7, 8];

/** Deity of the day by weekday (0 = Sunday). Sunday is the family deity, else Ganesh. */
const WEEKDAY_DEITY = ['', 'shiva', 'hanuman', 'ganesh', 'krishna', 'lakshmi', 'hanuman'];
export function deityForWeekday(weekday: number, familyDeity?: string | null): string {
  const id = weekday === 0 ? familyDeity || 'ganesh' : WEEKDAY_DEITY[weekday];
  return deityById(id) ? id : 'ganesh';
}

export const ymd = (x: Date) => `${x.getFullYear()}-${String(x.getMonth() + 1).padStart(2, '0')}-${String(x.getDate()).padStart(2, '0')}`;
const parseYmd = (v: string) => { const [y, m, d] = v.split('-').map(Number); return { y, m, d }; };

/** Localized deity name for the deity of the day. */
export function deityName(id: string): string {
  const names = s().darshan.deities as Record<string, string>;
  return names[id] || deityById(id)?.name || id;
}

/** Major festivals and vrats on that date (multi-day festivals count on every day), most prominent first. */
export function festivalsOn(date: string, region?: string | null): Festival[] {
  return FESTIVALS
    .filter((f) => (f.major || f.type === 'vrat') && (f.date === date || (!!f.endDate && f.date <= date && date <= f.endDate)))
    .sort((a, b) => prominence(b, region) - prominence(a, region));
}

export type DayDarshan = {
  date: string; weekday: number; deityId: string; deityName: string;
  panchang: Panchang; tithiLine: string; festivals: Festival[];
};

/** Everything shown for one calendar date ('YYYY-MM-DD'). */
export function darshanFor(date: string, prefs: Pick<Prefs, 'region' | 'familyDeity'>): DayDarshan {
  const { y, m, d } = parseYmd(date);
  const weekday = new Date(y, m - 1, d).getDay();
  // Noon IST of that date, so the panchang day is right whatever the phone's own time zone is.
  const p = panchangFor(new Date(Date.UTC(y, m - 1, d, 6, 30)), cityFor(prefs.region));
  const deityId = deityForWeekday(weekday, prefs.familyDeity);
  const deva = readsHindi();
  const paksha = p.paksha === 'Shukla' ? (deva ? 'शुक्ल' : 'Shukla') : (deva ? 'कृष्ण' : 'Krishna');
  const tithiLine = deva ? `${p.monthHi} ${paksha} ${p.tithiHi}` : `${p.month} ${paksha} ${p.tithi}`;
  return { date, weekday, deityId, deityName: deityName(deityId), panchang: p, tithiLine, festivals: festivalsOn(date, prefs.region) };
}

function contentFor(x: DayDarshan) {
  const t = s().darshan;
  const fest = x.festivals.slice(0, 2).map((f) => f.name).join(', ');
  return {
    title: fmt(t.notifTitle, { deity: x.deityName }),
    body: fest ? `${x.tithiLine} · ${fmt(t.todayIs, { f: fest })}` : x.tithiLine,
  };
}

async function ensureChannel() {
  if (Platform.OS !== 'android') return;
  await Notifications.setNotificationChannelAsync(DARSHAN_CHANNEL, {
    name: s().darshan.channel, importance: Notifications.AndroidImportance.DEFAULT,
  });
}

async function run(prefs: Prefs, enabled: boolean, askPermission: boolean) {
  const all = await Notifications.getAllScheduledNotificationsAsync();
  const existing = all.filter((n) => (n.content.data as any)?.dailyDarshan);
  const cancelAll = () => Promise.all(existing.map((n) => Notifications.cancelScheduledNotificationAsync(n.identifier)));
  if (!enabled) { await cancelAll(); return; }

  const granted = askPermission ? await ensureNotificationPermission() : (await Notifications.getPermissionsAsync()).granted;
  if (!granted) return;
  await ensureChannel();

  const hour = DARSHAN_HOURS.includes(prefs.dailyDarshanHour) ? prefs.dailyDarshanHour : 7;
  const now = new Date();
  const wanted: { when: Date; key: string; date: string; deityId: string; title: string; body: string }[] = [];
  for (let i = 0; i < DAYS + 1 && wanted.length < DAYS; i++) {
    const day = new Date(now.getFullYear(), now.getMonth(), now.getDate() + i, hour, 0, 0);
    if (day.getTime() <= now.getTime() + 60e3) continue; // today's time already passed
    const x = darshanFor(ymd(day), prefs);
    const c = contentFor(x);
    wanted.push({ when: day, date: x.date, deityId: x.deityId, ...c, key: `${x.date}|${hour}|${c.title}|${c.body}` });
  }

  // Keep notifications that are already correct; replace the rest. Makes frequent refreshes cheap.
  const keyOf = (n: Notifications.NotificationRequest) => {
    const d: any = n.content.data;
    return `${d?.date}|${d?.hour}|${n.content.title}|${n.content.body}`;
  };
  const wantedKeys = new Set(wanted.map((w) => w.key));
  const keep = new Set<string>();
  for (const n of existing) {
    const k = keyOf(n);
    if (wantedKeys.has(k) && !keep.has(k)) keep.add(k);
    else await Notifications.cancelScheduledNotificationAsync(n.identifier);
  }
  for (const w of wanted) {
    if (keep.has(w.key)) continue;
    await Notifications.scheduleNotificationAsync({
      content: { title: w.title, body: w.body, data: { dailyDarshan: true, date: w.date, deityId: w.deityId, hour } },
      trigger: { type: Notifications.SchedulableTriggerInputTypes.DATE, date: w.when, channelId: DARSHAN_CHANNEL },
    });
  }
}

let chain: Promise<void> = Promise.resolve();
/**
 * Cancels earlier daily-darshan notifications (data.dailyDarshan) that no longer match and schedules
 * the next 14 mornings at prefs.dailyDarshanHour. Calls are serialized so overlapping refreshes
 * (app start + app active + a setting change) never create duplicates.
 * By default it only checks permission; pass askPermission to show the system prompt.
 */
export function refreshDailyDarshan(prefs: Prefs, enabled: boolean, askPermission = false): Promise<void> {
  chain = chain.then(() => run(prefs, enabled, askPermission)).catch(() => {});
  return chain;
}
