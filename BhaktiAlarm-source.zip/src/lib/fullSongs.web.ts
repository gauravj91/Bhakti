export const FULL_SONGS_BASE = 'https://raw.githubusercontent.com/gauravj91/Bhakti/main/songs/';
export async function fullSongSource(id: string): Promise<{ uri: string } | null> { return null; }
