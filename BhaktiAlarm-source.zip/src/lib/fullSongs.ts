import { File, Directory, Paths } from 'expo-file-system';

/**
 * Full aarti/chalisa songs are NOT bundled (they would add ~70 MB).
 * They are streamed from FULL_SONGS_BASE/<lyric-id>.mp3 on first play and cached on the phone.
 * Today that is the public GitHub repo's songs/ folder; move to a CDN before a big launch.
 */
export const FULL_SONGS_BASE = 'https://raw.githubusercontent.com/gauravj91/Bhakti/main/songs/';

const dir = () => new Directory(Paths.document, 'songs');
const cached = (id: string) => new File(dir(), `${id}.mp3`);
const pending = new Set<string>();

/** Local file if cached, else the stream URL if the song exists online, else null. */
export async function fullSongSource(id: string): Promise<{ uri: string } | null> {
  try {
    const f = cached(id);
    if (f.exists && (f.size ?? 0) > 10000) return { uri: f.uri };
  } catch (e) {}
  const url = FULL_SONGS_BASE + encodeURIComponent(id) + '.mp3';
  try {
    const r = await fetch(url, { method: 'HEAD' });
    if (!r.ok) return null;
  } catch (e) {
    return null; // offline
  }
  cacheInBackground(id, url);
  return { uri: url };
}

function cacheInBackground(id: string, url: string) {
  if (pending.has(id)) return;
  pending.add(id);
  (async () => {
    try {
      const d = dir();
      if (!d.exists) d.create({ intermediates: true });
      const f = cached(id);
      if (f.exists) f.delete();
      await File.downloadFileAsync(url, f);
    } catch (e) {
      try { const f = cached(id); if (f.exists) f.delete(); } catch (_) {}
    } finally {
      pending.delete(id);
    }
  })();
}
