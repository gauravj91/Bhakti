import * as Notifications from 'expo-notifications';
import { Platform } from 'react-native';
import { Festival } from '../content/catalog';
import { s, fmt } from '../i18n';

Notifications.setNotificationHandler({
  handleNotification: async () => ({ shouldShowBanner: true, shouldShowList: true, shouldPlaySound: true, shouldSetBadge: false }),
});

export async function ensureNotificationPermission() {
  if (Platform.OS === 'android') {
    await Notifications.setNotificationChannelAsync('festival-reminders', {
      name: 'Festival reminders', importance: Notifications.AndroidImportance.DEFAULT,
    });
  }
  const cur = await Notifications.getPermissionsAsync();
  if (cur.granted) return true;
  const req = await Notifications.requestPermissionsAsync();
  return req.granted;
}

/** Schedules a reminder at 8:00 AM local time the day before the festival. Returns notification id or null. */
export async function scheduleFestivalReminder(f: Festival): Promise<string | null> {
  if (!(await ensureNotificationPermission())) return null;
  const [y, m, d] = f.date.split('-').map(Number);
  const when = new Date(y, m - 1, d - 1, 8, 0, 0);
  if (when.getTime() < Date.now()) return null;
  return Notifications.scheduleNotificationAsync({
    content: {
      title: fmt(s().calendar.reminderTitle, { f: f.name }),
      body: s().calendar.reminderBody,
      data: { festivalId: f.id, greetingCategory: f.greetingCategory, name: f.name },
    },
    trigger: { type: Notifications.SchedulableTriggerInputTypes.DATE, date: when, channelId: 'festival-reminders' },
  });
}
export async function cancelReminder(id?: string) { if (id) await Notifications.cancelScheduledNotificationAsync(id); }

/** Yearly 8 AM reminder on a family birthday / anniversary. */
export async function scheduleFamilyReminder(f: { id: string; name: string; kind: 'birthday' | 'anniversary'; month: number; day: number }): Promise<string | null> {
  if (!(await ensureNotificationPermission())) return null;
  const t = s().family;
  return Notifications.scheduleNotificationAsync({
    content: {
      title: fmt(f.kind === 'birthday' ? t.reminderTitleB : t.reminderTitleA, { name: f.name }),
      body: t.reminderBody,
      data: { familyId: f.id },
    },
    trigger: { type: Notifications.SchedulableTriggerInputTypes.YEARLY, month: f.month - 1, day: f.day, hour: 8, minute: 0, channelId: 'festival-reminders' },
  });
}

/** 6 PM the evening before a vrat. */
export async function scheduleVratReminder(f: Festival): Promise<string | null> {
  const [y, m, d] = f.date.split('-').map(Number);
  const when = new Date(y, m - 1, d - 1, 18, 0, 0);
  if (when.getTime() < Date.now()) return null;
  return Notifications.scheduleNotificationAsync({
    content: { title: fmt(s().vrat.reminderTitle, { f: f.name }), body: s().vrat.reminderBody, data: { vratFestivalId: f.id } },
    trigger: { type: Notifications.SchedulableTriggerInputTypes.DATE, date: when, channelId: 'festival-reminders' },
  });
}

/** (Re)schedule evening-before reminders for the next 60 days of vrats. Cancels old ones first. */
export async function refreshVratReminders(festivals: Festival[], enabled: boolean) {
  const all = await Notifications.getAllScheduledNotificationsAsync();
  await Promise.all(all.filter((n) => (n.content.data as any)?.vratFestivalId).map((n) => Notifications.cancelScheduledNotificationAsync(n.identifier)));
  if (!enabled || !(await ensureNotificationPermission())) return;
  const now = Date.now(), until = now + 60 * 86400e3;
  for (const f of festivals) {
    const t = new Date(f.date).getTime();
    if (f.type === 'vrat' && t > now && t < until) await scheduleVratReminder(f);
  }
}
