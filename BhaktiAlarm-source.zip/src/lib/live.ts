// Finds what a temple's YouTube channel is streaming right now (checked from the phone).
export const UA = 'Mozilla/5.0 (Linux; Android 14; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Mobile Safari/537.36';
const LIVE_ID = [
  /<link rel="canonical" href="https:\/\/www\.youtube\.com\/watch\?v=([\w-]{11})"/,
  /"videoDetails":\{"videoId":"([\w-]{11})"[^}]*"isLive(?:Content)?":true/,
  /"videoId":"([\w-]{11})"[^{}]{0,400}"isLive":true/,
];
export const VIDEO_IN_URL = /[?&]v=([\w-]{11})/;

/** Quick check (from the phone) for the video the channel is streaming. null = unknown or not live;
 *  the screen then opens the channel's live page itself, which settles it either way. */
export async function findLiveVideo(channelId: string): Promise<string | null> {
  const res = await fetch(`https://www.youtube.com/channel/${channelId}/live?ucbcb=1&hl=en`, {
    credentials: 'omit',
    headers: { 'User-Agent': UA, 'Accept-Language': 'en-US,en;q=0.8', Cookie: 'SOCS=CAI; CONSENT=YES+1' },
  });
  if (VIDEO_IN_URL.test(res.url)) return res.url.match(VIDEO_IN_URL)![1];
  const html = await res.text();
  for (const re of LIVE_ID) { const m = html.match(re); if (m) return m[1]; }
  return null;
}


// Official YouTube embed only; we never download or rehost temple streams.
// YouTube refuses embeds without a referrer/origin (player errors 152/153), so the player page gets a real https base URL.
export const ORIGIN = 'https://bhaktialarm.app';

export const playerHtml = (videoId: string) => `<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><style>html,body{margin:0;background:#000;height:100%;overflow:hidden}#p{width:100%;height:100%}</style></head><body><div id="p"></div>
<script src="https://www.youtube.com/iframe_api"></script>
<script>
function send(m){ if (window.ReactNativeWebView) window.ReactNativeWebView.postMessage(m); }
function onYouTubeIframeAPIReady(){
  new YT.Player('p', { width: '100%', height: '100%', videoId: '${videoId}',
    playerVars: { autoplay: 1, playsinline: 1, rel: 0, modestbranding: 1, origin: '${ORIGIN}' },
    events: { onReady: function(e){ e.target.playVideo(); }, onError: function(e){ send('error:' + e.data); } } });
}
</script></body></html>`;

export const liveThumb = (videoId: string) => `https://i.ytimg.com/vi/${videoId}/hqdefault_live.jpg`;

/** First live temple in the given order, checking a few at a time. Cached for 10 minutes. */
let cache: { at: number; id: string; videoId: string } | null = null;
export async function firstLive<T extends { id: string; channelId: string }>(list: T[]): Promise<{ temple: T; videoId: string } | null> {
  if (cache && Date.now() - cache.at < 10 * 60e3) {
    const t = list.find((x) => x.id === cache!.id);
    if (t) return { temple: t, videoId: cache.videoId };
  }
  for (let i = 0; i < list.length; i += 3) {
    const batch = list.slice(i, i + 3);
    const found = await Promise.all(batch.map((t) => findLiveVideo(t.channelId).catch(() => null)));
    const k = found.findIndex(Boolean);
    if (k >= 0) { cache = { at: Date.now(), id: batch[k].id, videoId: found[k]! }; return { temple: batch[k], videoId: found[k]! }; }
  }
  return null;
}
