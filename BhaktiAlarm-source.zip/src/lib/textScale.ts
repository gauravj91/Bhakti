// "Large text" mode: scales every <Text>/<TextInput> font in the app on top of Android's own font size.
import { Text, TextInput, StyleSheet } from 'react-native';

let scale = 1;
export const getTextScale = () => scale;
export function setTextScale(n: number) { scale = n; }

function patch(Comp: any) {
  if (!Comp || Comp.__bhaktiPatched || typeof Comp.render !== 'function') return;
  const orig = Comp.render;
  Comp.render = function (props: any, ref: any) {
    if (scale === 1) return orig.call(this, props, ref);
    const flat = StyleSheet.flatten(props.style) || {};
    const fs = flat.fontSize ?? 14;
    const extra: any = { fontSize: fs * scale };
    if (flat.lineHeight) extra.lineHeight = flat.lineHeight * scale;
    return orig.call(this, { ...props, style: [props.style, extra] }, ref);
  };
  Comp.__bhaktiPatched = true;
}
patch(Text);
patch(TextInput);

export const TEXT_SIZES = [
  { id: 1, key: 'normal' },
  { id: 1.2, key: 'large' },
  { id: 1.4, key: 'xlarge' },
] as const;
