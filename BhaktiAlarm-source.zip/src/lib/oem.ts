// Phone makers that stop background apps (and so alarms) unless the user allows autostart /
// unrestricted battery. Detected from Platform.constants, no extra dependency.
import { Platform } from 'react-native';

export type OemKey = 'xiaomi' | 'oppo' | 'vivo' | 'oneplus' | 'huawei' | 'samsung' | 'transsion' | 'generic';
export type Oem = { key: OemKey; brand: string };

const RULES: [RegExp, OemKey, string][] = [
  [/poco/, 'xiaomi', 'POCO'],
  [/redmi/, 'xiaomi', 'Redmi'],
  [/xiaomi|^mi$/, 'xiaomi', 'Xiaomi'],
  [/realme/, 'oppo', 'Realme'],
  [/oppo/, 'oppo', 'Oppo'],
  [/iqoo/, 'vivo', 'iQOO'],
  [/vivo/, 'vivo', 'Vivo'],
  [/oneplus/, 'oneplus', 'OnePlus'],
  [/honor/, 'huawei', 'Honor'],
  [/huawei/, 'huawei', 'Huawei'],
  [/samsung/, 'samsung', 'Samsung'],
  [/tecno/, 'transsion', 'Tecno'],
  [/infinix/, 'transsion', 'Infinix'],
  [/itel/, 'transsion', 'itel'],
];

/** The phone's maker if it is one known to block alarms, else null (iOS / web / other brands). */
export function detectOem(): Oem | null {
  if (Platform.OS !== 'android') return null;
  const c: any = (Platform as any).constants || {};
  const names = [c.Brand, c.Manufacturer].filter(Boolean).map((x: string) => String(x).toLowerCase().trim());
  for (const n of names) for (const [re, key, brand] of RULES) if (re.test(n)) return { key, brand };
  return null;
}

/** Same as detectOem but never null, for the "Alarm not ringing?" help that any phone can open. */
export function oemOrGeneric(): Oem {
  return detectOem() ?? { key: 'generic', brand: '' };
}
