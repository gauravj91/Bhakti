// Web preview only: AdMob has no web SDK.
export const PLAY_STORE_LINK = 'https://play.google.com/store/apps/details?id=com.bhaktialarm.app';
export const playLink = (campaign: string) =>
  `${PLAY_STORE_LINK}&referrer=${encodeURIComponent(`utm_source=bhakti_app&utm_medium=share&utm_campaign=${campaign}`)}`;
export const FEEDBACK_EMAIL = 'solutions@techcruisers.com';
export const PLAY_STORE_SHORT = 'play.google.com/store/apps/details?id=com.bhaktialarm.app';
export const AD_UNITS = { banner: 'web', interstitial: 'web' };
export const INTERSTITIAL_MIN_GAP_MS = 3 * 60 * 1000;
