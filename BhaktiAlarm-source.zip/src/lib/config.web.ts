// Web preview only: AdMob has no web SDK.
export const PLAY_STORE_LINK = 'https://play.google.com/store/apps/details?id=com.gauravj.bhaktialarm';
export const PLAY_STORE_SHORT = 'play.google.com/store/apps/details?id=com.gauravj.bhaktialarm';
export const AD_UNITS = { banner: 'web', interstitial: 'web' };
export const INTERSTITIAL_MIN_GAP_MS = 3 * 60 * 1000;
