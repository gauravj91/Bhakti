// Store-screenshot helpers for the web preview only (?screen=…&tab=…&kid=…&live=…). No effect on Android.
import { Platform } from 'react-native';
export function previewParam(name: string): string | null {
  if (Platform.OS !== 'web' || typeof window === 'undefined' || !window.location) return null;
  return new URLSearchParams(window.location.search).get(name);
}
