// Firebase Cloud Messaging: registers this phone so pushes sent from the Firebase console reach it.
// No user data is sent anywhere by the app; FCM holds the device token.
import * as Notifications from 'expo-notifications';
import { Platform } from 'react-native';

export const PUSH_CHANNEL = 'announcements';

export async function registerForPush(names: { channel: string }) {
  if (Platform.OS !== 'android') return null;
  try {
    await Notifications.setNotificationChannelAsync(PUSH_CHANNEL, {
      name: names.channel, importance: Notifications.AndroidImportance.DEFAULT,
    });
    if (!(await Notifications.getPermissionsAsync()).granted) return null;
    const tok = await Notifications.getDevicePushTokenAsync();
    return tok.data as string;
  } catch (e) {
    return null; // no Google Play services, offline, or FCM not configured
  }
}

// Console campaigns can carry custom data "screen" = Radio | Rashifal | LiveDarshan | Wallpaper | Kundali.
export function pushData(r: Notifications.NotificationResponse): Record<string, any> {
  const req: any = r.notification.request;
  return { ...(req.trigger?.remoteMessage?.data || {}), ...(req.content?.data || {}) };
}

export const PUSH_ROUTES: Record<string, { tab: string; screen: string }> = {
  Radio: { tab: 'Temple', screen: 'Radio' },
  LiveDarshan: { tab: 'Home', screen: 'LiveDarshan' },
  Rashifal: { tab: 'Home', screen: 'Rashifal' },
  Kundali: { tab: 'Home', screen: 'Kundali' },
  Mulank: { tab: 'Home', screen: 'Mulank' },
  Wallpaper: { tab: 'Home', screen: 'Wallpaper' },
};
