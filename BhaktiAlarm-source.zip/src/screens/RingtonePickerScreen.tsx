import React, { useEffect, useState } from 'react';
import { View, Image, Pressable, Text } from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';
import { useAudioPlayer } from 'expo-audio';
import { Screen, Title, T, Card } from '../components/ui';
import { orderedDeities, tracksFor, imageForTrack, Track } from '../content/catalog';
import { usePrefs } from '../lib/prefs';
import { s } from '../i18n';
import { colors, fonts, radius } from '../theme';

export default function RingtonePickerScreen() {
  const nav = useNavigation<any>();
  const route = useRoute<any>();
  const { prefs } = usePrefs();
  const [playing, setPlaying] = useState<string | null>(null);
  const player = useAudioPlayer(null);
  const t = s().alarm;

  useEffect(() => () => { try { player.pause(); } catch {} }, []);

  const preview = (tr: Track) => {
    if (playing === tr.id) { player.pause(); setPlaying(null); return; }
    player.replace(tr.source); player.seekTo(0); player.play(); setPlaying(tr.id);
  };
  const choose = (tr: Track) => {
    try { player.pause(); } catch {}
    nav.popTo('AlarmEdit', { pickedTrack: tr.id }, { merge: true });
  };

  return (
    <Screen>
      <Title>{t.ringtone}</Title>
      {orderedDeities(prefs.region, prefs.familyDeity).map((d) => {
        const tracks = tracksFor(d.id);
        if (!tracks.length) return null;
        return (
          <View key={d.id} style={{ marginBottom: 18 }}>
            <T bold big style={{ color: colors.maroon, marginBottom: 8 }}>{d.name}</T>
            {tracks.map((tr) => {
              const sel = route.params?.selected === tr.id;
              const img = imageForTrack(tr, prefs.region);
              return (
                <Card key={tr.id} style={{ marginBottom: 10, flexDirection: 'row', alignItems: 'center', padding: 10, borderColor: sel ? colors.saffron : colors.border, borderWidth: sel ? 2 : 1 }}>
                  {img ? <Image source={img} style={{ width: 64, height: 80, borderRadius: radius.sm }} /> : null}
                  <Pressable onPress={() => choose(tr)} style={{ flex: 1, paddingHorizontal: 12, minHeight: 64, justifyContent: 'center' }}>
                    <T bold>{tr.title}</T>
                    <T soft style={{ fontSize: 15 }}>{sel ? '✓ ' : ''}{t.choose}</T>
                  </Pressable>
                  <Pressable onPress={() => preview(tr)} accessibilityLabel={t.preview}
                    style={{ width: 56, height: 56, borderRadius: 28, backgroundColor: colors.saffron, alignItems: 'center', justifyContent: 'center' }}>
                    <Text style={{ color: colors.white, fontSize: 22, fontFamily: fonts.bold }}>{playing === tr.id ? '❚❚' : '▶'}</Text>
                  </Pressable>
                </Card>
              );
            })}
          </View>
        );
      })}
    </Screen>
  );
}
