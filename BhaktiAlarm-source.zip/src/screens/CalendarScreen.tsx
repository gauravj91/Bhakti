import React, { useMemo, useState } from 'react';
import { View, Text, Pressable, Modal, Alert } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Screen, Title, T, Card, Chip, Button } from '../components/ui';
import { FESTIVALS, Festival, prominence, isRegional, deityById } from '../content/catalog';
import { usePrefs } from '../lib/prefs';
import { scheduleFestivalReminder, cancelReminder } from '../lib/reminders';
import { Banner } from '../lib/ads';
import { s } from '../i18n';
import { colors, fonts, radius } from '../theme';

const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const WD = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const ymd = (x: Date) => `${x.getFullYear()}-${String(x.getMonth() + 1).padStart(2, '0')}-${String(x.getDate()).padStart(2, '0')}`;
const parse = (v: string) => { const [y, m, d] = v.split('-').map(Number); return new Date(y, m - 1, d); };
const addDays = (d: string, n: number) => { const x = parse(d); x.setDate(x.getDate() + n); return ymd(x); };

export default function CalendarScreen() {
  const nav = useNavigation<any>();
  const { prefs, update } = usePrefs();
  const t = s().calendar;
  const now = new Date();
  const [ym, setYm] = useState({ y: now.getFullYear(), m: now.getMonth() });
  const [filter, setFilter] = useState<'all' | 'festival' | 'vrat'>('all');
  const [open, setOpen] = useState<Festival | null>(null);
  const today = ymd(now);

  // Region changes ordering/highlighting only; every pan-India entry stays visible.
  const upcoming = useMemo(() => FESTIVALS
    .filter((f) => (f.endDate || f.date) >= today && f.date <= addDays(today, 45) && (f.major || isRegional(f, prefs.region)))
    .sort((a, b) => prominence(b, prefs.region) - prominence(a, prefs.region) || a.date.localeCompare(b.date))
    .slice(0, 3)
    .sort((a, b) => a.date.localeCompare(b.date)), [prefs.region, today]);

  const monthItems = useMemo(() => FESTIVALS.filter((f) => {
    const d = parse(f.date);
    const inMonth = d.getFullYear() === ym.y && d.getMonth() === ym.m;
    const typeOk = filter === 'all' || (filter === 'festival' ? f.type !== 'vrat' : f.type === 'vrat');
    return inMonth && typeOk;
  }), [ym, filter]);

  const shift = (n: number) => setYm(({ y, m }) => { const d = new Date(y, m + n, 1); return { y: d.getFullYear(), m: d.getMonth() }; });

  const toggleReminder = async (f: Festival) => {
    if (prefs.reminders.includes(f.id)) {
      await cancelReminder(prefs.reminderNotifIds[f.id]);
      const ids = { ...prefs.reminderNotifIds }; delete ids[f.id];
      await update({ reminders: prefs.reminders.filter((x) => x !== f.id), reminderNotifIds: ids });
    } else {
      const id = await scheduleFestivalReminder(f);
      if (!id) { Alert.alert('🙏', 'This date is too soon for a reminder, or notifications are turned off.'); return; }
      await update({ reminders: [...prefs.reminders, f.id], reminderNotifIds: { ...prefs.reminderNotifIds, [f.id]: id } });
    }
  };

  const createGreeting = (f: Festival) => {
    setOpen(null);
    nav.navigate('Create', { screen: 'StudioEditor', params: { festivalSlug: f.greetingCategory, festivalName: f.name }, initial: false });
  };

  const Item = ({ f }: { f: Festival }) => {
    const d = parse(f.date);
    const hi = prominence(f, prefs.region) >= 4;
    const isToday = f.date === today;
    return (
      <Card onPress={() => setOpen(f)} style={{ marginBottom: 10, flexDirection: 'row', alignItems: 'center', borderColor: hi ? colors.saffron : colors.border, borderWidth: hi ? 2 : 1, backgroundColor: isToday ? '#FFF1DE' : colors.white }}>
        <View style={{ width: 62, alignItems: 'center', marginRight: 12 }}>
          <Text style={{ fontFamily: fonts.bold, fontSize: 28, color: hi ? colors.maroon : colors.text }}>{d.getDate()}</Text>
          <Text style={{ fontFamily: fonts.medium, fontSize: 14, color: colors.textSoft }}>{WD[d.getDay()]}</Text>
        </View>
        <View style={{ flex: 1 }}>
          <T bold style={{ fontSize: hi ? 20 : 18, color: hi ? colors.maroon : colors.text }}>{f.name}</T>
          <T soft style={{ fontSize: 15 }}>
            {f.type === 'vrat' ? `🙏 ${t.vrat}` : f.type === 'auspicious' ? `✨ ${t.auspicious}` : `🪔 ${t.festival}`}
            {prefs.reminders.includes(f.id) ? '  🔔' : ''}{isToday ? `  · ${t.today}` : ''}
          </T>
        </View>
      </Card>
    );
  };

  return (
    <View style={{ flex: 1, backgroundColor: colors.cream }}>
      <Screen>
        <Title sub={t.note}>{t.title}</Title>
        {upcoming.length ? (
          <View style={{ marginBottom: 20 }}>
            <T bold big style={{ color: colors.maroon, marginBottom: 8 }}>{t.upcoming}</T>
            {upcoming.map((f) => <Item key={'u' + f.id} f={f} />)}
          </View>
        ) : null}
        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
          <Pressable onPress={() => shift(-1)} style={navBtn} accessibilityLabel="previous month"><Text style={navTxt}>‹</Text></Pressable>
          <Text style={{ fontFamily: fonts.bold, fontSize: 22, color: colors.maroon }}>{MONTHS[ym.m]} {ym.y}</Text>
          <Pressable onPress={() => shift(1)} style={navBtn} accessibilityLabel="next month"><Text style={navTxt}>›</Text></Pressable>
        </View>
        <View style={{ flexDirection: 'row', marginBottom: 6 }}>
          <Chip label={t.all} selected={filter === 'all'} onPress={() => setFilter('all')} />
          <Chip label={t.festivals} selected={filter === 'festival'} onPress={() => setFilter('festival')} />
          <Chip label={t.vrats} selected={filter === 'vrat'} onPress={() => setFilter('vrat')} />
        </View>
        {monthItems.length === 0 ? <T soft style={{ marginTop: 12 }}>{t.noneMonth}</T> : monthItems.map((f) => <Item key={f.id} f={f} />)}
      </Screen>
      <Banner />

      <Modal visible={!!open} transparent animationType="slide" onRequestClose={() => setOpen(null)}>
        <Pressable style={{ flex: 1, backgroundColor: colors.overlay, justifyContent: 'flex-end' }} onPress={() => setOpen(null)}>
          {open ? (
            <Pressable style={{ backgroundColor: colors.cream, borderTopLeftRadius: radius.lg, borderTopRightRadius: radius.lg, padding: 24 }}>
              <Text style={{ fontFamily: fonts.bold, fontSize: 26, color: colors.maroon }}>{open.name}</Text>
              <T soft style={{ marginTop: 4 }}>
                {parse(open.date).toDateString()}{open.endDate ? ` – ${parse(open.endDate).toDateString()}` : ''}
              </T>
              {open.deity ? <T soft>{deityById(open.deity)?.name}</T> : null}
              <T style={{ marginTop: 12 }}>{open.description}</T>
              <Button big icon="🎨" label={t.create} onPress={() => createGreeting(open)} style={{ marginTop: 20 }} />
              <Button kind="secondary" icon="🔔" label={prefs.reminders.includes(open.id) ? `✓ ${t.reminded}` : t.remind} onPress={() => toggleReminder(open)} style={{ marginTop: 12 }} />
              <Button kind="ghost" label={s().common.done} onPress={() => setOpen(null)} style={{ marginTop: 6 }} />
            </Pressable>
          ) : null}
        </Pressable>
      </Modal>
    </View>
  );
}

const navBtn = { width: 56, height: 56, borderRadius: 28, backgroundColor: colors.white, alignItems: 'center' as const, justifyContent: 'center' as const, borderWidth: 1, borderColor: colors.border };
const navTxt = { fontSize: 32, color: colors.saffronDark, marginTop: -4 };
