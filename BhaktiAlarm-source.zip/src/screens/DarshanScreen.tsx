import React, { useEffect, useRef, useState } from 'react';
import { View, Image, Pressable, Text, Animated, Easing, Dimensions, StyleSheet } from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';
import { useAudioPlayer, setAudioModeAsync } from 'expo-audio';
import { useKeepAwake } from 'expo-keep-awake';
import * as Haptics from 'expo-haptics';
import { templeAssets, deityById, templeName } from '../content/catalog';
import { templeVisit } from './TempleListScreen';
import { s, fmt } from '../i18n';
import { colors, fonts } from '../theme';

const { width: SW, height: SH } = Dimensions.get('window');

function Petal({ delay, x }: { delay: number; x: number }) {
  const y = useRef(new Animated.Value(-60)).current;
  const r = useRef(new Animated.Value(0)).current;
  const [flower] = useState(Math.random() > 0.4 ? '🌼' : '🌺');
  const [dir] = useState(Math.random() > 0.5 ? '' : '-');
  useEffect(() => {
    Animated.parallel([
      Animated.timing(y, { toValue: SH * 0.75, duration: 2600 + Math.random() * 1200, delay, easing: Easing.in(Easing.quad), useNativeDriver: true }),
      Animated.timing(r, { toValue: 1, duration: 3000, delay, useNativeDriver: true }),
    ]).start();
  }, []);
  const rot = r.interpolate({ inputRange: [0, 1], outputRange: ['0deg', `${dir}300deg`] });
  return <Animated.Text style={{ position: 'absolute', left: x, top: 0, fontSize: 30, transform: [{ translateY: y }, { rotate: rot }] }}>{flower}</Animated.Text>;
}

/** Calm darshan view. No ads on this screen. */
export default function DarshanScreen() {
  useKeepAwake();
  const nav = useNavigation<any>();
  const route = useRoute<any>();
  const deity = deityById(route.params?.deityId)!;
  const a = templeAssets(deity.id);
  const t = s().temple;
  const ambient = useAudioPlayer(a.ambient);
  const bell = useAudioPlayer(a.bell);
  const [soundOn, setSoundOn] = useState(true);
  const [petals, setPetals] = useState<{ id: number; x: number; delay: number }[]>([]);
  const [diya, setDiya] = useState(false);
  const swing = useRef(new Animated.Value(0)).current;
  const glow = useRef(new Animated.Value(0.6)).current;

  useEffect(() => {
    setAudioModeAsync({ playsInSilentMode: true, shouldPlayInBackground: false }).catch(() => {});
    ambient.loop = true; ambient.volume = 0.6; ambient.play();
    return () => { templeVisit.returned = true; };
  }, []);
  useEffect(() => { soundOn ? ambient.play() : ambient.pause(); }, [soundOn]);
  useEffect(() => {
    if (!diya) return;
    const loop = Animated.loop(Animated.sequence([
      Animated.timing(glow, { toValue: 1, duration: 900, useNativeDriver: true }),
      Animated.timing(glow, { toValue: 0.6, duration: 700, useNativeDriver: true }),
    ]));
    loop.start(); return () => loop.stop();
  }, [diya]);

  const ring = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium).catch(() => {});
    bell.seekTo(0); bell.play();
    swing.setValue(0);
    Animated.sequence([
      Animated.timing(swing, { toValue: 1, duration: 160, useNativeDriver: true }),
      Animated.timing(swing, { toValue: -1, duration: 260, useNativeDriver: true }),
      Animated.timing(swing, { toValue: 0.5, duration: 220, useNativeDriver: true }),
      Animated.timing(swing, { toValue: 0, duration: 200, useNativeDriver: true }),
    ]).start();
  };
  const flowers = () => {
    const base = Date.now();
    setPetals((p) => [...p.slice(-24), ...Array.from({ length: 12 }, (_, i) => ({ id: base + i, x: SW * 0.15 + Math.random() * SW * 0.7, delay: i * 120 }))]);
  };
  const rot = swing.interpolate({ inputRange: [-1, 1], outputRange: ['-18deg', '18deg'] });
  const imgW = SW * 0.72;

  return (
    <View style={{ flex: 1, backgroundColor: '#1A0500' }}>
      <Image source={a.backdrop} style={StyleSheet.absoluteFill} resizeMode="cover" blurRadius={2} />
      <View style={[StyleSheet.absoluteFill, { backgroundColor: 'rgba(20,4,0,0.35)' }]} />
      <Animated.Text style={{ position: 'absolute', top: 36, alignSelf: 'center', fontSize: 56, transform: [{ rotate: rot }] }}>🔔</Animated.Text>

      <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
        <View style={{ padding: 6, borderRadius: 18, backgroundColor: colors.gold }}>
          <Image source={a.image} style={{ width: imgW, height: imgW * 1.25, borderRadius: 14 }} resizeMode="cover" />
        </View>
        <Text style={{ fontFamily: fonts.bold, fontSize: 26, color: '#FFE9B8', marginTop: 14 }}>{templeName(deity.id, deity.short, t.templeOf)}</Text>
        {diya ? <Animated.Text style={{ fontSize: 60, marginTop: 6, opacity: glow }}>🪔</Animated.Text> : <View style={{ height: 76 }} />}
      </View>

      {petals.map((p) => <Petal key={p.id} x={p.x} delay={p.delay} />)}

      <View style={st.bar}>
        <Action icon="🔔" label={t.ringBell} onPress={ring} />
        <Action icon="🌼" label={t.flowers} onPress={flowers} />
        <Action icon="🪔" label={t.diya} onPress={() => setDiya((d) => !d)} active={diya} />
      </View>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', paddingHorizontal: 20, paddingBottom: 26 }}>
        <Pressable onPress={() => setSoundOn((v) => !v)} style={st.small}><Text style={st.smallTxt}>{soundOn ? '🔊' : '🔇'} {t.sound}</Text></Pressable>
        <Pressable onPress={() => nav.goBack()} style={st.small}><Text style={st.smallTxt}>🙏 {t.leave}</Text></Pressable>
      </View>
    </View>
  );
}

function Action({ icon, label, onPress, active }: { icon: string; label: string; onPress: () => void; active?: boolean }) {
  return (
    <Pressable onPress={onPress} style={({ pressed }) => [st.action, (pressed || active) && { backgroundColor: 'rgba(255,153,51,0.9)' }]}>
      <Text style={{ fontSize: 34 }}>{icon}</Text>
      <Text style={{ fontFamily: fonts.bold, fontSize: 15, color: '#FFF3D6', marginTop: 4, textAlign: 'center' }}>{label}</Text>
    </Pressable>
  );
}

const st = StyleSheet.create({
  bar: { flexDirection: 'row', justifyContent: 'space-around', paddingHorizontal: 12, paddingBottom: 14 },
  action: { width: 104, minHeight: 96, borderRadius: 22, alignItems: 'center', justifyContent: 'center', backgroundColor: 'rgba(139,0,0,0.75)', borderWidth: 1.5, borderColor: colors.gold, padding: 8 },
  small: { minHeight: 48, paddingHorizontal: 18, borderRadius: 24, backgroundColor: 'rgba(0,0,0,0.45)', justifyContent: 'center' },
  smallTxt: { color: '#FFF3D6', fontFamily: fonts.bold, fontSize: 17 },
});
