import React, { useEffect, useState } from 'react';
import { View, Text, Linking, Dimensions, Pressable, ScrollView, ActivityIndicator } from 'react-native';
import { WebView } from 'react-native-webview';
import { useKeepAwake } from 'expo-keep-awake';
import { Title, T, Card } from '../components/ui';
import { LIVE, LiveTemple } from '../content/devotion';
import { deityOrder } from '../content/catalog';
import { usePrefs } from '../lib/prefs';
import { s, readsHindi } from '../i18n';
import { colors, fonts } from '../theme';

// Official YouTube embed only; we never download or rehost temple streams.
// YouTube refuses embeds without a referrer/origin (player errors 152/153), so the player page gets a real https base URL.
const ORIGIN = 'https://bhaktialarm.app';
// YouTube rejects playback from WebViews that look like embedded browsers ("wv" UA, no storage/cookies).
const UA = 'Mozilla/5.0 (Linux; Android 14; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Mobile Safari/537.36';

const LIVE_ID = [
  /<link rel="canonical" href="https:\/\/www\.youtube\.com\/watch\?v=([\w-]{11})"/,
  /"videoDetails":\{"videoId":"([\w-]{11})"[^}]*"isLive(?:Content)?":true/,
  /"videoId":"([\w-]{11})"[^{}]{0,400}"isLive":true/,
];
const VIDEO_IN_URL = /[?&]v=([\w-]{11})/;

/** Quick check (from the phone) for the video the channel is streaming. null = unknown or not live;
 *  the screen then opens the channel's live page itself, which settles it either way. */
async function findLiveVideo(channelId: string): Promise<string | null> {
  const res = await fetch(`https://www.youtube.com/channel/${channelId}/live?ucbcb=1&hl=en`, {
    credentials: 'omit',
    headers: { 'User-Agent': UA, 'Accept-Language': 'en-US,en;q=0.8', Cookie: 'SOCS=CAI; CONSENT=YES+1' },
  });
  if (VIDEO_IN_URL.test(res.url)) return res.url.match(VIDEO_IN_URL)![1];
  const html = await res.text();
  for (const re of LIVE_ID) { const m = html.match(re); if (m) return m[1]; }
  return null;
}

/** Reports the page address to the app every second (YouTube's mobile site changes pages without reloading). */
const WATCH_URL_JS = `setInterval(function(){ if (window.ReactNativeWebView) window.ReactNativeWebView.postMessage('url:' + location.href); }, 1000); true;`;

const playerHtml = (videoId: string) => `<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><style>html,body{margin:0;background:#000;height:100%;overflow:hidden}#p{width:100%;height:100%}</style></head><body><div id="p"></div>
<script src="https://www.youtube.com/iframe_api"></script>
<script>
function send(m){ if (window.ReactNativeWebView) window.ReactNativeWebView.postMessage(m); }
function onYouTubeIframeAPIReady(){
  new YT.Player('p', { width: '100%', height: '100%', videoId: '${videoId}',
    playerVars: { autoplay: 1, playsinline: 1, rel: 0, modestbranding: 1, origin: '${ORIGIN}' },
    events: { onReady: function(e){ e.target.playVideo(); }, onError: function(e){ send('error:' + e.data); } } });
}
</script></body></html>`;

// live = clean embedded player; page = YouTube's own mobile live page shown inside the app (fallback, always works).
type Stream = { state: 'checking' } | { state: 'live'; videoId: string } | { state: 'page'; noEmbed?: boolean };

export default function LiveDarshanScreen() {
  useKeepAwake();
  const { prefs } = usePrefs();
  const t = s().live;
  const hi = readsHindi();
  const order = deityOrder(prefs.region, prefs.familyDeity);
  const rank: Record<string, number> = { '24x7': 0, daily: 1, festivals: 2 };
  const list = [...LIVE].sort((a, b) => (rank[a.schedule || 'daily'] - rank[b.schedule || 'daily']) || (order.indexOf(a.deity || '') - order.indexOf(b.deity || '')));
  const [cur, setCur] = useState<LiveTemple | null>(list[0] || null);
  const W = Dimensions.get('window').width;
  const H = (W * 9) / 16;
  const PAGE_H = Math.round(Dimensions.get('window').height * 0.55);
  const [stream, setStream] = useState<Stream>({ state: 'checking' });

  useEffect(() => {
    if (!cur) return;
    let alive = true;
    setStream({ state: 'checking' });
    findLiveVideo(cur.channelId)
      .then((v) => { if (alive) setStream(v ? { state: 'live', videoId: v } : { state: 'page' }); })
      .catch(() => { if (alive) setStream({ state: 'page' }); });
    return () => { alive = false; };
  }, [cur?.id]);

  return (
    <View style={{ flex: 1, backgroundColor: colors.cream }}>
      {cur ? (
        <View style={{ backgroundColor: '#000' }}>
          {stream.state === 'live' ? (
            <WebView key={stream.videoId} source={{ html: playerHtml(stream.videoId), baseUrl: ORIGIN }} style={{ width: W, height: H, backgroundColor: '#000' }}
              containerStyle={{ flex: 0, width: W, height: H }}
              onMessage={(e) => { if (e.nativeEvent.data.startsWith('error')) setStream({ state: 'page', noEmbed: true }); }}
              userAgent={UA} domStorageEnabled thirdPartyCookiesEnabled sharedCookiesEnabled
              allowsInlineMediaPlayback originWhitelist={['*']}
              allowsFullscreenVideo mediaPlaybackRequiresUserAction={false} javaScriptEnabled />
          ) : stream.state === 'page' ? (
            <WebView key={'page-' + cur.id} source={{ uri: `https://m.youtube.com/channel/${cur.channelId}/live?ucbcb=1` }}
              style={{ width: W, height: PAGE_H, backgroundColor: '#000' }} containerStyle={{ flex: 0, width: W, height: PAGE_H }}
              injectedJavaScript={WATCH_URL_JS}
              onMessage={(e) => {
                const v = e.nativeEvent.data.match(VIDEO_IN_URL)?.[1];
                if (v && !stream.noEmbed) setStream({ state: 'live', videoId: v });
              }}
              userAgent={UA} domStorageEnabled thirdPartyCookiesEnabled sharedCookiesEnabled
              allowsInlineMediaPlayback allowsFullscreenVideo mediaPlaybackRequiresUserAction={false} javaScriptEnabled />
          ) : (
            <View style={{ width: W, height: H, alignItems: 'center', justifyContent: 'center', padding: 24 }}>
              <ActivityIndicator color="#FFE2B8" size="large" />
              <Text style={{ color: '#FFE2B8', fontFamily: fonts.medium, fontSize: 17, marginTop: 12 }}>{t.checking}</Text>
            </View>
          )}
          <View style={{ flexDirection: 'row', alignItems: 'center', padding: 10, backgroundColor: colors.maroon }}>
            <Text style={{ flex: 1, fontFamily: fonts.bold, fontSize: 18, color: '#FFF3D6' }} numberOfLines={1}>{stream.state === 'live' ? '🔴 ' : ''}{hi ? cur.nameHi : cur.name}</Text>
            <Pressable onPress={() => Linking.openURL(stream.state === 'live' ? `https://www.youtube.com/watch?v=${stream.videoId}` : cur.channelUrl + '/live')}><Text style={{ color: '#FFE2B8', fontFamily: fonts.medium }}>{t.openYouTube} ›</Text></Pressable>
          </View>
        </View>
      ) : null}
      <ScrollView contentContainerStyle={{ padding: 20, paddingBottom: 40 }}>
        <Title sub={t.sub}>{t.title}</Title>
        <T soft style={{ marginBottom: 12, fontSize: 15 }}>{t.offline}</T>
        {list.map((x) => (
          <Card key={x.id} onPress={() => setCur(x)} style={{ marginBottom: 10, borderWidth: cur?.id === x.id ? 2 : 1, borderColor: cur?.id === x.id ? colors.saffron : colors.border }}>
            <T bold style={{ fontSize: 19, color: colors.maroon }}>🛕 {hi ? x.nameHi : x.name}</T>
            <T soft>{x.place} · {(t.schedule as any)[x.schedule || 'daily']}</T>
          </Card>
        ))}
      </ScrollView>
    </View>
  );
}
