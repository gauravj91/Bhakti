import React, { useState } from 'react';
import { View, Text, Linking, Dimensions, Pressable, ScrollView } from 'react-native';
import { WebView } from 'react-native-webview';
import { useKeepAwake } from 'expo-keep-awake';
import { Title, T, Card } from '../components/ui';
import { LIVE, LiveTemple } from '../content/devotion';
import { deityOrder } from '../content/catalog';
import { usePrefs } from '../lib/prefs';
import { s, readsHindi } from '../i18n';
import { colors, fonts } from '../theme';

// Official YouTube embed only; we never download or rehost temple streams.
const embed = (ch: string) => `https://www.youtube.com/embed/live_stream?channel=${ch}&autoplay=1&playsinline=1&rel=0`;
// YouTube now refuses embeds without a referrer/origin (player error 152/153), so host the iframe in a page with a real https base URL.
const ORIGIN = 'https://bhaktialarm.app';
const playerHtml = (ch: string) => `<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="referrer" content="strict-origin-when-cross-origin"><style>html,body{margin:0;background:#000;height:100%}iframe{border:0;width:100%;height:100%}</style></head><body><iframe src="${embed(ch)}&origin=${encodeURIComponent(ORIGIN)}" allow="autoplay; encrypted-media; picture-in-picture; fullscreen" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe></body></html>`;

export default function LiveDarshanScreen() {
  useKeepAwake();
  const { prefs } = usePrefs();
  const t = s().live;
  const hi = readsHindi();
  const order = deityOrder(prefs.region, prefs.familyDeity);
  const rank: Record<string, number> = { '24x7': 0, daily: 1, festivals: 2 };
  const list = [...LIVE].sort((a, b) => (rank[a.schedule || 'daily'] - rank[b.schedule || 'daily']) || (order.indexOf(a.deity || '') - order.indexOf(b.deity || '')));
  const [cur, setCur] = useState<LiveTemple | null>(list[0] || null);
  const W = Dimensions.get('window').width;

  return (
    <View style={{ flex: 1, backgroundColor: colors.cream }}>
      {cur ? (
        <View style={{ backgroundColor: '#000' }}>
          <WebView key={cur.id} source={{ html: playerHtml(cur.channelId), baseUrl: ORIGIN }} style={{ width: W, height: (W * 9) / 16, backgroundColor: '#000' }}
            containerStyle={{ flex: 0, width: W, height: (W * 9) / 16 }}
            allowsFullscreenVideo mediaPlaybackRequiresUserAction={false} javaScriptEnabled />
          <View style={{ flexDirection: 'row', alignItems: 'center', padding: 10, backgroundColor: colors.maroon }}>
            <Text style={{ flex: 1, fontFamily: fonts.bold, fontSize: 18, color: '#FFF3D6' }} numberOfLines={1}>🔴 {hi ? cur.nameHi : cur.name}</Text>
            <Pressable onPress={() => Linking.openURL(cur.channelUrl + '/live')}><Text style={{ color: '#FFE2B8', fontFamily: fonts.medium }}>{t.openYouTube} ›</Text></Pressable>
          </View>
        </View>
      ) : null}
      <ScrollView contentContainerStyle={{ padding: 20, paddingBottom: 40 }}>
        <Title sub={t.sub}>{t.title}</Title>
        <T soft style={{ marginBottom: 12, fontSize: 15 }}>{t.offline}</T>
        {list.map((x) => (
          <Card key={x.id} onPress={() => setCur(x)} style={{ marginBottom: 10, borderWidth: cur?.id === x.id ? 2 : 1, borderColor: cur?.id === x.id ? colors.saffron : colors.border }}>
            <T bold style={{ fontSize: 19, color: colors.maroon }}>🛕 {hi ? x.nameHi : x.name}</T>
            <T soft>{x.place} · {(t.schedule as any)[x.schedule || 'daily']}</T>
          </Card>
        ))}
      </ScrollView>
    </View>
  );
}
