import React, { useEffect, useRef, useState } from 'react';
import { View, Text, Pressable, StyleSheet, Animated, ScrollView } from 'react-native';
import * as Haptics from 'expo-haptics';
import { useKeepAwake } from 'expo-keep-awake';
import Svg, { Circle } from 'react-native-svg';
import { Chip } from '../components/ui';
import { usePrefs } from '../lib/prefs';
import { s, fmt } from '../i18n';
import { colors, fonts } from '../theme';

export const MANTRAS = [
  { id: 'ram', text: 'राम', roman: 'Ram' },
  { id: 'radhe', text: 'राधे राधे', roman: 'Radhe Radhe' },
  { id: 'shiv', text: 'ॐ नमः शिवाय', roman: 'Om Namah Shivaya' },
  { id: 'krishna', text: 'हरे कृष्ण', roman: 'Hare Krishna' },
  { id: 'ganesh', text: 'ॐ गं गणपतये नमः', roman: 'Om Gan Ganapataye Namah' },
  { id: 'vasudev', text: 'ॐ नमो भगवते वासुदेवाय', roman: 'Om Namo Bhagavate Vasudevaya' },
  { id: 'gayatri', text: 'गायत्री मंत्र', roman: 'Gayatri Mantra' },
  { id: 'durga', text: 'जय माता दी', roman: 'Jai Mata Di' },
  { id: 'hanuman', text: 'जय हनुमान', roman: 'Jai Hanuman' },
  { id: 'waheguru', text: 'वाहेगुरु', roman: 'Waheguru' },
];
const MALA = 108;
const todayKey = () => new Date().toISOString().slice(0, 10);

export default function JaapScreen() {
  useKeepAwake();
  const { prefs, update } = usePrefs();
  const t = s().jaap;
  const j = prefs.jaap;
  const fresh = j.today === todayKey();
  const [count, setCount] = useState(fresh ? j.todayCount : 0);
  const [total, setTotal] = useState(j.total);
  const [mantraId, setMantraId] = useState(j.mantraId);
  const pulse = useRef(new Animated.Value(1)).current;
  const saveTimer = useRef<any>(null);

  // Persist (debounced) so fast tapping stays smooth.
  useEffect(() => {
    clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(() => update({ jaap: { ...prefs.jaap, mantraId, today: todayKey(), todayCount: count, total } }), 600);
    return () => clearTimeout(saveTimer.current);
  }, [count, total, mantraId]);

  const tap = () => {
    const next = count + 1;
    setCount(next); setTotal(total + 1);
    if (next % MALA === 0) Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    else Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    pulse.setValue(0.94);
    Animated.spring(pulse, { toValue: 1, useNativeDriver: true, speed: 40 }).start();
  };

  const inMala = count % MALA;
  const malas = Math.floor(count / MALA);
  const R = 120, C = 2 * Math.PI * R;
  const mantra = MANTRAS.find((m) => m.id === mantraId) || MANTRAS[0];

  return (
    <View style={{ flex: 1, backgroundColor: '#3A0A00' }}>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ flexGrow: 0, paddingVertical: 12 }} contentContainerStyle={{ paddingHorizontal: 12 }}>
        {MANTRAS.map((m) => <Chip key={m.id} label={m.roman} selected={m.id === mantraId} onPress={() => setMantraId(m.id)} />)}
      </ScrollView>
      <Pressable onPress={tap} style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }} accessibilityLabel={t.tap}>
        <Text style={st.mantra}>{mantra.text}</Text>
        <Animated.View style={{ transform: [{ scale: pulse }], alignItems: 'center', justifyContent: 'center', marginVertical: 24 }}>
          <Svg width={2 * R + 30} height={2 * R + 30}>
            <Circle cx={R + 15} cy={R + 15} r={R} stroke="rgba(255,215,140,0.25)" strokeWidth={14} fill="none" />
            <Circle cx={R + 15} cy={R + 15} r={R} stroke="#FFB347" strokeWidth={14} fill="none"
              strokeDasharray={`${C} ${C}`} strokeDashoffset={C * (1 - inMala / MALA)} strokeLinecap="round"
              transform={`rotate(-90 ${R + 15} ${R + 15})`} />
          </Svg>
          <View style={StyleSheet.absoluteFill as any}>
            <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
              <Text style={st.count}>{inMala}</Text>
              <Text style={st.of}>/ {MALA}</Text>
            </View>
          </View>
        </Animated.View>
        <Text style={st.stat}>{fmt(t.mala, { n: malas })}  ·  {fmt(t.today, { n: count })}</Text>
        <Text style={[st.stat, { opacity: 0.7, marginTop: 6 }]}>{fmt(t.total, { n: total })}</Text>
        <Text style={st.hint}>{t.tap}</Text>
      </Pressable>
    </View>
  );
}

const st = StyleSheet.create({
  mantra: { fontFamily: fonts.devaBold, fontSize: 34, color: '#FFE2B8', textAlign: 'center', paddingHorizontal: 20 },
  count: { fontFamily: fonts.bold, fontSize: 72, color: '#FFF3D6' },
  of: { fontFamily: fonts.medium, fontSize: 18, color: '#FFE2B8' },
  stat: { fontFamily: fonts.bold, fontSize: 20, color: '#FFE2B8' },
  hint: { fontFamily: fonts.regular, fontSize: 16, color: 'rgba(255,226,184,0.6)', marginTop: 24 },
});
