import React, { useState } from 'react';
import { View, Pressable, Text, StyleSheet } from 'react-native';
import { Screen, Title, T, Button } from '../components/ui';
import { REGIONS, DEITIES } from '../content/catalog';
import { usePrefs } from '../lib/prefs';
import { s } from '../i18n';
import { colors, fonts, radius, size } from '../theme';

export function OptionList({ items, selected, onSelect }: { items: { id: string | null; name: string }[]; selected: string | null; onSelect: (id: string | null) => void }) {
  return (
    <View>
      {items.map((it) => {
        const on = it.id === selected;
        return (
          <Pressable key={String(it.id)} onPress={() => onSelect(it.id)} accessibilityRole="radio" accessibilityState={{ checked: on }}
            style={[st.opt, on && { borderColor: colors.saffron, backgroundColor: '#FFF1DE' }]}>
            <View style={[st.radio, on && { borderColor: colors.saffron }]}>{on ? <View style={st.dot} /> : null}</View>
            <Text style={st.optText}>{it.name}</Text>
          </Pressable>
        );
      })}
    </View>
  );
}

export default function OnboardingScreen() {
  const { update } = usePrefs();
  const [step, setStep] = useState(0);
  const [region, setRegion] = useState<string | null>(null);
  const [deity, setDeity] = useState<string | null>(null);
  const t = s().onboarding;

  if (step === 0) {
    return (
      <Screen>
        <View style={{ alignItems: 'center', marginTop: 40 }}>
          <Text style={{ fontSize: 96 }}>🪔</Text>
          <Text style={{ fontFamily: fonts.bold, fontSize: 34, color: colors.maroon, marginTop: 12 }}>{t.welcome}</Text>
          <T soft style={{ textAlign: 'center', marginTop: 12, marginBottom: 40 }}>{t.welcomeSub}</T>
          <Button big label={s().common.next} onPress={() => setStep(1)} style={{ alignSelf: 'stretch' }} />
        </View>
      </Screen>
    );
  }
  if (step === 1) {
    return (
      <Screen>
        <Title sub={t.regionHint}>{t.regionQ}</Title>
        <OptionList items={REGIONS} selected={region} onSelect={setRegion} />
        <Button big label={s().common.next} disabled={!region} onPress={() => setStep(2)} style={{ marginTop: 16 }} />
      </Screen>
    );
  }
  return (
    <Screen>
      <Title sub={t.deityHint}>{t.deityQ}</Title>
      <OptionList items={[{ id: null, name: t.noPreference }, ...DEITIES]} selected={deity} onSelect={setDeity} />
      <Button big label={t.start} onPress={() => update({ region, familyDeity: deity, onboarded: true })} style={{ marginTop: 16 }} />
      <Button kind="ghost" label={s().common.back} onPress={() => setStep(1)} style={{ marginTop: 8 }} />
    </Screen>
  );
}

const st = StyleSheet.create({
  opt: { flexDirection: 'row', alignItems: 'center', minHeight: 60, paddingHorizontal: 16, borderRadius: radius.md, borderWidth: 2, borderColor: colors.border, backgroundColor: colors.white, marginBottom: 10 },
  optText: { fontFamily: fonts.medium, fontSize: size.body, color: colors.text, flex: 1 },
  radio: { width: 26, height: 26, borderRadius: 13, borderWidth: 2, borderColor: colors.border, marginRight: 14, alignItems: 'center', justifyContent: 'center' },
  dot: { width: 14, height: 14, borderRadius: 7, backgroundColor: colors.saffron },
});
