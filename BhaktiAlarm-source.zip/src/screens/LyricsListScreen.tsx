import React from 'react';
import { View, Text } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Screen, Title, T, Card } from '../components/ui';
import { LYRICS } from '../content/devotion';
import { deityOrder, deityById } from '../content/catalog';
import { usePrefs } from '../lib/prefs';
import { s, fmt, readsHindi } from '../i18n';
import { colors } from '../theme';

const ICON = { chalisa: '📖', aarti: '🪔', bhajan: '🎵' } as const;

export default function LyricsListScreen() {
  const nav = useNavigation<any>();
  const { prefs } = usePrefs();
  const t = s().lyrics;
  const order = deityOrder(prefs.region, prefs.familyDeity);
  const list = [...LYRICS].sort((a, b) => order.indexOf(a.deity) - order.indexOf(b.deity));
  const doneToday = prefs.path.last === new Date().toISOString().slice(0, 10);
  const hi = readsHindi();
  return (
    <Screen>
      <Title sub={prefs.path.streak ? fmt(t.streak, { n: prefs.path.streak }) + (doneToday ? '  ·  ' + t.doneToday : '') : undefined}>{t.title}</Title>
      {list.map((l) => (
        <Card key={l.id} onPress={() => nav.navigate('LyricsReader', { id: l.id })} style={{ marginBottom: 10, flexDirection: 'row', alignItems: 'center' }}>
          <Text style={{ fontSize: 30, marginRight: 14 }}>{ICON[l.kind] || '🪔'}</Text>
          <View style={{ flex: 1 }}>
            <T bold style={{ fontSize: 20, color: colors.maroon }}>{hi ? l.titleHi : l.title}</T>
            <T soft>{hi ? l.title : l.titleHi} · {deityById(l.deity)?.name}</T>
          </View>
          <Text style={{ fontSize: 26, color: colors.saffronDark }}>›</Text>
        </Card>
      ))}
    </Screen>
  );
}
