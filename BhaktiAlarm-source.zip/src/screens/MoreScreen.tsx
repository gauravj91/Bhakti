import React, { useCallback, useState } from 'react';
import { Modal, TextInput, View, Share as RNShare } from 'react-native';
import { useFocusEffect, useNavigation } from '@react-navigation/native';
import Constants from 'expo-constants';
import { Screen, Title, T, Card, Row, Button, Chip, Toggle } from '../components/ui';
import AutostartGuide from '../components/AutostartGuide';
import { oemOrGeneric } from '../lib/oem';
import { DARSHAN_HOURS } from '../lib/dailyDarshan';
import { TITHI_OPTIONS } from '../lib/tithiReminders';
import { OptionList } from './OnboardingScreen';
import { REGIONS, DEITIES, FESTIVALS } from '../content/catalog';
import { usePrefs } from '../lib/prefs';
import { permissionsStatus, openExactAlarmSettings, openFullScreenSettings } from '../lib/alarms';
import { ensureNotificationPermission, refreshVratReminders } from '../lib/reminders';
import { TEXT_SIZES } from '../lib/textScale';
import { PLAY_STORE_LINK } from '../lib/config';
import { s, fmt, LANGUAGES } from '../i18n';
import { colors, fonts, radius, size } from '../theme';

export default function MoreScreen() {
  const { prefs, update } = usePrefs();
  const t = s().more;
  const nav = useNavigation<any>();
  const [sheet, setSheet] = useState<null | 'region' | 'deity' | 'footer' | 'lang' | 'text' | 'autostart' | 'tithi'>(null);
  const [footer, setFooter] = useState(prefs.footer ?? '');
  const [perm, setPerm] = useState(permissionsStatus());
  useFocusEffect(useCallback(() => setPerm(permissionsStatus()), []));
  const permOk = perm.exact && perm.notifications && perm.fullScreen;

  const fixPerm = async () => {
    if (!perm.notifications) await ensureNotificationPermission();
    else if (!perm.exact) openExactAlarmSettings();
    else if (!perm.fullScreen) openFullScreenSettings();
    setTimeout(() => setPerm(permissionsStatus()), 800);
  };

  const hourLabel = (h: number) => fmt(t.hourLabel, { h });
  const setDarshan = async (v: boolean) => {
    if (v) await ensureNotificationPermission().catch(() => false);
    await update({ dailyDarshanEnabled: v }); // Root re-schedules (or cancels) when this changes
  };

  return (
    <Screen>
      <Title>{t.title}</Title>
      <Card style={{ marginBottom: 16 }}>
        <Row label={t.language} value={LANGUAGES.find((l) => l.id === prefs.language)?.name ?? 'English'} onPress={() => setSheet('lang')} />
        <Row label={t.textSize} value={t.textSizes[TEXT_SIZES.find((x) => x.id === prefs.textScale)?.key ?? 'normal']} onPress={() => setSheet('text')} />
        <Row label={'🎂 ' + t.family} value={fmt(t.familySub, { n: prefs.family.length })} onPress={() => nav.navigate('Family')} />
        <Row label={'📖 ' + s().calendar.allVrats} onPress={() => nav.navigate('VratGuide')} />
        <Row label={'🔔 ' + t.vratReminders} value={prefs.vratReminders ? s().common.on : s().common.off}
          onPress={async () => { const v = !prefs.vratReminders; await update({ vratReminders: v }); refreshVratReminders(FESTIVALS, v); }} />
        <Row label={'🌙 ' + s().tithiRem.title}
          value={prefs.tithiReminders.length ? fmt(s().tithiRem.count, { n: prefs.tithiReminders.length }) : s().tithiRem.none}
          onPress={() => setSheet('tithi')} />
        <Row label={'🌅 ' + t.morningDarshan}
          value={prefs.dailyDarshanEnabled ? fmt(t.morningDarshanSub, { time: hourLabel(prefs.dailyDarshanHour) }) : s().common.off}
          right={<Toggle value={prefs.dailyDarshanEnabled} onChange={setDarshan} />} />
        {prefs.dailyDarshanEnabled ? (
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', paddingTop: 12 }}>
            {DARSHAN_HOURS.map((h) => (
              <Chip key={h} label={hourLabel(h)} selected={prefs.dailyDarshanHour === h} onPress={() => update({ dailyDarshanHour: h })} />
            ))}
          </View>
        ) : null}
      </Card>
      <Card>
        <Row label={t.region} value={REGIONS.find((r) => r.id === prefs.region)?.name ?? '—'} onPress={() => setSheet('region')} />
        <Row label={t.deity} value={DEITIES.find((d) => d.id === prefs.familyDeity)?.name ?? s().onboarding.noPreference} onPress={() => setSheet('deity')} />
        <Row label={t.footer} value={prefs.footer || t.footerNone} onPress={() => { setFooter(prefs.footer ?? ''); setSheet('footer'); }} />
        <Row label={'🔔 ' + t.alarmHelp} onPress={() => setSheet('autostart')} />
        <Row label={t.permissions} value={permOk ? `✓ ${t.permissionsOk}` : `⚠️ ${t.permissionsFix}`} onPress={permOk ? undefined : fixPerm} />
      </Card>
      <Button kind="secondary" icon="💛" label={t.rate} style={{ marginTop: 20 }}
        onPress={() => RNShare.share({ message: fmt(t.shareText, { link: PLAY_STORE_LINK }) })} />
      <Card style={{ marginTop: 20 }}>
        <T bold>{t.about}</T>
        <T soft style={{ marginTop: 6 }}>{fmt(t.aboutBody, { v: Constants.expoConfig?.version ?? '1.0.0' })}</T>
        <T soft style={{ marginTop: 6, fontSize: 15 }}>{t.placeholderNote}</T>
      </Card>

      <Modal visible={!!sheet} animationType="slide" onRequestClose={() => setSheet(null)}>
        <Screen>
          {sheet === 'region' ? (<>
            <Title>{s().onboarding.regionQ}</Title>
            <OptionList items={REGIONS} selected={prefs.region} onSelect={(id) => { update({ region: id }); setSheet(null); }} />
          </>) : null}
          {sheet === 'deity' ? (<>
            <Title>{s().onboarding.deityQ}</Title>
            <OptionList items={[{ id: null, name: s().onboarding.noPreference }, ...DEITIES]} selected={prefs.familyDeity} onSelect={(id) => { update({ familyDeity: id }); setSheet(null); }} />
          </>) : null}
          {sheet === 'lang' ? (<>
            <Title>{s().langPick.title}</Title>
            <OptionList items={LANGUAGES} selected={prefs.language} onSelect={(id) => { update({ language: id || 'en' }); setSheet(null); }} />
          </>) : null}
          {sheet === 'text' ? (<>
            <Title>{t.textSize}</Title>
            <OptionList items={TEXT_SIZES.map((x) => ({ id: String(x.id), name: t.textSizes[x.key] }))} selected={String(prefs.textScale)}
              onSelect={(id) => { update({ textScale: Number(id) || 1 }); setSheet(null); }} />
            <T style={{ marginTop: 12 }}>{t.textSample}</T>
          </>) : null}
          {sheet === 'tithi' ? (<>
            <Title sub={s().tithiRem.sub}>{s().tithiRem.title}</Title>
            {TITHI_OPTIONS.map((o) => {
              const on = prefs.tithiReminders.includes(o.key);
              return (
                <Row key={o.key} label={(s().tithiRem.options as Record<string, string>)[o.key]}
                  right={<Toggle value={on} onChange={async (v) => {
                    if (v) await ensureNotificationPermission().catch(() => false);
                    update({ tithiReminders: v ? [...prefs.tithiReminders, o.key] : prefs.tithiReminders.filter((k) => k !== o.key) });
                  }} />} />
              );
            })}
            <T bold style={{ marginTop: 16, marginBottom: 8 }}>{s().tithiRem.when}</T>
            <View style={{ flexDirection: 'row', flexWrap: 'wrap' }}>
              <Chip label={s().tithiRem.eve} selected={prefs.tithiReminderTime === 'eve'} onPress={() => update({ tithiReminderTime: 'eve' })} />
              <Chip label={s().tithiRem.morn} selected={prefs.tithiReminderTime === 'morn'} onPress={() => update({ tithiReminderTime: 'morn' })} />
            </View>
            <T soft style={{ marginTop: 12, fontSize: 14 }}>{s().tithiRem.note}</T>
            <Button big label={s().common.done} style={{ marginTop: 16 }} onPress={() => setSheet(null)} />
          </>) : null}
          {sheet === 'autostart' ? <AutostartGuide oem={oemOrGeneric()} onDone={() => { update({ autostartGuideDismissed: true }); setSheet(null); }} /> : null}
          {sheet === 'footer' ? (<>
            <Title>{t.footer}</Title>
            <TextInput value={footer} onChangeText={setFooter} placeholder="— Ramesh & Family" placeholderTextColor={colors.textSoft}
              style={{ backgroundColor: colors.white, borderRadius: radius.md, borderWidth: 1.5, borderColor: colors.border, minHeight: 56, paddingHorizontal: 16, fontSize: size.body, fontFamily: fonts.regular, color: colors.text }} />
            <Button big label={s().common.save} style={{ marginTop: 16 }} onPress={() => { update({ footer: footer.trim() || null }); setSheet(null); }} />
          </>) : null}
          <Button kind="ghost" label={s().common.cancel} style={{ marginTop: 10 }} onPress={() => setSheet(null)} />
        </Screen>
      </Modal>
    </Screen>
  );
}
