import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { View, Text, Pressable, Image, Dimensions, ActivityIndicator, ScrollView } from 'react-native';
import { useFocusEffect, useNavigation } from '@react-navigation/native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { WebView } from 'react-native-webview';
import { LinearGradient } from 'expo-linear-gradient';
import { T } from '../components/ui';
import { listAlarms, fmtTime, Alarm } from '../lib/alarms';
import { usePrefs } from '../lib/prefs';
import { LIVE, LiveTemple } from '../content/devotion';
import { deityOrder } from '../content/catalog';
import { firstLive, liveThumb, playerHtml, ORIGIN, UA } from '../lib/live';
import { panchangFor, cityFor, fmtIST } from '../lib/panchang';
import { dailyRashifal } from '../content/rashifal';
import { RASHIS, RASHIS_HI, RASHI_SYMBOL } from '../lib/astro';
import { Banner } from '../lib/ads';
import { previewParam } from '../lib/webPreview';
import { s, fmt, readsHindi } from '../i18n';
import { x } from '../i18n/extra';
import { colors, fonts, radius, shadow } from '../theme';

/** Next ring time of the enabled alarms, or null. */
function nextAlarm(alarms: Alarm[]): Date | null {
  const now = new Date();
  let best: Date | null = null;
  for (const a of alarms.filter((y) => y.enabled)) {
    for (let add = 0; add < 8; add++) {
      const d = new Date(now.getFullYear(), now.getMonth(), now.getDate() + add, a.hour, a.minute);
      if (d <= now) continue;
      if (a.days.length && !a.days.includes(d.getDay())) continue;
      if (!best || d < best) best = d;
      break;
    }
  }
  return best;
}

const Stars = ({ n }: { n: number }) => <Text style={{ color: colors.gold, fontSize: 18, letterSpacing: 2 }}>{'★'.repeat(n)}<Text style={{ color: '#E5D3B0' }}>{'★'.repeat(5 - n)}</Text></Text>;

export default function HomeScreen() {
  const nav = useNavigation<any>();
  const { prefs } = usePrefs();
  const t = x().home;
  const hi = readsHindi();
  const W = Dimensions.get('window').width - 40;

  // ---- Alarm fold
  const [alarms, setAlarms] = useState<Alarm[]>([]);
  useFocusEffect(useCallback(() => { setAlarms(listAlarms()); }, []));
  const next = nextAlarm(alarms);
  const onCount = alarms.filter((a) => a.enabled).length;
  const dayNames = s().alarm.dayNames;

  // ---- Live fold
  const order = deityOrder(prefs.region, prefs.familyDeity);
  const ranked = useMemo(() => {
    const rank: Record<string, number> = { '24x7': 0, daily: 1, festivals: 2 };
    return [...LIVE].sort((a, b) => (rank[a.schedule || 'daily'] - rank[b.schedule || 'daily']) || (order.indexOf(a.deity || '') - order.indexOf(b.deity || '')));
  }, [prefs.region, prefs.familyDeity]);
  const [live, setLive] = useState<{ temple: LiveTemple; videoId: string } | null | 'checking'>('checking');
  const [playing, setPlaying] = useState(false);
  useEffect(() => {
    let alive = true;
    const pv = previewParam('live');
    if (pv) { const tp = LIVE.find((y) => y.id === (previewParam('temple') || 'harmandir-sahib')); if (tp) { setLive({ temple: tp, videoId: pv }); return; } }
    firstLive(ranked).then((r) => { if (alive) setLive(r); }).catch(() => { if (alive) setLive(null); });
    return () => { alive = false; };
  }, [ranked]);
  // Stop the inline player when leaving Home.
  useFocusEffect(useCallback(() => () => setPlaying(false), []));

  // ---- Panchang + Rashifal
  const p = useMemo(() => panchangFor(new Date(), cityFor(prefs.region)), [prefs.region, new Date().toDateString()]);
  const rf = prefs.myRashi != null ? dailyRashifal(prefs.myRashi, new Date(), hi ? 'hi' : 'en') : null;
  const pt = s().panchang;

  const goLive = (lv?: { temple: LiveTemple; videoId: string } | null) => nav.navigate('LiveDarshan', lv ? { templeId: lv.temple.id, videoId: lv.videoId } : undefined);

  return (
    <SafeAreaView edges={['top']} style={{ flex: 1, backgroundColor: colors.cream }}>
      <ScrollView contentContainerStyle={{ padding: 20, paddingBottom: 32 }}>
        <Text style={{ fontFamily: fonts.bold, fontSize: 26, color: colors.maroon }}>{t.hello}</Text>
        <T soft style={{ marginBottom: 16 }}>
          {`${pt.days[new Date().getDay()]} · ${hi ? p.tithiHi : p.tithi} · ${p.paksha === 'Shukla' ? pt.shukla : pt.krishna}`}
        </T>

        {/* 1. Alarm */}
        <Pressable onPress={() => nav.navigate('AlarmList')} accessibilityRole="button"
          style={({ pressed }) => [{ borderRadius: radius.md, overflow: 'hidden', marginBottom: 16, opacity: pressed ? 0.92 : 1 }, shadow]}>
          <LinearGradient colors={['#8B0000', '#C2410C']} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={{ padding: 18, flexDirection: 'row', alignItems: 'center' }}>
            <Text style={{ fontSize: 46, marginRight: 14 }}>⏰</Text>
            <View style={{ flex: 1 }}>
              <Text style={{ color: '#FFE2B8', fontFamily: fonts.medium, fontSize: 15 }}>{t.alarmTitle}{onCount > 1 ? ` · ${fmt(t.alarmsOn, { n: onCount })}` : ''}</Text>
              {next ? (() => { const f = fmtTime(next.getHours(), next.getMinutes()); return (
                <Text style={{ color: '#FFF8E7', fontFamily: fonts.bold, fontSize: 40 }}>{f.time}<Text style={{ fontSize: 18 }}> {f.ampm} · {dayNames[next.getDay()]}</Text></Text>
              ); })() : <Text style={{ color: '#FFF8E7', fontFamily: fonts.bold, fontSize: 19, marginTop: 2 }}>{t.noAlarm}</Text>}
            </View>
            <Text style={{ color: '#FFF3D6', fontSize: 30 }}>›</Text>
          </LinearGradient>
        </Pressable>

        {/* 2. Live aarti */}
        <View style={[{ borderRadius: radius.md, overflow: 'hidden', backgroundColor: '#1A0A00', marginBottom: 16 }, shadow]}>
          <View style={{ flexDirection: 'row', alignItems: 'center', padding: 12 }}>
            <Text style={{ flex: 1, color: '#FFE2B8', fontFamily: fonts.bold, fontSize: 18 }}>🛕 {t.liveTitle}</Text>
            <Pressable onPress={() => goLive(live && live !== 'checking' ? live : null)}><Text style={{ color: '#FFB347', fontFamily: fonts.medium }}>{t.allLive} ›</Text></Pressable>
          </View>
          {live === 'checking' ? (
            <View style={{ height: (W * 9) / 16, alignItems: 'center', justifyContent: 'center' }}>
              <ActivityIndicator color="#FFE2B8" />
              <Text style={{ color: '#FFE2B8', marginTop: 8, fontFamily: fonts.regular }}>{t.liveChecking}</Text>
            </View>
          ) : live ? (
            <View>
              {playing ? (
                <WebView source={{ html: playerHtml(live.videoId), baseUrl: ORIGIN }} style={{ width: W, height: (W * 9) / 16, backgroundColor: '#000' }}
                  containerStyle={{ flex: 0, width: W, height: (W * 9) / 16 }} userAgent={UA} domStorageEnabled thirdPartyCookiesEnabled sharedCookiesEnabled
                  allowsInlineMediaPlayback allowsFullscreenVideo mediaPlaybackRequiresUserAction={false} javaScriptEnabled originWhitelist={['*']}
                  onMessage={(e) => { if (e.nativeEvent.data.startsWith('error')) goLive(live); }} />
              ) : (
                <Pressable onPress={() => setPlaying(true)} accessibilityRole="button" accessibilityLabel={t.watch}>
                  <Image source={{ uri: previewParam('thumb') || liveThumb(live.videoId) }} style={{ width: W, height: (W * 9) / 16 }} resizeMode="cover" />
                  <View style={{ position: 'absolute', top: 10, left: 10, backgroundColor: '#D32F2F', borderRadius: 6, paddingHorizontal: 8, paddingVertical: 3 }}>
                    <Text style={{ color: '#fff', fontFamily: fonts.bold, fontSize: 13 }}>● {t.liveNow}</Text>
                  </View>
                  <View style={{ position: 'absolute', top: 0, bottom: 0, left: 0, right: 0, alignItems: 'center', justifyContent: 'center' }}>
                    <View style={{ width: 76, height: 76, borderRadius: 38, backgroundColor: 'rgba(0,0,0,0.6)', alignItems: 'center', justifyContent: 'center', borderWidth: 2, borderColor: '#FFE2B8' }}>
                      <Text style={{ color: '#fff', fontSize: 34, marginLeft: 6 }}>▶</Text>
                    </View>
                  </View>
                </Pressable>
              )}
              <Text style={{ color: '#FFF3D6', fontFamily: fonts.bold, fontSize: 17, padding: 12 }} numberOfLines={1}>{hi ? live.temple.nameHi : live.temple.name}<Text style={{ color: '#FFE2B8', fontFamily: fonts.regular }}>  ·  {live.temple.place}</Text></Text>
            </View>
          ) : (
            <Pressable onPress={() => goLive(null)} style={{ padding: 16, paddingTop: 4 }}>
              <Text style={{ color: '#FFE2B8', fontFamily: fonts.regular, fontSize: 16 }}>{t.liveNone}</Text>
            </Pressable>
          )}
        </View>

        {/* 3. Rashifal */}
        <Pressable onPress={() => nav.navigate('Rashifal')} style={({ pressed }) => [{ backgroundColor: colors.card, borderRadius: radius.md, padding: 16, marginBottom: 16, borderWidth: 1, borderColor: colors.border, opacity: pressed ? 0.9 : 1 }, shadow]}>
          <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 6 }}>
            <Text style={{ fontSize: 26, marginRight: 8 }}>{rf ? RASHI_SYMBOL[prefs.myRashi!] : '🔮'}</Text>
            <Text style={{ flex: 1, fontFamily: fonts.bold, fontSize: 19, color: colors.maroon }}>{t.rashifalTitle}{prefs.myRashi != null ? ` · ${hi ? RASHIS_HI[prefs.myRashi] : RASHIS[prefs.myRashi]}` : ''}</Text>
            {rf ? <Stars n={rf.score} /> : null}
          </View>
          {rf ? <T numberOfLines={3}>{rf.text}</T> : <T soft>{t.pickRashi}</T>}
          <Text style={{ color: colors.saffronDark, fontFamily: fonts.bold, marginTop: 8 }}>{t.readMore} ›</Text>
        </Pressable>

        {/* 4. Shortcuts */}
        <View style={{ flexDirection: 'row', marginBottom: 16 }}>
          <Shortcut icon="📜" title={t.kundaliTitle} sub={t.kundaliSub} onPress={() => nav.navigate('Kundali')} style={{ marginRight: 12 }} />
          <Shortcut icon="🌅" title={t.greetTitle} sub={t.greetSub} onPress={() => nav.navigate('Create', { screen: 'Studio' })} />
        </View>
        <Pressable onPress={() => nav.navigate('Calendar', { screen: 'CalendarHome' })} style={({ pressed }) => [{ backgroundColor: '#FFF1DE', borderRadius: radius.md, padding: 16, borderWidth: 1, borderColor: colors.saffron, opacity: pressed ? 0.9 : 1 }]}>
          <T bold style={{ color: colors.maroon, marginBottom: 4 }}>📅 {t.panchangTitle}</T>
          <T soft style={{ fontSize: 16 }}>{`${pt.nakshatra}: ${hi ? p.nakshatraHi : p.nakshatra} · ${pt.yoga}: ${hi ? p.yogaHi : p.yoga}`}</T>
          {p.rahuKaal ? <T soft style={{ fontSize: 16 }}>{`${pt.rahu}: ${fmtIST(p.rahuKaal[0])} – ${fmtIST(p.rahuKaal[1])}`}</T> : null}
        </Pressable>
      </ScrollView>
      <Banner />
    </SafeAreaView>
  );
}

function Shortcut({ icon, title, sub, onPress, style }: { icon: string; title: string; sub: string; onPress: () => void; style?: any }) {
  return (
    <Pressable onPress={onPress} style={({ pressed }) => [{ flex: 1, backgroundColor: colors.card, borderRadius: radius.md, padding: 14, borderWidth: 1, borderColor: colors.border, opacity: pressed ? 0.9 : 1 }, shadow, style]}>
      <Text style={{ fontSize: 30 }}>{icon}</Text>
      <Text style={{ fontFamily: fonts.bold, fontSize: 17, color: colors.maroon, marginTop: 6 }}>{title}</Text>
      <Text style={{ fontFamily: fonts.regular, fontSize: 14, color: colors.textSoft, marginTop: 2 }} numberOfLines={3}>{sub}</Text>
    </Pressable>
  );
}
