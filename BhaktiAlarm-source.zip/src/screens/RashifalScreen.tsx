import React, { useMemo, useState } from 'react';
import { View, Text, Pressable, ScrollView, Dimensions } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import Share from 'react-native-share';
import { T, Button, Chip } from '../components/ui';
import { usePrefs } from '../lib/prefs';
import { RASHIS, RASHIS_HI, RASHIS_EN, RASHI_SYMBOL, RASHI_AKSHAR, RASHI_AKSHAR_EN } from '../lib/astro';
import { dailyRashifal, weeklyRashifal, monthlyRashifal, addDays, Daily, Period } from '../content/rashifal';
import { Banner } from '../lib/ads';
import { previewParam } from '../lib/webPreview';
import { playLink } from '../lib/config';
import { fmt, readsHindi } from '../i18n';
import { x } from '../i18n/extra';
import { colors, fonts, radius, shadow } from '../theme';

type Tab = 'today' | 'tomorrow' | 'weekly' | 'monthly';

export function Disclaimer() {
  return (
    <View style={{ backgroundColor: '#FFF1DE', borderRadius: radius.sm, padding: 12, marginTop: 16, borderWidth: 1, borderColor: colors.border }}>
      <Text style={{ fontFamily: fonts.regular, fontSize: 13, color: colors.textSoft, lineHeight: 19 }}>⚠️ {x().disclaimer}</Text>
    </View>
  );
}

const Stars = ({ n, size = 22 }: { n: number; size?: number }) => (
  <Text style={{ color: colors.gold, fontSize: size, letterSpacing: 2 }}>{'★'.repeat(n)}<Text style={{ color: '#E5D3B0' }}>{'★'.repeat(5 - n)}</Text></Text>
);

export function RashiGrid({ selected, onPick }: { selected: number | null; onPick: (i: number) => void }) {
  const hi = readsHindi();
  const W = (Dimensions.get('window').width - 40 - 16) / 3;
  return (
    <View style={{ flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between' }}>
      {RASHIS.map((r, i) => (
        <Pressable key={r} onPress={() => onPick(i)} accessibilityRole="button"
          style={({ pressed }) => [{ width: W, marginBottom: 8, padding: 8, borderRadius: radius.sm, alignItems: 'center', backgroundColor: selected === i ? colors.saffron : colors.card, borderWidth: 1, borderColor: selected === i ? colors.saffron : colors.border, opacity: pressed ? 0.85 : 1 }]}>
          <Text style={{ fontSize: 28, color: selected === i ? '#fff' : colors.maroon }}>{RASHI_SYMBOL[i]}</Text>
          <Text style={{ fontFamily: fonts.bold, fontSize: 16, color: selected === i ? '#fff' : colors.text }}>{hi ? RASHIS_HI[i] : RASHIS[i]}</Text>
          <Text style={{ fontFamily: fonts.regular, fontSize: 11, color: selected === i ? '#FFF3D6' : colors.textSoft, textAlign: 'center' }} numberOfLines={2}>{hi ? RASHI_AKSHAR[i] : RASHI_AKSHAR_EN[i]}</Text>
        </Pressable>
      ))}
    </View>
  );
}

function Section({ icon, title, text }: { icon: string; title: string; text: string }) {
  return (
    <View style={{ flexDirection: 'row', marginTop: 12 }}>
      <Text style={{ fontSize: 22, width: 34 }}>{icon}</Text>
      <View style={{ flex: 1 }}>
        <T bold style={{ fontSize: 16, color: colors.maroon }}>{title}</T>
        <T style={{ fontSize: 16 }}>{text}</T>
      </View>
    </View>
  );
}

export default function RashifalScreen() {
  const nav = useNavigation<any>();
  const { prefs, update } = usePrefs();
  const t = x().rashifal;
  const hi = readsHindi();
  const l = hi ? 'hi' : 'en';
  const [picking, setPicking] = useState(prefs.myRashi == null);
  const [tab, setTab] = useState<Tab>((previewParam('tab') as Tab) || 'today');
  const rashi = prefs.myRashi;

  const data = useMemo(() => {
    if (rashi == null) return null;
    const now = new Date();
    if (tab === 'today') return { kind: 'day' as const, d: dailyRashifal(rashi, now, l) };
    if (tab === 'tomorrow') return { kind: 'day' as const, d: dailyRashifal(rashi, addDays(now, 1), l) };
    if (tab === 'weekly') return { kind: 'period' as const, p: weeklyRashifal(rashi, now, l) };
    return { kind: 'period' as const, p: monthlyRashifal(rashi, now, l) };
  }, [rashi, tab, l]);

  const name = rashi != null ? (hi ? RASHIS_HI[rashi] : `${RASHIS[rashi]} (${RASHIS_EN[rashi]})`) : '';

  const share = () => {
    if (!data || rashi == null) return;
    const head = `${RASHI_SYMBOL[rashi]} ${name} · ${t[tab]}`;
    const body = data.kind === 'day'
      ? `${data.d.text}\n\n${t.career}: ${data.d.career}\n${t.money}: ${data.d.money}\n${t.family}: ${data.d.family}\n${t.health}: ${data.d.health}\n${t.upay}: ${data.d.upay}`
      : `${data.p.text}\n${data.p.planets.join('\n')}`;
    const msg = `${head}\n\n${body}\n\n${fmt(t.shareCaption, { rashi: hi ? RASHIS_HI[rashi] : RASHIS[rashi], link: playLink('rashifal') })}`;
    Share.open({ message: msg, failOnCancel: false }).catch(() => {});
  };

  if (picking || rashi == null) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.cream }}>
        <ScrollView contentContainerStyle={{ padding: 20, paddingBottom: 40 }}>
          <Text style={{ fontFamily: fonts.bold, fontSize: 24, color: colors.maroon }}>{t.chooseTitle}</Text>
          <T soft style={{ marginVertical: 8, fontSize: 16 }}>{t.chooseSub}</T>
          <RashiGrid selected={rashi} onPick={(i) => { update({ myRashi: i }); setPicking(false); }} />
          <Button kind="secondary" icon="📜" label={x().home.kundaliTitle} onPress={() => nav.navigate('Kundali')} style={{ marginTop: 12 }} />
          <Disclaimer />
        </ScrollView>
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: colors.cream }}>
      <ScrollView contentContainerStyle={{ padding: 20, paddingBottom: 40 }}>
        <Pressable onPress={() => setPicking(true)} style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 12 }}>
          <View style={{ width: 64, height: 64, borderRadius: 32, backgroundColor: colors.maroon, alignItems: 'center', justifyContent: 'center', marginRight: 12 }}>
            <Text style={{ fontSize: 34, color: '#FFE2B8' }}>{RASHI_SYMBOL[rashi]}</Text>
          </View>
          <View style={{ flex: 1 }}>
            <Text style={{ fontFamily: fonts.bold, fontSize: 24, color: colors.maroon }}>{name}</Text>
            <Text style={{ fontFamily: fonts.medium, color: colors.saffronDark }}>{t.change} ›</Text>
          </View>
        </Pressable>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap' }}>
          {(['today', 'tomorrow', 'weekly', 'monthly'] as Tab[]).map((k) => <Chip key={k} label={t[k]} selected={tab === k} onPress={() => setTab(k)} />)}
        </View>
        {data?.kind === 'day' ? <DayCard d={data.d} /> : data ? <PeriodCard p={data.p} /> : null}
        <Button icon="💬" label={t.share} onPress={share} style={{ marginTop: 16, backgroundColor: '#25A244' }} />
        <Disclaimer />
      </ScrollView>
      <Banner />
    </View>
  );
}

function DayCard({ d }: { d: Daily }) {
  const t = x().rashifal;
  return (
    <View style={[{ backgroundColor: colors.card, borderRadius: radius.md, padding: 16, marginTop: 4, borderWidth: 1, borderColor: colors.border }, shadow]}>
      <Stars n={d.score} size={26} />
      <T style={{ marginTop: 8, fontSize: 18, lineHeight: 27 }}>{d.text}</T>
      <Section icon="💼" title={t.career} text={d.career} />
      <Section icon="💰" title={t.money} text={d.money} />
      <Section icon="👨‍👩‍👧" title={t.family} text={d.family} />
      <Section icon="🌿" title={t.health} text={d.health} />
      <View style={{ flexDirection: 'row', marginTop: 14 }}>
        <View style={{ flex: 1, backgroundColor: colors.creamDeep, borderRadius: radius.sm, padding: 10, marginRight: 8 }}>
          <T soft style={{ fontSize: 13 }}>{t.color}</T><T bold>{d.color}</T>
        </View>
        <View style={{ flex: 1, backgroundColor: colors.creamDeep, borderRadius: radius.sm, padding: 10 }}>
          <T soft style={{ fontSize: 13 }}>{t.number}</T><T bold>{d.number}</T>
        </View>
      </View>
      <Section icon="🪔" title={t.upay} text={d.upay} />
    </View>
  );
}

function PeriodCard({ p }: { p: Period }) {
  const t = x().rashifal;
  return (
    <View style={[{ backgroundColor: colors.card, borderRadius: radius.md, padding: 16, marginTop: 4, borderWidth: 1, borderColor: colors.border }, shadow]}>
      <Stars n={p.score} size={26} />
      <T style={{ marginTop: 8, fontSize: 18, lineHeight: 27 }}>{p.text}</T>
      <Section icon="🪐" title={t.planets} text={p.planets.join('\n')} />
      <Section icon="✅" title={t.best} text={p.best.length ? p.best.join(', ') : t.none} />
      <Section icon="⚠️" title={t.careful} text={p.careful.length ? p.careful.join(', ') : t.none} />
      <Section icon="🪔" title={t.upay} text={p.upay} />
    </View>
  );
}
