import React, { useEffect, useState } from 'react';
import { View, Text, Pressable, TextInput, Alert, StyleSheet } from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';
import { Screen, Title, T, Button, Card, Chip, Toggle, Row } from '../components/ui';
import { Alarm, listAlarms, newAlarm, saveAlarm, deleteAlarm, testAlarm } from '../lib/alarms';
import { orderedDeities, trackById, allTracks } from '../content/catalog';
import { usePrefs } from '../lib/prefs';
import { s, fmt } from '../i18n';
import { colors, fonts, radius, size } from '../theme';

function Stepper({ value, onUp, onDown }: { value: string; onUp: () => void; onDown: () => void }) {
  return (
    <View style={{ alignItems: 'center' }}>
      <Pressable onPress={onUp} style={st.step} accessibilityLabel="increase"><Text style={st.stepTxt}>▲</Text></Pressable>
      <Text style={st.big}>{value}</Text>
      <Pressable onPress={onDown} style={st.step} accessibilityLabel="decrease"><Text style={st.stepTxt}>▼</Text></Pressable>
    </View>
  );
}

export default function AlarmEditScreen() {
  const nav = useNavigation<any>();
  const route = useRoute<any>();
  const { prefs } = usePrefs();
  const t = s().alarm;
  const [a, setA] = useState<Alarm>(() => {
    const existing = route.params?.id ? listAlarms().find((x) => x.id === route.params.id) : null;
    if (existing) return existing;
    const n = newAlarm();
    n.trackId = allTracks(prefs.region, prefs.familyDeity)[0]?.id ?? null;
    return n;
  });
  const isNew = !route.params?.id;
  useEffect(() => {
    const picked = route.params?.pickedTrack;
    if (picked) setA((x) => ({ ...x, trackId: picked, shuffle: false }));
  }, [route.params?.pickedTrack]);

  const set = (p: Partial<Alarm>) => setA((x) => ({ ...x, ...p }));
  const h12 = a.hour % 12 === 0 ? 12 : a.hour % 12;
  const pm = a.hour >= 12;
  const setH12 = (h: number, isPm: boolean) => set({ hour: (h % 12) + (isPm ? 12 : 0) });
  const toggleDay = (d: number) => set({ days: a.days.includes(d) ? a.days.filter((x) => x !== d) : [...a.days, d] });
  const togglePool = (d: string) => set({ deityPool: a.deityPool.includes(d) ? a.deityPool.filter((x) => x !== d) : [...a.deityPool, d] });

  const save = async () => {
    await saveAlarm({ ...a, enabled: true }, prefs.region, prefs.familyDeity);
    nav.goBack();
  };
  const remove = () => Alert.alert(t.deleteConfirm, '', [
    { text: s().common.cancel, style: 'cancel' },
    { text: s().common.delete, style: 'destructive', onPress: () => { deleteAlarm(a.id); nav.goBack(); } },
  ]);
  const test = async () => { await testAlarm(a, prefs.region, prefs.familyDeity); Alert.alert('⏰', t.testInfo); };
  const track = trackById(a.trackId);

  return (
    <Screen>
      <Title>{isNew ? t.add : t.edit}</Title>
      <Card style={{ alignItems: 'center', paddingVertical: 20 }}>
        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
          <Stepper value={String(h12)} onUp={() => setH12(h12 % 12 + 1, pm)} onDown={() => setH12(h12 === 1 ? 12 : h12 - 1, pm)} />
          <Text style={[st.big, { marginHorizontal: 6, minWidth: 0 }]}>:</Text>
          <Stepper value={a.minute.toString().padStart(2, '0')} onUp={() => set({ minute: (a.minute + 1) % 60 })} onDown={() => set({ minute: (a.minute + 59) % 60 })} />
          <View style={{ marginLeft: 16 }}>
            <Chip label="AM" selected={!pm} onPress={() => setH12(h12, false)} />
            <Chip label="PM" selected={pm} onPress={() => setH12(h12, true)} />
          </View>
        </View>
        <View style={{ flexDirection: 'row', marginTop: 8 }}>
          {[-10, -5, 5, 10].map((d) => (
            <Chip key={d} label={`${d > 0 ? '+' : ''}${d}m`} onPress={() => set({ minute: ((a.minute + d) % 60 + 60) % 60 })} />
          ))}
        </View>
      </Card>

      <T bold style={{ marginTop: 20, marginBottom: 8 }}>{t.repeat}</T>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
        {t.days.map((d, i) => (
          <Pressable key={i} onPress={() => toggleDay(i)} accessibilityLabel={t.dayNames[i]} style={[st.day, a.days.includes(i) && { backgroundColor: colors.saffron, borderColor: colors.saffron }]}>
            <Text style={{ fontFamily: fonts.bold, fontSize: 18, color: a.days.includes(i) ? colors.white : colors.text }}>{d}</Text>
          </Pressable>
        ))}
      </View>
      <View style={{ flexDirection: 'row', marginTop: 10, flexWrap: 'wrap' }}>
        <Chip label={t.everyday} onPress={() => set({ days: [0, 1, 2, 3, 4, 5, 6] })} />
        <Chip label={t.weekdays} onPress={() => set({ days: [1, 2, 3, 4, 5] })} />
        <Chip label={t.once} onPress={() => set({ days: [] })} />
      </View>

      <Card style={{ marginTop: 20 }}>
        <Row label={t.shuffle} value={t.shuffleHint} right={<Toggle value={a.shuffle} onChange={(v) => set({ shuffle: v })} />} />
        {a.shuffle ? (
          <View style={{ paddingTop: 12 }}>
            <T bold style={{ marginBottom: 8 }}>{t.deityPool}</T>
            <View style={{ flexDirection: 'row', flexWrap: 'wrap' }}>
              <Chip label={t.allDeities} selected={a.deityPool.length === 0} onPress={() => set({ deityPool: [] })} />
              {orderedDeities(prefs.region, prefs.familyDeity).map((d) => (
                <Chip key={d.id} label={d.short} selected={a.deityPool.includes(d.id)} onPress={() => togglePool(d.id)} />
              ))}
            </View>
          </View>
        ) : (
          <Row label={t.ringtone} value={track ? track.title : t.choose}
            onPress={() => nav.navigate('RingtonePicker', { selected: a.trackId })} />
        )}
        <Row label={t.vibrate} right={<Toggle value={a.vibrate} onChange={(v) => set({ vibrate: v })} />} />
        <View style={{ paddingTop: 12 }}>
          <T bold style={{ marginBottom: 8 }}>{t.snooze}</T>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap' }}>
            {[5, 10, 15].map((m) => <Chip key={m} label={fmt(t.minutes, { n: m })} selected={a.snoozeMinutes === m} onPress={() => set({ snoozeMinutes: m })} />)}
          </View>
        </View>
      </Card>

      <T bold style={{ marginTop: 20, marginBottom: 8 }}>{t.label}</T>
      <TextInput value={a.label} onChangeText={(v) => set({ label: v })} placeholder={t.labelPlaceholder} placeholderTextColor={colors.textSoft} style={st.input} />

      <Button big label={s().common.save} onPress={save} style={{ marginTop: 24 }} />
      <Button kind="secondary" icon="🔔" label={t.test} onPress={test} style={{ marginTop: 12 }} />
      {!isNew ? <Button kind="ghost" label={s().common.delete} onPress={remove} style={{ marginTop: 8 }} /> : null}
    </Screen>
  );
}

const st = StyleSheet.create({
  big: { fontFamily: fonts.bold, fontSize: 60, color: colors.maroon, minWidth: 80, textAlign: 'center' },
  step: { width: 72, height: 48, alignItems: 'center', justifyContent: 'center', borderRadius: 24, backgroundColor: colors.creamDeep },
  stepTxt: { fontSize: 22, color: colors.saffronDark },
  day: { width: 44, height: 44, borderRadius: 22, borderWidth: 1.5, borderColor: colors.border, backgroundColor: colors.white, alignItems: 'center', justifyContent: 'center' },
  input: { backgroundColor: colors.white, borderRadius: radius.md, borderWidth: 1.5, borderColor: colors.border, minHeight: 56, paddingHorizontal: 16, fontSize: size.body, fontFamily: fonts.regular, color: colors.text },
});
