import React, { useState } from 'react';
import { View, Text, TextInput, Modal, Pressable, Alert, StyleSheet } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Screen, Title, T, Card, Chip, Button } from '../components/ui';
import MicButton from '../components/MicButton';
import { usePrefs, FamilyDate } from '../lib/prefs';
import { scheduleFamilyReminder, cancelReminder } from '../lib/reminders';
import { s, fmt } from '../i18n';
import { colors, fonts, radius, size } from '../theme';

export function greetingFor(f: FamilyDate) {
  const t = s().family;
  return f.kind === 'birthday'
    ? { header: fmt(t.birthdayHeader, { name: f.name }), footer: t.birthdayFooter }
    : { header: fmt(t.anniversaryHeader, { name: f.name }), footer: t.anniversaryFooter };
}

export default function FamilyScreen() {
  const nav = useNavigation<any>();
  const { prefs, update } = usePrefs();
  const t = s().family;
  const [edit, setEdit] = useState<FamilyDate | null>(null);

  const sorted = [...prefs.family].sort((a, b) => {
    const now = new Date(); const base = (now.getMonth() + 1) * 100 + now.getDate();
    const k = (x: FamilyDate) => { const v = x.month * 100 + x.day; return v >= base ? v : v + 1300; };
    return k(a) - k(b);
  });

  const save = async (f: FamilyDate) => {
    if (!f.name.trim()) { Alert.alert('🙏', t.name); return; }
    await cancelReminder(prefs.familyNotifIds[f.id]);
    const nid = await scheduleFamilyReminder(f);
    const list = [...prefs.family.filter((x) => x.id !== f.id), { ...f, name: f.name.trim() }];
    await update({ family: list, familyNotifIds: { ...prefs.familyNotifIds, ...(nid ? { [f.id]: nid } : {}) } });
    setEdit(null);
  };
  const remove = async (f: FamilyDate) => {
    await cancelReminder(prefs.familyNotifIds[f.id]);
    const ids = { ...prefs.familyNotifIds }; delete ids[f.id];
    await update({ family: prefs.family.filter((x) => x.id !== f.id), familyNotifIds: ids });
    setEdit(null);
  };
  const greet = (f: FamilyDate, video = false) => {
    const g = greetingFor(f);
    if (video) nav.navigate('Create', { screen: 'VideoMaker', params: g, initial: false });
    else nav.navigate('Create', { screen: 'StudioEditor', params: { festivalSlug: 'general', ...g }, initial: false });
  };

  return (
    <Screen>
      <Title sub={t.sub}>{t.title}</Title>
      {sorted.length === 0 ? <T soft style={{ marginBottom: 16 }}>{t.empty}</T> : null}
      {sorted.map((f) => (
        <Card key={f.id} onPress={() => setEdit(f)} style={{ marginBottom: 12 }}>
          <View style={{ flexDirection: 'row', alignItems: 'center' }}>
            <Text style={{ fontSize: 34, marginRight: 12 }}>{f.kind === 'birthday' ? '🎂' : '💐'}</Text>
            <View style={{ flex: 1 }}>
              <T bold style={{ fontSize: 20 }}>{f.name}</T>
              <T soft>{f.relation ? f.relation + ' · ' : ''}{f.day} {t.months[f.month - 1]} · {f.kind === 'birthday' ? t.birthday : t.anniversary}</T>
            </View>
          </View>
          <View style={{ flexDirection: 'row', marginTop: 10 }}>
            <Button icon="🎨" label={t.greet} onPress={() => greet(f)} style={{ flex: 1, marginRight: 8 }} />
            <Button kind="secondary" icon="🎬" label={t.video} onPress={() => greet(f, true)} style={{ flex: 1 }} />
          </View>
        </Card>
      ))}
      <Button big icon="➕" label={t.add} onPress={() => setEdit({ id: 'f' + Date.now().toString(36), name: '', relation: '', kind: 'birthday', month: new Date().getMonth() + 1, day: new Date().getDate() })} style={{ marginTop: 8 }} />

      <Modal visible={!!edit} animationType="slide" onRequestClose={() => setEdit(null)}>
        {edit ? <Editor value={edit} onSave={save} onDelete={prefs.family.some((x) => x.id === edit.id) ? () => remove(edit) : undefined} onCancel={() => setEdit(null)} /> : null}
      </Modal>
    </Screen>
  );
}

function Editor({ value, onSave, onDelete, onCancel }: { value: FamilyDate; onSave: (f: FamilyDate) => void; onDelete?: () => void; onCancel: () => void }) {
  const t = s().family;
  const [f, setF] = useState(value);
  const days = new Date(2024, f.month, 0).getDate();
  return (
    <Screen>
      <Title>{f.kind === 'birthday' ? t.birthday : t.anniversary}</Title>
      <View style={{ flexDirection: 'row', marginBottom: 12 }}>
        <Chip label={'🎂 ' + t.birthday} selected={f.kind === 'birthday'} onPress={() => setF({ ...f, kind: 'birthday' })} />
        <Chip label={'💐 ' + t.anniversary} selected={f.kind === 'anniversary'} onPress={() => setF({ ...f, kind: 'anniversary' })} />
      </View>
      <T bold style={st.label}>{t.name}</T>
      <View style={{ flexDirection: 'row', alignItems: 'center' }}>
        <TextInput value={f.name} onChangeText={(name) => setF({ ...f, name })} style={[st.input, { flex: 1 }]} maxLength={30} />
        <MicButton onText={(name) => setF((x) => ({ ...x, name }))} />
      </View>
      <T bold style={st.label}>{t.relation}</T>
      <TextInput value={f.relation} onChangeText={(relation) => setF({ ...f, relation })} style={st.input} maxLength={20} />
      <T bold style={st.label}>{t.date}</T>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap' }}>
        {t.months.map((m, i) => <Chip key={m} label={m} selected={f.month === i + 1} onPress={() => setF({ ...f, month: i + 1, day: Math.min(f.day, new Date(2024, i + 1, 0).getDate()) })} />)}
      </View>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', marginTop: 6 }}>
        {Array.from({ length: days }, (_, i) => i + 1).map((d) => (
          <Pressable key={d} onPress={() => setF({ ...f, day: d })} style={[st.day, f.day === d && { backgroundColor: colors.saffron, borderColor: colors.saffron }]}>
            <Text style={{ fontFamily: fonts.bold, fontSize: 17, color: f.day === d ? colors.white : colors.text }}>{d}</Text>
          </Pressable>
        ))}
      </View>
      <Button big label={s().common.save} onPress={() => onSave(f)} style={{ marginTop: 20 }} />
      {onDelete ? <Button kind="danger" label={s().common.delete} onPress={onDelete} style={{ marginTop: 10 }} /> : null}
      <Button kind="ghost" label={s().common.cancel} onPress={onCancel} style={{ marginTop: 6 }} />
    </Screen>
  );
}

const st = StyleSheet.create({
  label: { marginTop: 14, marginBottom: 6 },
  input: { backgroundColor: colors.white, borderRadius: radius.md, borderWidth: 1.5, borderColor: colors.border, minHeight: 56, paddingHorizontal: 16, fontSize: size.body, fontFamily: fonts.regular, color: colors.text },
  day: { width: 46, height: 46, borderRadius: 23, borderWidth: 1.5, borderColor: colors.border, backgroundColor: colors.white, alignItems: 'center', justifyContent: 'center', margin: 4 },
});
