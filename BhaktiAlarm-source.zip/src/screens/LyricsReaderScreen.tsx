import React, { useEffect, useRef, useState } from 'react';
import { View, Text, ScrollView, StyleSheet } from 'react-native';
import { useRoute } from '@react-navigation/native';
import { useAudioPlayer, useAudioPlayerStatus } from 'expo-audio';
import { useKeepAwake } from 'expo-keep-awake';
import { Button, Chip } from '../components/ui';
import { lyricById } from '../content/devotion';
import { tracksFor } from '../content/catalog';
import { usePrefs } from '../lib/prefs';
import { speak, stopSpeaking } from '../lib/voice';
import { maybeShowInterstitial } from '../lib/ads';
import { s, fmt, readsHindi } from '../i18n';
import { colors, fonts } from '../theme';

const today = () => new Date().toISOString().slice(0, 10);
const yesterday = () => new Date(Date.now() - 86400e3).toISOString().slice(0, 10);

export default function LyricsReaderScreen() {
  useKeepAwake();
  const route = useRoute<any>();
  const { prefs, update } = usePrefs();
  const t = s().lyrics;
  const l = lyricById(route.params?.id)!;
  const [script, setScript] = useState<'hi' | 'en'>(readsHindi() ? 'hi' : 'en');
  const [fs, setFs] = useState(24);
  const [talking, setTalking] = useState(false);
  const track = tracksFor(l?.deity || '')[0];
  const player = useAudioPlayer(track?.source ?? null);
  const status = useAudioPlayerStatus(player);
  useEffect(() => () => { stopSpeaking(); }, []);

  if (!l) return null;
  const done = prefs.path.last === today();

  const markDone = async () => {
    if (done) return;
    const streak = prefs.path.last === yesterday() ? prefs.path.streak + 1 : 1;
    await update({ path: { last: today(), streak, best: Math.max(streak, prefs.path.best), done: [...prefs.path.done.slice(-30), l.id] } });
    maybeShowInterstitial();
  };
  const toggleSpeak = () => {
    if (talking) { stopSpeaking(); setTalking(false); return; }
    setTalking(true);
    speak(l.verses.map((v) => v.hi).join('\n'), { lang: 'hi-IN', onDone: () => setTalking(false) });
  };

  return (
    <View style={{ flex: 1, backgroundColor: colors.cream }}>
      <View style={st.bar}>
        <Chip label={t.hindi} selected={script === 'hi'} onPress={() => setScript('hi')} />
        <Chip label={t.roman} selected={script === 'en'} onPress={() => setScript('en')} />
        <View style={{ flex: 1 }} />
        <Chip label={t.smaller} onPress={() => setFs(Math.max(18, fs - 3))} />
        <Chip label={t.bigger} onPress={() => setFs(Math.min(40, fs + 3))} />
      </View>
      <ScrollView contentContainerStyle={{ padding: 20, paddingBottom: 30 }}>
        <Text style={st.title}>{script === 'hi' ? l.titleHi : l.title}</Text>
        {l.verses.map((v, i) => (
          <Text key={i} style={[st.verse, { fontSize: fs, lineHeight: fs * 1.6, fontFamily: script === 'hi' ? fonts.deva : fonts.regular }]}>
            {script === 'hi' ? v.hi : v.en}
          </Text>
        ))}
        <Button big label={done ? t.doneToday : t.done} onPress={markDone} style={{ marginTop: 20, backgroundColor: done ? '#2E7D32' : colors.saffron }} />
        {prefs.path.streak ? <Text style={st.streak}>{fmt(t.streak, { n: prefs.path.streak })}</Text> : null}
      </ScrollView>
      <View style={st.footer}>
        {track ? (
          <Button icon={status.playing ? '⏸️' : '▶️'} label={status.playing ? t.stop : t.play}
            onPress={() => (status.playing ? player.pause() : player.play())} style={{ flex: 1, marginRight: 8 }} />
        ) : null}
        <Button kind="secondary" icon={talking ? '⏹️' : '🔊'} label={talking ? t.stop : t.listen} onPress={toggleSpeak} style={{ flex: 1 }} />
      </View>
    </View>
  );
}

const st = StyleSheet.create({
  bar: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 12, paddingTop: 10, flexWrap: 'wrap' },
  title: { fontFamily: fonts.devaBold, fontSize: 28, color: colors.maroon, textAlign: 'center', marginBottom: 16 },
  verse: { color: colors.text, textAlign: 'center', marginBottom: 18 },
  streak: { fontFamily: fonts.bold, fontSize: 18, color: colors.maroon, textAlign: 'center', marginTop: 12 },
  footer: { flexDirection: 'row', padding: 12, borderTopWidth: 1, borderTopColor: colors.border, backgroundColor: colors.cream },
});
