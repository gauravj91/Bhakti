import React, { useEffect, useState } from 'react';
import { View, Text } from 'react-native';
import { useRoute, useNavigation } from '@react-navigation/native';
import { Screen, Title, T, Card, Button } from '../components/ui';
import { vratByKey, VRATS } from '../content/devotion';
import { speak, stopSpeaking } from '../lib/voice';
import { s, readsHindi } from '../i18n';
import { colors } from '../theme';

export default function VratGuideScreen() {
  const route = useRoute<any>();
  const nav = useNavigation<any>();
  const t = s().vrat;
  const key: string | undefined = route.params?.key;
  const [talking, setTalking] = useState(false);
  const hi = readsHindi();
  useEffect(() => () => { stopSpeaking(); }, []);

  if (!key) {
    return (
      <Screen>
        <Title>{t.all}</Title>
        {VRATS.map((v) => (
          <Card key={v.key} onPress={() => nav.push('VratGuide', { key: v.key })} style={{ marginBottom: 10 }}>
            <T bold style={{ fontSize: 20, color: colors.maroon }}>{hi ? v.nameHi : v.name}</T>
            <T soft numberOfLines={2}>{hi ? v.about.hi : v.about.en}</T>
          </Card>
        ))}
      </Screen>
    );
  }
  const v = vratByKey(key);
  if (!v) return null;
  const L = (b: { en: any; hi: any }) => (hi ? b.hi : b.en);
  const katha = L(v.katha) as string;

  const Section = ({ title, items }: { title: string; items: string[] }) => (
    <Card style={{ marginBottom: 12 }}>
      <T bold style={{ fontSize: 20, color: colors.maroon, marginBottom: 6 }}>{title}</T>
      {items.map((x, i) => <T key={i} style={{ marginBottom: 4 }}>•  {x}</T>)}
    </Card>
  );

  return (
    <Screen>
      <Title sub={hi ? v.name : v.nameHi}>{hi ? v.nameHi : v.name}</Title>
      <T style={{ marginBottom: 14 }}>{L(v.about)}</T>
      <Section title={t.rules} items={L(v.rules)} />
      <Section title={'✅ ' + t.eat} items={L(v.eat)} />
      <Section title={'🚫 ' + t.avoid} items={L(v.avoid)} />
      <Section title={'🪔 ' + t.puja} items={L(v.puja)} />
      <Card style={{ marginBottom: 12 }}>
        <T bold style={{ fontSize: 20, color: colors.maroon, marginBottom: 6 }}>📖 {t.katha}</T>
        <T style={{ lineHeight: 30 }}>{katha}</T>
        <Button icon={talking ? '⏹️' : '🔊'} label={talking ? t.stop : t.listen} style={{ marginTop: 14 }}
          onPress={() => {
            if (talking) { stopSpeaking(); setTalking(false); return; }
            setTalking(true); speak(katha, { onDone: () => setTalking(false) });
          }} />
      </Card>
    </Screen>
  );
}
