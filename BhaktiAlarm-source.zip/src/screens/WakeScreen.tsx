import React, { useEffect, useRef, useState } from 'react';
import { View, Image, Text, Pressable, StyleSheet, Animated, BackHandler } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ringing, stopRinging, snoozeRinging } from '../lib/alarms';
import { trackById, imageForTrack, deityImage, deityById } from '../content/catalog';
import { s, fmt } from '../i18n';
import { colors, fonts } from '../theme';

/** Calm, devotional full-screen wake view. No ads here, ever. */
export default function WakeScreen({ ringing, region, onDone }: { ringing: Ringing; region: string | null; onDone: () => void }) {
  const t = s().wake;
  const track = trackById(ringing.trackId);
  const img = imageForTrack(track, region) ?? deityImage(ringing.deityId, null, region);
  const deity = deityById(ringing.deityId || track?.deityId);
  const [clock, setClock] = useState(new Date());
  const pulse = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    const i = setInterval(() => setClock(new Date()), 10_000);
    const sub = BackHandler.addEventListener('hardwareBackPress', () => true);
    Animated.loop(Animated.sequence([
      Animated.timing(pulse, { toValue: 1, duration: 1800, useNativeDriver: true }),
      Animated.timing(pulse, { toValue: 0, duration: 1800, useNativeDriver: true }),
    ])).start();
    return () => { clearInterval(i); sub.remove(); };
  }, []);

  const hour = clock.getHours();
  const greeting = hour < 12 ? 'Shubh Prabhat' : hour < 17 ? 'Shubh Dopahar' : 'Shubh Sandhya';
  const hh = hour % 12 === 0 ? 12 : hour % 12;
  const time = `${hh}:${String(clock.getMinutes()).padStart(2, '0')}`;
  const scale = pulse.interpolate({ inputRange: [0, 1], outputRange: [1, 1.04] });
  const snoozeMin = ringing.snoozeMinutes || 5;

  return (
    <View style={StyleSheet.absoluteFill}>
      <LinearGradient colors={['#5A0F00', '#8B0000', '#C25E00']} style={StyleSheet.absoluteFill} />
      <View style={{ flex: 1, alignItems: 'center', paddingTop: 54 }}>
        <Text style={{ fontFamily: fonts.bold, fontSize: 64, color: '#FFF3D6' }}>{time}</Text>
        <Text style={{ fontFamily: fonts.medium, fontSize: 22, color: '#FFD9A0' }}>{greeting} 🙏</Text>
        {ringing.label ? <Text style={{ fontFamily: fonts.regular, fontSize: 18, color: '#FFE9C8', marginTop: 4 }}>{ringing.label}</Text> : null}
        <Animated.View style={{ marginTop: 22, padding: 6, borderRadius: 22, backgroundColor: colors.gold, transform: [{ scale }] }}>
          {img ? <Image source={img} style={{ width: 250, height: 312, borderRadius: 18 }} resizeMode="cover" /> : <View style={{ width: 250, height: 312 }} />}
        </Animated.View>
        <Text style={{ fontFamily: fonts.bold, fontSize: 22, color: '#FFF3D6', marginTop: 14 }}>{deity?.name ?? ''}</Text>
        {track ? <Text style={{ fontFamily: fonts.regular, fontSize: 16, color: '#FFD9A0' }}>{t.nowPlaying}: {track.title}</Text> : null}
      </View>
      <View style={{ padding: 24, paddingBottom: 40 }}>
        <Pressable accessibilityRole="button" onPress={() => { stopRinging(); onDone(); }}
          style={({ pressed }) => [st.btn, { backgroundColor: colors.cream, opacity: pressed ? 0.85 : 1 }]}>
          <Text style={{ fontFamily: fonts.bold, fontSize: 26, color: colors.maroon }}>{t.dismiss}</Text>
        </Pressable>
        <Pressable accessibilityRole="button" onPress={() => { snoozeRinging(snoozeMin); onDone(); }}
          style={({ pressed }) => [st.btn, { marginTop: 14, backgroundColor: 'rgba(255,255,255,0.12)', borderWidth: 2, borderColor: '#FFD9A0', opacity: pressed ? 0.85 : 1 }]}>
          <Text style={{ fontFamily: fonts.bold, fontSize: 22, color: '#FFF3D6' }}>💤 {fmt(t.snooze, { n: snoozeMin })}</Text>
        </Pressable>
      </View>
    </View>
  );
}
const st = StyleSheet.create({ btn: { minHeight: 76, borderRadius: 38, alignItems: 'center', justifyContent: 'center' } });
