// Bhakti Wallpapers (v1.2): set a deity darshan image or a calm greeting background as the phone wallpaper.
import React, { useMemo, useState } from 'react';
import { View, Text, Image, Pressable, SectionList, Dimensions, Modal, ActivityIndicator, Alert, ImageSourcePropType, ScrollView, useWindowDimensions } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Asset } from 'expo-asset';
import { File, Directory, Paths } from 'expo-file-system';
import Native from '../../modules/bhakti-alarm';
import { orderedDeities, deityImages } from '../content/catalog';
import { useRemoteTemplates, REMOTE_BASE } from '../lib/remoteTemplates';
import { usePrefs } from '../lib/prefs';
import { Banner } from '../lib/ads';
import Share from 'react-native-share';
import { x } from '../i18n/extra';
import { fmt } from '../i18n';
import { playLink } from '../lib/config';
import { colors, fonts, radius, shadow } from '../theme';

type Item = { key: string; label?: string; source: ImageSourcePropType };
type Target = 'home' | 'lock' | 'both';

// Deities whose artwork is still a placeholder are left out until the real image ships.
const PLACEHOLDER_DEITIES = new Set<string>([]);
const COLS = 3;

async function localFileFor(item: Item): Promise<string> {
  const src: any = item.source;
  if (typeof src === 'number') {
    const asset = Asset.fromModule(src);
    await asset.downloadAsync();
    if (!asset.localUri) throw new Error('asset');
    return asset.localUri;
  }
  const url: string = src.uri;
  const dir = new Directory(Paths.cache, 'wallpapers');
  if (!dir.exists) dir.create({ intermediates: true });
  const name = url.replace(REMOTE_BASE, '').replace(/[^a-z0-9._-]/gi, '_');
  const dest = new File(dir, name);
  if (!dest.exists) {
    try { await File.downloadFileAsync(url, dest); } catch { throw new Error('offline'); }
  }
  return dest.uri;
}

export default function WallpaperScreen() {
  const t = x().wallpaper;
  const { prefs } = usePrefs();
  const remote = useRemoteTemplates();
  const [sel, setSel] = useState<Item | null>(null);
  const [busy, setBusy] = useState(false);
  const W = (Dimensions.get('window').width - 40 - (COLS - 1) * 8) / COLS;
  const win = useWindowDimensions();
  // Preview stays small enough that the Set buttons are always on screen, even with large text.
  const prevH = Math.min(win.height * 0.38, (win.width * 0.7) / 0.8);

  const sections = useMemo(() => {
    const deities: Item[] = orderedDeities(prefs.region, prefs.familyDeity)
      .filter((d) => !PLACEHOLDER_DEITIES.has(d.id))
      .flatMap((d) => deityImages(d.id).map((img) => ({ key: img.id, label: d.short, source: img.source })));
    const bgs: Item[] = remote.filter((r) => r.category !== 'festival').map((r) => ({ key: r.id, source: r.source as any }));
    const rows = (list: Item[]) => {
      const out: Item[][] = [];
      for (let i = 0; i < list.length; i += COLS) out.push(list.slice(i, i + COLS));
      return out;
    };
    return [
      { title: t.deities, data: rows(deities) },
      { title: t.backgrounds, data: rows(bgs), empty: bgs.length === 0 },
    ];
  }, [remote, prefs.region, prefs.familyDeity, prefs.language]);

  const applyLive = async () => {
    if (!sel || busy) return;
    if (!Native) { Alert.alert(t.failed); return; }
    setBusy(true);
    try {
      const uri = await localFileFor(sel);
      setSel(null);
      Alert.alert(t.live.replace('✨ ', ''), t.liveHint, [{ text: 'OK', onPress: () => { Native!.setLiveWallpaper(uri).catch(() => Alert.alert(t.failed)); } }]);
    } catch (e: any) {
      Alert.alert(e?.message === 'offline' ? t.offline : t.failed);
    } finally {
      setBusy(false);
    }
  };

  const share = async () => {
    if (!sel || busy) return;
    try {
      const uri = await localFileFor(sel);
      await Share.open({ url: uri, type: 'image/jpeg', message: fmt(t.shareCaption, { link: playLink('wallpaper') }), failOnCancel: false });
    } catch (e: any) {
      if (e?.message === 'offline') Alert.alert(t.offline);
    }
  };

  const apply = async (target: Target) => {
    if (!sel || busy) return;
    if (!Native) { Alert.alert(t.failed); return; }
    setBusy(true);
    try {
      const uri = await localFileFor(sel);
      await Native.setWallpaper(uri, target);
      setSel(null);
      Alert.alert(t.done);
    } catch (e: any) {
      Alert.alert(e?.message === 'offline' ? t.offline : t.failed, e?.message && e.message !== 'offline' ? String(e.message).slice(0, 160) : undefined);
    } finally {
      setBusy(false);
    }
  };

  return (
    <SafeAreaView edges={['bottom']} style={{ flex: 1, backgroundColor: colors.cream }}>
      <SectionList
        sections={sections as any}
        keyExtractor={(row: Item[]) => row.map((i) => i.key).join('|')}
        contentContainerStyle={{ padding: 20, paddingTop: 12 }}
        stickySectionHeadersEnabled={false}
        ListHeaderComponent={<Text style={{ fontFamily: fonts.regular, fontSize: 16, color: colors.textSoft, marginBottom: 6 }}>{t.sub}</Text>}
        renderSectionHeader={({ section }: any) => (
          <View>
            <Text style={{ fontFamily: fonts.bold, fontSize: 21, color: colors.maroon, marginTop: 12, marginBottom: 10 }}>{section.title}</Text>
            {section.empty ? <View style={{ flexDirection: 'row', alignItems: 'center' }}><ActivityIndicator color={colors.saffron} /><Text style={{ marginLeft: 8, color: colors.textSoft, fontFamily: fonts.regular }}>{t.loading}</Text></View> : null}
          </View>
        )}
        renderItem={({ item: row }: { item: Item[] }) => (
          <View style={{ flexDirection: 'row', marginBottom: 8 }}>
            {row.map((it, i) => (
              <Pressable key={it.key} onPress={() => setSel(it)} accessibilityRole="button" accessibilityLabel={`${t.setOn} ${it.label ?? ''}`}
                style={({ pressed }) => [{ width: W, marginLeft: i ? 8 : 0, borderRadius: radius.md, overflow: 'hidden', backgroundColor: colors.creamDeep, opacity: pressed ? 0.85 : 1 }, shadow]}>
                <Image source={it.source} style={{ width: W, height: W * 1.25 }} resizeMode="cover" resizeMethod="resize" />
                {it.label ? <Text numberOfLines={1} style={{ position: 'absolute', left: 0, right: 0, bottom: 0, paddingVertical: 4, textAlign: 'center', backgroundColor: 'rgba(60,10,0,0.6)', color: '#FFF3D6', fontFamily: fonts.bold, fontSize: 13 }}>{it.label}</Text> : null}
              </Pressable>
            ))}
          </View>
        )}
      />
      <Banner />

      <Modal visible={!!sel} transparent animationType="fade" statusBarTranslucent onRequestClose={() => !busy && setSel(null)}>
        <View style={{ flex: 1, backgroundColor: 'rgba(20,5,0,0.94)' }}>
          <ScrollView contentContainerStyle={{ flexGrow: 1, justifyContent: 'center', alignItems: 'center', paddingHorizontal: 20, paddingTop: 40, paddingBottom: 32 }}>
            {sel ? <Image source={sel.source} style={{ height: prevH, aspectRatio: 0.8, borderRadius: radius.md }} resizeMode="cover" /> : null}
            <Text style={{ fontFamily: fonts.bold, fontSize: 20, color: '#FFE2B8', marginTop: 14, marginBottom: 10 }}>{busy ? t.setting : t.setOn}</Text>
            {busy ? <ActivityIndicator size="large" color={colors.saffron} /> : (
              <View style={{ width: '100%' }}>
                <View style={{ flexDirection: 'row' }}>
                  {(['home', 'lock'] as Target[]).map((k, i) => (
                    <Pressable key={k} onPress={() => apply(k)} accessibilityRole="button"
                      style={({ pressed }) => [{ flex: 1, marginLeft: i ? 10 : 0, backgroundColor: '#5D2E0A', borderRadius: radius.md, paddingVertical: 14, marginBottom: 10, alignItems: 'center', opacity: pressed ? 0.85 : 1 }]}>
                      <Text style={{ fontFamily: fonts.bold, fontSize: 17, color: '#FFF3D6' }} numberOfLines={1} adjustsFontSizeToFit>{t[k]}</Text>
                    </Pressable>
                  ))}
                </View>
                <Pressable onPress={() => apply('both')} accessibilityRole="button"
                  style={({ pressed }) => [{ backgroundColor: colors.saffron, borderRadius: radius.md, paddingVertical: 14, marginBottom: 10, alignItems: 'center', opacity: pressed ? 0.85 : 1 }]}>
                  <Text style={{ fontFamily: fonts.bold, fontSize: 18, color: '#FFF3D6' }}>{t.both}</Text>
                </Pressable>
                <Pressable onPress={applyLive} accessibilityRole="button"
                  style={({ pressed }) => [{ backgroundColor: '#7A1400', borderWidth: 2, borderColor: colors.gold, borderRadius: radius.md, paddingVertical: 14, marginBottom: 6, alignItems: 'center', opacity: pressed ? 0.85 : 1 }]}>
                  <Text style={{ fontFamily: fonts.bold, fontSize: 18, color: '#FFD27A' }}>{t.live}</Text>
                </Pressable>
                <Pressable onPress={share} accessibilityRole="button" style={{ paddingVertical: 12, alignItems: 'center' }}>
                  <Text style={{ fontFamily: fonts.bold, fontSize: 17, color: '#FFD27A' }}>📤 {t.share}</Text>
                </Pressable>
                <Pressable onPress={() => setSel(null)} accessibilityRole="button" style={{ paddingVertical: 12, alignItems: 'center' }}>
                  <Text style={{ fontFamily: fonts.medium, fontSize: 17, color: '#FFE2B8' }}>{t.close}</Text>
                </Pressable>
              </View>
            )}
          </ScrollView>
        </View>
      </Modal>
    </SafeAreaView>
  );
}
