import React, { useEffect, useMemo, useRef, useState } from 'react';
import { View, Image, Text, TextInput, Alert, ScrollView, Pressable, StyleSheet, Dimensions, ActivityIndicator, Platform } from 'react-native';
import { captureRef } from 'react-native-view-shot';
import { useRoute } from '@react-navigation/native';
import MicButton from '../components/MicButton';
import { useVideoPlayer, VideoView } from 'expo-video';
import * as MediaLibrary from 'expo-media-library';
import Native from '../../modules/bhakti-alarm';
import { Screen, Button, T, Chip } from '../components/ui';
import { orderedDeities, deityImages, tracksFor, deityById, devotionalHeader } from '../content/catalog';
import { fileUriFor } from '../lib/alarms';
import { usePrefs } from '../lib/prefs';
import { maybeShowInterstitial } from '../lib/ads';
import { PLAY_STORE_LINK } from '../lib/config';
import { s, fmt } from '../i18n';
import { colors, fonts, radius, shadow, size } from '../theme';

const OUT_W = 1080, OUT_H = 1920; // 9:16 = Reels / Shorts / WhatsApp Status
const LENGTHS = [15, 30, 60];
const APPS = { whatsapp: 'com.whatsapp', instagram: 'com.instagram.android', youtube: 'com.google.android.youtube' };

// Plays the finished video inside the app, with its bhajan, so the user sees it before sharing.
function FinishedVideo({ uri, w, h }: { uri: string; w: number; h: number }) {
  const player = useVideoPlayer(uri, (p) => { p.loop = true; p.play(); });
  return <VideoView player={player} style={{ width: w, height: h, borderRadius: 6, backgroundColor: '#000' }} contentFit="contain" nativeControls allowsFullscreen />;
}

export default function VideoMakerScreen() {
  const { prefs } = usePrefs();
  const route = useRoute<any>();
  const fixedHeader: string | undefined = route.params?.header;
  const t = s().video;
  const st0 = s().studio;
  const deities = useMemo(() => orderedDeities(prefs.region, prefs.familyDeity), [prefs.region, prefs.familyDeity]);
  const [deityId, setDeityId] = useState<string>(route.params?.deityId || deities[0]?.id || 'ganesh');
  const images = deityImages(deityId);
  const tracks = tracksFor(deityId);
  const [imageId, setImageId] = useState(images[0]?.id);
  const [trackId, setTrackId] = useState(tracks[0]?.id);
  const deity = deityById(deityId);
  const [header, setHeader] = useState(fixedHeader || devotionalHeader(deity?.id, s().defaults.devotional.header) + ' 🙏');
  const [footer, setFooter] = useState(route.params?.footer || prefs.footer || s().defaults.devotional.footer);
  const [seconds, setSeconds] = useState(30);
  const [progress, setProgress] = useState<number | null>(null);
  const [video, setVideo] = useState<string | null>(null);
  const shotRef = useRef<View>(null);

  // Switching deity resets picture, bhajan and the default greeting.
  useEffect(() => {
    setImageId(deityImages(deityId)[0]?.id);
    setTrackId(tracksFor(deityId)[0]?.id);
    if (!fixedHeader) setHeader(devotionalHeader(deityId, s().defaults.devotional.header) + ' 🙏');
    setVideo(null);
  }, [deityId]);
  useEffect(() => { setVideo(null); }, [imageId, trackId, header, footer, seconds]);
  useEffect(() => { if (route.params?.deityId) setDeityId(route.params.deityId); }, [route.params?.deityId]);

  useEffect(() => {
    const sub = Native?.addListener('onVideoProgress', (e: { progress: number }) => setProgress(e.progress));
    return () => sub?.remove();
  }, []);

  const picture = images.find((i) => i.id === imageId)?.source ?? images[0]?.source;
  const previewW = Math.min(Dimensions.get('window').width - 120, 300);
  const k = previewW / 360;

  const make = async () => {
    if (!Native) return;
    setProgress(0); setVideo(null);
    try {
      const imageUri = await captureRef(shotRef, { format: 'jpg', quality: 0.95, width: OUT_W, height: OUT_H, result: 'tmpfile' });
      const track = tracks.find((x) => x.id === trackId);
      const audioUri = track ? await fileUriFor(track) : '';
      const uri = await Native.makeVideo(JSON.stringify({ imageUri, audioUri, durationMs: seconds * 1000, width: OUT_W, height: OUT_H }));
      setVideo(uri);
    } catch (e: any) {
      Alert.alert('🙏', t.failed);
    } finally { setProgress(null); }
  };

  const caption = () => fmt(st0.shareCaption, { link: PLAY_STORE_LINK });
  const shareTo = (pkg: string) => { if (video) { Native?.shareVideo(video, pkg, caption()); maybeShowInterstitial(); } };
  const save = async () => {
    if (!video) return;
    // Android 10+ saves via MediaStore without any read permission (Play photo policy).
    if (Platform.OS !== 'android' || (Platform.Version as number) < 29) {
      const perm = await MediaLibrary.requestPermissionsAsync(true);
      if (!perm.granted) { Alert.alert(st0.needPermission); return; }
    }
    await MediaLibrary.saveToLibraryAsync(video);
    Alert.alert(t.saved);
  };

  const busy = progress !== null;
  return (
    <Screen>
      {/* Live preview = exactly the frame that becomes the video */}
      <View style={{ alignItems: 'center', marginBottom: 18 }}>
        {video ? <FinishedVideo uri={video} w={previewW} h={previewW * 16 / 9} /> : null}
        <View ref={shotRef} collapsable={false} style={{ display: video ? 'none' : 'flex', width: previewW, height: previewW * 16 / 9, borderRadius: 6, overflow: 'hidden', backgroundColor: colors.maroon }}>
          {picture ? <Image source={picture} style={{ position: 'absolute', top: 0, left: 0, width: previewW, height: previewW * 16 / 9 }} resizeMode="cover" /> : null}
          <View style={[st.band, { paddingTop: 26 * k, paddingBottom: 18 * k }]}>
            <Text style={[st.header, { fontSize: 34 * k, lineHeight: 42 * k }]} numberOfLines={2}>{header}</Text>
          </View>
          <View style={[st.footerWrap, { bottom: 58 * k }]}>
            <Text style={[st.footer, { fontSize: 20 * k, lineHeight: 27 * k, paddingHorizontal: 14 * k, paddingVertical: 7 * k }]} numberOfLines={2}>{footer}</Text>
          </View>
          <View style={[st.wm, { height: 26 * k }]}>
            <Text style={{ color: '#fff', fontSize: 12 * k, fontFamily: fonts.medium }}>🪔 {st0.watermark}</Text>
          </View>
        </View>
      </View>

      {video ? (
        <View>
          <T bold big style={{ textAlign: 'center', color: colors.maroon, marginBottom: 14 }}>{t.ready}</T>
          <Button big icon="💬" label={t.whatsapp} onPress={() => shareTo(APPS.whatsapp)} style={{ backgroundColor: '#25A244' }} />
          <T style={{ textAlign: 'center', color: colors.textSoft, fontSize: 15, marginTop: 6, marginBottom: 4 }}>💡 {t.statusHint}</T>
          <Button icon="📸" label={t.instagram} onPress={() => shareTo(APPS.instagram)} style={[st.full, { backgroundColor: '#C13584' }]} />
          <Button icon="▶️" label={t.youtube} onPress={() => shareTo(APPS.youtube)} style={[st.full, { backgroundColor: '#E62117' }]} />
          <Button kind="secondary" icon="⬇️" label={t.save} onPress={save} style={st.full} />
          <Button kind="secondary" icon="📤" label={t.more} onPress={() => shareTo('')} style={st.full} />
          <Button kind="ghost" label={t.makeAnother} onPress={() => setVideo(null)} style={{ marginTop: 8 }} />
        </View>
      ) : (
        <View>
          <T bold style={st.h}>{t.pickDeity}</T>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 6 }}>
            {deities.map((d) => {
              const img = deityImages(d.id)[0]?.source;
              const on = d.id === deityId;
              return (
                <Pressable key={d.id} onPress={() => setDeityId(d.id)} style={[st.deity, on && { borderColor: colors.saffron, backgroundColor: '#FFF1DE' }]}>
                  {img ? <Image source={img} style={st.deityImg} /> : <View style={[st.deityImg, { backgroundColor: d.color }]} />}
                  <Text style={st.deityName} numberOfLines={1}>{d.short}</Text>
                </Pressable>
              );
            })}
          </ScrollView>
          {images.length > 1 ? (
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', marginBottom: 6 }}>
              {images.map((im, i) => (
                <Pressable key={im.id} onPress={() => setImageId(im.id)} style={[st.thumb, imageId === im.id && { borderColor: colors.saffron }]}>
                  <Image source={im.source} style={{ width: 52, height: 70, borderRadius: 6 }} />
                </Pressable>
              ))}
            </View>
          ) : null}

          <T bold style={st.h}>{t.pickBhajan}</T>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap' }}>
            {tracks.map((tr) => <Chip key={tr.id} label={'🎵 ' + tr.title} selected={tr.id === trackId} onPress={() => setTrackId(tr.id)} />)}
          </View>

          <T bold style={st.h}>{t.texts}</T>
          <TextInput value={header} onChangeText={setHeader} style={st.input} maxLength={40} placeholder={st0.header} />
          <View style={{ flexDirection: 'row', alignItems: 'center', marginTop: 10 }}>
            <TextInput value={footer} onChangeText={setFooter} style={[st.input, { flex: 1 }]} maxLength={50} placeholder={st0.footer} />
            <MicButton onText={setFooter} />
          </View>

          <T bold style={st.h}>{t.length}</T>
          <View style={{ flexDirection: 'row' }}>
            {LENGTHS.map((n) => <Chip key={n} label={fmt(t.seconds, { n: String(n) })} selected={seconds === n} onPress={() => setSeconds(n)} />)}
          </View>

          {busy ? (
            <View style={st.busy}>
              <ActivityIndicator color={colors.maroon} size="large" />
              <T bold style={{ marginTop: 10, color: colors.maroon }}>{fmt(t.making, { p: String(progress ?? 0) })}</T>
            </View>
          ) : (
            <Button big icon="🎬" label={t.make} onPress={make} style={{ marginTop: 22 }} />
          )}
        </View>
      )}
    </Screen>
  );
}

const st = StyleSheet.create({
  h: { marginTop: 18, marginBottom: 8 },
  band: { position: 'absolute', top: 0, left: 0, right: 0, alignItems: 'center', backgroundColor: 'rgba(90,0,0,0.35)' },
  header: { fontFamily: fonts.bold, color: '#FFF3D6', textAlign: 'center', textShadowColor: 'rgba(0,0,0,0.6)', textShadowRadius: 6, paddingHorizontal: 12 },
  footerWrap: { position: 'absolute', left: 0, right: 0, alignItems: 'center' },
  footer: { fontFamily: fonts.bold, color: colors.maroon, backgroundColor: 'rgba(255,248,231,0.92)', borderRadius: 14, textAlign: 'center', overflow: 'hidden' },
  wm: { position: 'absolute', left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(0,0,0,0.45)', alignItems: 'center', justifyContent: 'center' },
  deity: { width: 100, alignItems: 'center', padding: 6, marginRight: 10, borderRadius: radius.md, borderWidth: 2, borderColor: colors.border, backgroundColor: colors.white },
  deityImg: { width: 70, height: 70, borderRadius: 35 },
  deityName: { fontFamily: fonts.bold, fontSize: 13, color: colors.text, marginTop: 6 },
  thumb: { borderWidth: 2, borderColor: 'transparent', borderRadius: 8, marginRight: 8, padding: 2 },
  input: { backgroundColor: colors.white, borderRadius: radius.md, borderWidth: 1.5, borderColor: colors.border, minHeight: 56, paddingHorizontal: 16, fontSize: size.body, fontFamily: fonts.regular, color: colors.text },
  busy: { alignItems: 'center', marginTop: 22, padding: 20, borderRadius: radius.md, backgroundColor: '#FFF1DE', ...shadow },
  full: { marginTop: 12 },
});
