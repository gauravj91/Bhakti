import React, { useCallback, useMemo } from 'react';
import { View, Image, Pressable, FlatList, Dimensions, Text } from 'react-native';
import { useFocusEffect, useNavigation } from '@react-navigation/native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Title } from '../components/ui';
import { orderedDeities, templeAssets, deityImages, templeName } from '../content/catalog';
import { darshanFor, ymd } from '../lib/dailyDarshan';
import { usePrefs } from '../lib/prefs';
import { Banner, maybeShowInterstitial } from '../lib/ads';
import { s, fmt } from '../i18n';
import { x } from '../i18n/extra';
import { colors, fonts, radius, shadow } from '../theme';

export const templeVisit = { returned: false };

export default function TempleListScreen() {
  const nav = useNavigation<any>();
  const { prefs } = usePrefs();
  const t = s().temple;
  const W = (Dimensions.get('window').width - 52) / 2;
  const today = ymd(new Date());
  const day = useMemo(() => darshanFor(today, prefs), [today, prefs.region, prefs.familyDeity, prefs.language]);
  const dayImg = deityImages(day.deityId)[0]?.source ?? templeAssets(day.deityId).image;

  // Interstitials only *between* temple visits, never inside darshan.
  useFocusEffect(useCallback(() => {
    if (templeVisit.returned) { templeVisit.returned = false; maybeShowInterstitial(); }
  }, []));

  return (
    <SafeAreaView edges={['top']} style={{ flex: 1, backgroundColor: colors.cream }}>
      <FlatList
        data={orderedDeities(prefs.region, prefs.familyDeity)}
        keyExtractor={(d) => d.id}
        numColumns={2}
        columnWrapperStyle={{ justifyContent: 'space-between' }}
        contentContainerStyle={{ padding: 20 }}
        ListHeaderComponent={
          <View>
            <Title sub={s().bhakti.subtitle}>{s().bhakti.title}</Title>
            <Pressable onPress={() => nav.navigate('TodayDarshan', { date: today })} accessibilityRole="button" accessibilityLabel={s().darshan.title}
              style={({ pressed }) => [{ flexDirection: 'row', alignItems: 'center', backgroundColor: '#7A1400', borderRadius: radius.md, overflow: 'hidden', marginBottom: 14, borderWidth: 2, borderColor: colors.gold, opacity: pressed ? 0.9 : 1 }, shadow]}>
              <Image source={dayImg} style={{ width: 110, height: 140 }} resizeMode="cover" />
              <View style={{ flex: 1, padding: 14 }}>
                <Text style={{ fontFamily: fonts.bold, fontSize: 16, color: '#FFD27A' }}>🙏 {s().darshan.title}</Text>
                <Text style={{ fontFamily: fonts.bold, fontSize: 22, color: '#FFF3D6', marginTop: 2 }} numberOfLines={2}>{day.deityName}</Text>
                <Text style={{ fontFamily: fonts.regular, fontSize: 15, color: '#FFE2B8', marginTop: 4 }} numberOfLines={2}>{day.tithiLine}</Text>
              </View>
              <Text style={{ fontSize: 28, color: '#FFF3D6', paddingRight: 14 }}>›</Text>
            </Pressable>
            {[
              { icon: '📺', title: s().bhakti.live, sub: s().bhakti.liveSub, go: 'LiveDarshan', bg: '#8B0000' },
              { icon: '📻', title: x().radio.title, sub: x().radio.sub, go: 'Radio', bg: '#7A2E00' },
              { icon: '📿', title: s().bhakti.jaap, sub: s().bhakti.jaapSub, go: 'Jaap', bg: '#5D2E0A' },
              { icon: '📖', title: s().bhakti.lyrics, sub: s().bhakti.lyricsSub, go: 'LyricsList', bg: '#B35900' },
              { icon: '🖼️', title: x().wallpaper.title, sub: x().wallpaper.sub, go: 'Wallpaper', bg: '#6B3A00' },
            ].map((r) => (
              <Pressable key={r.go} onPress={() => nav.navigate(r.go)} accessibilityRole="button"
                style={({ pressed }) => [{ flexDirection: 'row', alignItems: 'center', backgroundColor: r.bg, borderRadius: radius.md, padding: 16, marginBottom: 12, opacity: pressed ? 0.9 : 1 }, shadow]}>
                <Text style={{ fontSize: 36, marginRight: 14 }}>{r.icon}</Text>
                <View style={{ flex: 1 }}>
                  <Text style={{ fontFamily: fonts.bold, fontSize: 20, color: '#FFF3D6' }}>{r.title}</Text>
                  <Text style={{ fontFamily: fonts.regular, fontSize: 15, color: '#FFE2B8' }}>{r.sub}</Text>
                </View>
                <Text style={{ fontSize: 26, color: '#FFF3D6' }}>›</Text>
              </Pressable>
            ))}
            <Text style={{ fontFamily: fonts.bold, fontSize: 21, color: colors.maroon, marginTop: 8, marginBottom: 10 }}>🛕 {s().bhakti.temples}</Text>
          </View>
        }
        renderItem={({ item }) => (
          <Pressable onPress={() => nav.navigate('Darshan', { deityId: item.id })}
            style={({ pressed }) => [{ width: W, marginBottom: 12, borderRadius: radius.md, overflow: 'hidden', backgroundColor: colors.maroon, opacity: pressed ? 0.85 : 1 }, shadow]}>
            <Image source={templeAssets(item.id).image} style={{ width: W, height: W * 1.2 }} resizeMode="cover" />
            <View style={{ padding: 10, backgroundColor: colors.maroon }}>
              <Text style={{ fontFamily: fonts.bold, fontSize: 17, color: '#FFF3D6' }} numberOfLines={1}>{templeName(item.id, item.short, t.templeOf)}</Text>
            </View>
          </Pressable>
        )}
      />
      <Banner />
    </SafeAreaView>
  );
}
