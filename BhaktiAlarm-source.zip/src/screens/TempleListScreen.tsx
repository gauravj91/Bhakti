import React, { useCallback } from 'react';
import { View, Image, Pressable, FlatList, Dimensions, Text } from 'react-native';
import { useFocusEffect, useNavigation } from '@react-navigation/native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Title } from '../components/ui';
import { orderedDeities, templeAssets } from '../content/catalog';
import { usePrefs } from '../lib/prefs';
import { Banner, maybeShowInterstitial } from '../lib/ads';
import { s, fmt } from '../i18n';
import { colors, fonts, radius, shadow } from '../theme';

export const templeVisit = { returned: false };

export default function TempleListScreen() {
  const nav = useNavigation<any>();
  const { prefs } = usePrefs();
  const t = s().temple;
  const W = (Dimensions.get('window').width - 52) / 2;

  // Interstitials only *between* temple visits, never inside darshan.
  useFocusEffect(useCallback(() => {
    if (templeVisit.returned) { templeVisit.returned = false; maybeShowInterstitial(); }
  }, []));

  return (
    <SafeAreaView edges={['top']} style={{ flex: 1, backgroundColor: colors.cream }}>
      <FlatList
        data={orderedDeities(prefs.region, prefs.familyDeity)}
        keyExtractor={(d) => d.id}
        numColumns={2}
        columnWrapperStyle={{ justifyContent: 'space-between' }}
        contentContainerStyle={{ padding: 20 }}
        ListHeaderComponent={
          <View>
            <Title sub={s().bhakti.subtitle}>{s().bhakti.title}</Title>
            {[
              { icon: '📺', title: s().bhakti.live, sub: s().bhakti.liveSub, go: 'LiveDarshan', bg: '#8B0000' },
              { icon: '📿', title: s().bhakti.jaap, sub: s().bhakti.jaapSub, go: 'Jaap', bg: '#5D2E0A' },
              { icon: '📖', title: s().bhakti.lyrics, sub: s().bhakti.lyricsSub, go: 'LyricsList', bg: '#B35900' },
            ].map((x) => (
              <Pressable key={x.go} onPress={() => nav.navigate(x.go)} accessibilityRole="button"
                style={({ pressed }) => [{ flexDirection: 'row', alignItems: 'center', backgroundColor: x.bg, borderRadius: radius.md, padding: 16, marginBottom: 12, opacity: pressed ? 0.9 : 1 }, shadow]}>
                <Text style={{ fontSize: 36, marginRight: 14 }}>{x.icon}</Text>
                <View style={{ flex: 1 }}>
                  <Text style={{ fontFamily: fonts.bold, fontSize: 20, color: '#FFF3D6' }}>{x.title}</Text>
                  <Text style={{ fontFamily: fonts.regular, fontSize: 15, color: '#FFE2B8' }}>{x.sub}</Text>
                </View>
                <Text style={{ fontSize: 26, color: '#FFF3D6' }}>›</Text>
              </Pressable>
            ))}
            <Text style={{ fontFamily: fonts.bold, fontSize: 21, color: colors.maroon, marginTop: 8, marginBottom: 10 }}>🛕 {s().bhakti.temples}</Text>
          </View>
        }
        renderItem={({ item }) => (
          <Pressable onPress={() => nav.navigate('Darshan', { deityId: item.id })}
            style={({ pressed }) => [{ width: W, marginBottom: 12, borderRadius: radius.md, overflow: 'hidden', backgroundColor: colors.maroon, opacity: pressed ? 0.85 : 1 }, shadow]}>
            <Image source={templeAssets(item.id).image} style={{ width: W, height: W * 1.2 }} resizeMode="cover" />
            <View style={{ padding: 10, backgroundColor: colors.maroon }}>
              <Text style={{ fontFamily: fonts.bold, fontSize: 17, color: '#FFF3D6' }} numberOfLines={1}>{fmt(t.templeOf, { d: item.short })}</Text>
            </View>
          </Pressable>
        )}
      />
      <Banner />
    </SafeAreaView>
  );
}
