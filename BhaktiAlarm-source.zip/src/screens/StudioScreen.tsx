import React, { useState } from 'react';
import { View, Image, Pressable, FlatList, Dimensions, Text } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Title, T, Chip } from '../components/ui';
import { templatesFor, StudioCategory, festivalLabel, deityById } from '../content/catalog';
import { usePrefs } from '../lib/prefs';
import { useRemoteTemplates } from '../lib/remoteTemplates';
import { Banner } from '../lib/ads';
import { s } from '../i18n';
import { colors, radius, shadow, fonts } from '../theme';

const CATS: StudioCategory[] = ['morning', 'afternoon', 'evening', 'devotional', 'festival'];
function defaultCat(): StudioCategory {
  const h = new Date().getHours();
  return h < 12 ? 'morning' : h < 17 ? 'afternoon' : 'evening';
}

export default function StudioScreen() {
  const nav = useNavigation<any>();
  const { prefs } = usePrefs();
  const [cat, setCat] = useState<StudioCategory>(defaultCat());
  const t = s().studio;
  const remote = useRemoteTemplates();
  const items = templatesFor(cat, prefs.region, prefs.familyDeity, remote);
  const W = (Dimensions.get('window').width - 20 * 2 - 12) / 2;

  return (
    <SafeAreaView edges={['top']} style={{ flex: 1, backgroundColor: colors.cream }}>
      <FlatList
        data={items}
        keyExtractor={(i) => i.id}
        numColumns={2}
        columnWrapperStyle={{ justifyContent: 'space-between' }}
        contentContainerStyle={{ padding: 20 }}
        ListHeaderComponent={
          <View>
            <Title>{t.title}</Title>
            <Pressable onPress={() => nav.navigate('VideoMaker')} accessibilityRole="button"
              style={({ pressed }) => [{ flexDirection: 'row', alignItems: 'center', backgroundColor: colors.maroon, borderRadius: radius.md, padding: 16, marginBottom: 16, opacity: pressed ? 0.9 : 1 }, shadow]}>
              <Text style={{ fontSize: 40, marginRight: 14 }}>🎬</Text>
              <View style={{ flex: 1 }}>
                <Text style={{ color: '#FFF3D6', fontFamily: fonts.bold, fontSize: 20 }}>{s().video.entryTitle}</Text>
                <Text style={{ color: '#FFE2B8', fontFamily: fonts.regular, fontSize: 14, marginTop: 2 }}>{s().video.entrySub}</Text>
              </View>
              <Text style={{ color: '#FFF3D6', fontSize: 26 }}>›</Text>
            </Pressable>
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', marginBottom: 8 }}>
              {CATS.map((c) => <Chip key={c} label={t[c]} selected={cat === c} onPress={() => setCat(c)} />)}
            </View>
          </View>
        }
        renderItem={({ item }) => (
          <Pressable onPress={() => nav.navigate('StudioEditor', { templateId: item.id })}
            style={({ pressed }) => [{ width: W, marginBottom: 12, borderRadius: radius.md, overflow: 'hidden', backgroundColor: colors.white, opacity: pressed ? 0.85 : 1 }, shadow]}>
            <Image source={item.source} style={{ width: W, height: W * 1.25 }} resizeMode="cover" />
            <T style={{ fontSize: 15, padding: 8 }} bold>
              {item.festival ? festivalLabel(item.festival) : item.deityId ? deityById(item.deityId)?.name : t[item.category as StudioCategory]}
            </T>
          </Pressable>
        )}
      />
      <Banner />
    </SafeAreaView>
  );
}
