import React, { useMemo, useState } from 'react';
import { View, Text, TextInput, Pressable, ScrollView, Alert, StyleSheet } from 'react-native';
import Share from 'react-native-share';
import { T, Button, Chip } from '../components/ui';
import { usePrefs, NumPerson } from '../lib/prefs';
import { MULANK, mulankOf, bhagyankOf, mulankDaily } from '../content/mulank';
import { Disclaimer } from './RashifalScreen';
import { Banner } from '../lib/ads';
import { playLink } from '../lib/config';
import { readsHindi } from '../i18n';
import { colors, fonts, radius, shadow } from '../theme';

const S = {
  en: { title: 'Mulank · Numerology', add: 'Add person', name: 'Name', me: 'Me', dob: 'Date of birth', dd: 'Day', mm: 'Month', yyyy: 'Year', save: 'Save', cancel: 'Cancel',
    bad: 'Please enter a valid date of birth', mulank: 'Mulank', bhagyank: 'Bhagyank', planet: 'Ruling planet', deity: 'Deity', day: 'Lucky day', color: 'Lucky colour',
    today: 'Today', tomorrow: 'Tomorrow', luckyNo: 'Lucky number today', upay: 'Upay', nature: 'Nature', share: 'Share on WhatsApp', del: 'Remove this person?',
    intro: 'Enter a date of birth to see mulank, bhagyank and today’s reading.', caption: 'Check your mulank free on Bhakti Alarm:' },
  hi: { title: 'मूलांक · अंक ज्योतिष', add: 'व्यक्ति जोड़ें', name: 'नाम', me: 'मैं', dob: 'जन्म तिथि', dd: 'दिन', mm: 'महीना', yyyy: 'वर्ष', save: 'सेव करें', cancel: 'रद्द करें',
    bad: 'कृपया सही जन्म तिथि डालें', mulank: 'मूलांक', bhagyank: 'भाग्यांक', planet: 'स्वामी ग्रह', deity: 'देवता', day: 'शुभ दिन', color: 'शुभ रंग',
    today: 'आज', tomorrow: 'कल', luckyNo: 'आज का शुभ अंक', upay: 'उपाय', nature: 'स्वभाव', share: 'WhatsApp पर भेजें', del: 'इस व्यक्ति को हटाएँ?',
    intro: 'मूलांक, भाग्यांक और आज का फल देखने के लिए जन्म तिथि डालें।', caption: 'अपना मूलांक Bhakti Alarm पर मुफ़्त देखें:' },
};

function Box({ v, set, label, w, max }: { v: string; set: (s: string) => void; label: string; w: number; max: number }) {
  return (
    <View style={{ marginRight: 8 }}>
      <Text style={{ fontFamily: fonts.regular, fontSize: 13, color: colors.textSoft, marginBottom: 2 }}>{label}</Text>
      <TextInput value={v} onChangeText={(t) => set(t.replace(/\D/g, '').slice(0, max))} keyboardType="number-pad" placeholder={label}
        placeholderTextColor="#C9B49A" style={[st.input, { width: w, textAlign: 'center' }]} />
    </View>
  );
}

export default function MulankScreen() {
  const { prefs, update } = usePrefs();
  const l = readsHindi() ? 'hi' : 'en';
  const t = S[l];
  const fromKundali: NumPerson[] = prefs.kundalis.map((k) => ({ id: `k:${k.id}`, name: k.name, y: k.y, m: k.m, d: k.d }));
  const people = [...prefs.numPeople, ...fromKundali.filter((k) => !prefs.numPeople.some((p) => p.name === k.name && p.y === k.y && p.m === k.m && p.d === k.d))];
  const active = people.find((p) => p.id === prefs.numActive) || people[0];
  const [adding, setAdding] = useState(people.length === 0);
  const [day, setDay] = useState<0 | 1>(0);
  const [name, setName] = useState(''); const [dd, setDd] = useState(''); const [mm, setMm] = useState(''); const [yy, setYy] = useState('');

  const save = async () => {
    const d = +dd, m = +mm, y = +yy;
    const dt = new Date(y, m - 1, d);
    if (!(y >= 1900 && y <= new Date().getFullYear() && dt.getMonth() === m - 1 && dt.getDate() === d)) { Alert.alert(t.bad); return; }
    const p: NumPerson = { id: String(Date.now()), name: name.trim() || (prefs.numPeople.length ? `${t.name} ${prefs.numPeople.length + 1}` : t.me), y, m, d };
    await update({ numPeople: [p, ...prefs.numPeople].slice(0, 20), numActive: p.id });
    setName(''); setDd(''); setMm(''); setYy(''); setAdding(false);
  };

  const r = useMemo(() => {
    if (!active) return null;
    const mul = mulankOf(active.d);
    const date = new Date(); date.setDate(date.getDate() + day);
    return { mul, bha: bhagyankOf(active.y, active.m, active.d), info: MULANK[mul], daily: mulankDaily(mul, date, l) };
  }, [active?.id, day, l]);

  const share = () => {
    if (!r || !active) return;
    const msg = `🔢 ${active.name} · ${t.mulank} ${r.mul} · ${t.bhagyank} ${r.bha}\n${t.planet}: ${r.info.planet[l]}\n\n${day ? t.tomorrow : t.today}: ${r.daily.text}\n${t.luckyNo}: ${r.daily.luckyNumber}\n${t.upay}: ${r.daily.upay}\n\n🙏 ${t.caption} ${playLink('mulank')}`;
    Share.open({ message: msg, failOnCancel: false }).catch(() => {});
  };

  return (
    <View style={{ flex: 1, backgroundColor: colors.cream }}>
      <ScrollView contentContainerStyle={{ padding: 20, paddingBottom: 40 }} keyboardShouldPersistTaps="handled">
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', marginBottom: 8 }}>
          {people.map((p) => (
            <Chip key={p.id} label={p.name} selected={!adding && active?.id === p.id} onPress={() => { setAdding(false); update({ numActive: p.id }); }} />
          ))}
          <Chip label={`＋ ${t.add}`} selected={adding} onPress={() => setAdding(true)} />
        </View>

        {adding || !r || !active ? (
          <View style={[st.card, shadow]}>
            <T soft style={{ marginBottom: 8 }}>{t.intro}</T>
            <T bold>{t.name}</T>
            <TextInput value={name} onChangeText={setName} style={[st.input, { marginBottom: 10 }]} maxLength={40} placeholder={people.length ? '' : t.me} placeholderTextColor="#C9B49A" />
            <T bold>{t.dob}</T>
            <View style={{ flexDirection: 'row', marginTop: 4 }}>
              <Box v={dd} set={setDd} label={t.dd} w={64} max={2} />
              <Box v={mm} set={setMm} label={t.mm} w={64} max={2} />
              <Box v={yy} set={setYy} label={t.yyyy} w={90} max={4} />
            </View>
            <Button icon="🔢" label={t.save} onPress={save} style={{ marginTop: 14 }} />
            {people.length ? <Button kind="secondary" label={t.cancel} onPress={() => setAdding(false)} style={{ marginTop: 8 }} /> : null}
          </View>
        ) : (
          <>
            <Pressable onLongPress={() => !active.id.startsWith('k:') && Alert.alert(t.del, active.name, [{ text: '✓', style: 'destructive', onPress: () => update({ numPeople: prefs.numPeople.filter((p) => p.id !== active.id), numActive: null }) }, { text: '✕', style: 'cancel' }])}
              style={[st.card, shadow, { flexDirection: 'row', alignItems: 'center' }]}>
              <View style={st.big}><Text style={st.bigNum}>{r.mul}</Text><Text style={st.bigLbl}>{t.mulank}</Text></View>
              <View style={[st.big, { backgroundColor: colors.saffron }]}><Text style={st.bigNum}>{r.bha}</Text><Text style={st.bigLbl}>{t.bhagyank}</Text></View>
              <View style={{ flex: 1, marginLeft: 4 }}>
                <T bold style={{ color: colors.maroon }}>{active.name}</T>
                <T soft style={{ fontSize: 14 }}>{`${String(active.d).padStart(2, '0')}.${String(active.m).padStart(2, '0')}.${active.y}`}</T>
              </View>
            </Pressable>

            <View style={[st.card, shadow]}>
              <Row k={t.planet} v={r.info.planet[l]} /><Row k={t.deity} v={r.info.deity[l]} />
              <Row k={t.day} v={r.info.day[l]} /><Row k={t.color} v={r.info.color[l]} />
              <T bold style={{ marginTop: 8, color: colors.maroon }}>{t.nature}</T><T>{r.info.trait[l]}</T>
            </View>

            <View style={{ flexDirection: 'row', marginTop: 4 }}>
              <Chip label={t.today} selected={day === 0} onPress={() => setDay(0)} />
              <Chip label={t.tomorrow} selected={day === 1} onPress={() => setDay(1)} />
            </View>
            <View style={[st.card, shadow]}>
              <Text style={{ color: colors.gold, fontSize: 26, letterSpacing: 2 }}>{'★'.repeat(r.daily.score)}<Text style={{ color: '#E5D3B0' }}>{'★'.repeat(5 - r.daily.score)}</Text></Text>
              <T style={{ marginTop: 8, fontSize: 18, lineHeight: 27 }}>{r.daily.text}</T>
              <Row k={t.luckyNo} v={String(r.daily.luckyNumber)} />
              <T bold style={{ marginTop: 8, color: colors.maroon }}>🪔 {t.upay}</T><T>{r.daily.upay}</T>
            </View>
            <Button icon="💬" label={t.share} onPress={share} style={{ marginTop: 8, backgroundColor: '#25A244' }} />
          </>
        )}
        <Disclaimer />
      </ScrollView>
      <Banner />
    </View>
  );
}

function Row({ k, v }: { k: string; v: string }) {
  return (
    <View style={{ flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 6, borderBottomWidth: StyleSheet.hairlineWidth, borderColor: colors.border }}>
      <T soft style={{ fontSize: 15 }}>{k}</T><T bold style={{ fontSize: 15, flexShrink: 1, textAlign: 'right', marginLeft: 8 }}>{v}</T>
    </View>
  );
}

const st = StyleSheet.create({
  card: { backgroundColor: colors.card, borderRadius: radius.md, padding: 16, marginTop: 8, borderWidth: 1, borderColor: colors.border },
  input: { backgroundColor: '#fff', borderWidth: 1, borderColor: colors.border, borderRadius: radius.sm, paddingHorizontal: 12, paddingVertical: 10, fontSize: 18, fontFamily: fonts.regular, color: colors.text },
  big: { width: 72, height: 72, borderRadius: 36, backgroundColor: colors.maroon, alignItems: 'center', justifyContent: 'center', marginRight: 10 },
  bigNum: { fontFamily: fonts.bold, fontSize: 30, color: '#FFE2B8', lineHeight: 34 },
  bigLbl: { fontFamily: fonts.regular, fontSize: 11, color: '#FFE2B8' },
});
