import React, { useCallback, useState } from 'react';
import { View, Text } from 'react-native';
import { useFocusEffect, useNavigation } from '@react-navigation/native';
import { Screen, Title, T, Button, Card, Toggle } from '../components/ui';
import { Alarm, listAlarms, saveAlarm, describeDays, fmtTime, permissionsStatus, openExactAlarmSettings, openFullScreenSettings, alarmEngineAvailable } from '../lib/alarms';
import { trackById } from '../content/catalog';
import { usePrefs } from '../lib/prefs';
import { ensureNotificationPermission } from '../lib/reminders';
import { Banner } from '../lib/ads';
import { s } from '../i18n';
import { colors, fonts } from '../theme';

export default function AlarmListScreen() {
  const nav = useNavigation<any>();
  const { prefs } = usePrefs();
  const [alarms, setAlarms] = useState<Alarm[]>([]);
  const [perm, setPerm] = useState(permissionsStatus());
  const t = s().alarm;

  useFocusEffect(useCallback(() => { setAlarms(listAlarms()); setPerm(permissionsStatus()); }, []));

  const toggle = async (a: Alarm, v: boolean) => {
    const next = { ...a, enabled: v };
    setAlarms((xs) => xs.map((x) => (x.id === a.id ? next : x)));
    await saveAlarm(next, prefs.region, prefs.familyDeity);
    setAlarms(listAlarms());
  };

  const fixPerms = async () => {
    if (!perm.notifications) await ensureNotificationPermission();
    else if (!perm.exact) openExactAlarmSettings();
    else if (!perm.fullScreen) openFullScreenSettings();
    setTimeout(() => setPerm(permissionsStatus()), 800);
  };
  const needsPerm = !perm.exact || !perm.notifications || !perm.fullScreen;
  const fsOnly = perm.exact && perm.notifications;

  return (
    <View style={{ flex: 1, backgroundColor: colors.cream }}>
      <Screen>
        <Title>{t.title}</Title>
        {!alarmEngineAvailable ? <T soft>{t.unavailable}</T> : null}
        {needsPerm ? (
          <Card style={{ marginBottom: 16, backgroundColor: '#FFF1DE', borderColor: colors.saffron }}>
            <T bold>{fsOnly ? t.fullScreenTitle : t.permTitle}</T>
            <T soft style={{ marginVertical: 8 }}>{fsOnly ? t.fullScreenBody : t.permBody}</T>
            <Button label={t.permButton} onPress={fixPerms} />
          </Card>
        ) : null}
        {alarms.length === 0 ? <T soft style={{ marginVertical: 24, textAlign: 'center' }}>{t.empty}</T> : null}
        {alarms.map((a) => {
          const { time, ampm } = fmtTime(a.hour, a.minute);
          const track = trackById(a.trackId);
          const sub = a.shuffle ? `🔀 ${t.shuffle}` : track ? `🎵 ${track.title}` : '';
          return (
            <Card key={a.id} style={{ marginBottom: 14 }} onPress={() => nav.navigate('AlarmEdit', { id: a.id })}>
              <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                <View style={{ flex: 1 }}>
                  <Text style={{ fontFamily: fonts.bold, fontSize: 44, color: a.enabled ? colors.maroon : colors.textSoft }}>
                    {time}<Text style={{ fontSize: 20 }}> {ampm}</Text>
                  </Text>
                  <T soft>{[a.label, describeDays(a.days, t.dayNames, t.everyday, t.weekdays, t.once)].filter(Boolean).join(' · ')}</T>
                  {sub ? <T soft style={{ fontSize: 16 }}>{sub}</T> : null}
                </View>
                <Toggle value={a.enabled} onChange={(v) => toggle(a, v)} />
              </View>
            </Card>
          );
        })}
        <Button big icon="⏰" label={t.add} onPress={() => nav.navigate('AlarmEdit', { id: null })} style={{ marginTop: 8 }} />
      </Screen>
      <Banner />
    </View>
  );
}
