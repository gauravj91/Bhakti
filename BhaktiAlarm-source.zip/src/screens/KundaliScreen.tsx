import React, { useMemo, useState } from 'react';
import { View, Text, TextInput, Pressable, ScrollView, Alert, ActivityIndicator, Dimensions, StyleSheet } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { T, Button, Card, Chip } from '../components/ui';
import NorthChart from '../components/NorthChart';
import { Disclaimer } from './RashifalScreen';
import { usePrefs, KundaliProfile } from '../lib/prefs';
import { kundaliFor, birthMoment, currentDasha, RASHIS, RASHIS_HI, NAKSHATRAS, NAKSHATRAS_HI, PLANETS, PLANETS_HI, PLANET_ABBR, PLANET_ABBR_HI } from '../lib/astro';
import { REGION_CITY } from '../lib/panchang';
import { Banner } from '../lib/ads';
import { previewParam } from '../lib/webPreview';
import { readsHindi } from '../i18n';
import { x } from '../i18n/extra';
import { colors, fonts, radius, size, shadow } from '../theme';

type Place = { name: string; lat: number; lon: number; tz: number };
const OFFLINE: Place[] = [
  ...Object.values(REGION_CITY).filter((c, i, a) => a.findIndex((d) => d.name === c.name) === i).map((c) => ({ ...c, tz: 5.5 })),
  { name: 'Varanasi', lat: 25.3176, lon: 82.9739, tz: 5.5 }, { name: 'Pune', lat: 18.5204, lon: 73.8567, tz: 5.5 },
  { name: 'Surat', lat: 21.1702, lon: 72.8311, tz: 5.5 }, { name: 'Indore', lat: 22.7196, lon: 75.8577, tz: 5.5 },
  { name: 'Amritsar', lat: 31.634, lon: 74.8723, tz: 5.5 }, { name: 'Ludhiana', lat: 30.901, lon: 75.8573, tz: 5.5 },
  { name: 'Kathmandu', lat: 27.7172, lon: 85.324, tz: 5.75 },
];

/** UTC offset (hours) of an IANA zone on a date; null if the phone cannot tell. */
function zoneOffset(tz: string, at: Date): number | null {
  try {
    const parts = new Intl.DateTimeFormat('en-US', { timeZone: tz, hourCycle: 'h23', year: 'numeric', month: 'numeric', day: 'numeric', hour: 'numeric', minute: 'numeric' }).formatToParts(at);
    const g = (k: string) => Number(parts.find((p) => p.type === k)?.value);
    const local = Date.UTC(g('year'), g('month') - 1, g('day'), g('hour') % 24, g('minute'));
    const off = Math.round(((local - at.getTime()) / 3600e3) * 4) / 4;
    return Number.isFinite(off) ? off : null;
  } catch { return null; }
}

async function searchPlaces(q: string, y: number, m: number, d: number): Promise<(Place & { label: string; tzGuess: boolean })[]> {
  const res = await fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(q)}&count=8&language=en&format=json`);
  const j = await res.json();
  return (j.results || []).map((r: any) => {
    const at = new Date(Date.UTC(y || 2000, (m || 1) - 1, d || 1, 6));
    let tz = r.country_code === 'IN' ? 5.5 : r.country_code === 'NP' ? 5.75 : zoneOffset(r.timezone, at);
    const tzGuess = tz == null;
    return { name: r.name, label: [r.name, r.admin1, r.country].filter(Boolean).join(', '), lat: r.latitude, lon: r.longitude, tz: tz ?? 0, tzGuess };
  });
}

const fmtTz = (h: number) => `UTC${h >= 0 ? '+' : '−'}${Math.floor(Math.abs(h))}:${String(Math.round((Math.abs(h) % 1) * 60)).padStart(2, '0')}`;
const pad = (n: number) => String(n).padStart(2, '0');
const fmtDate = (d: Date) => `${pad(d.getDate())}.${pad(d.getMonth() + 1)}.${d.getFullYear()}`;

export default function KundaliScreen() {
  const { prefs, update } = usePrefs();
  const t = x().kundali;
  const [view, setView] = useState<string | 'new' | null>(previewParam('kid') || (prefs.kundalis.length ? null : 'new'));
  const current = prefs.kundalis.find((k) => k.id === view);

  if (view === 'new') return <KundaliForm onDone={(id) => setView(id)} onCancel={prefs.kundalis.length ? () => setView(null) : undefined} />;
  if (current) return <KundaliResult k={current} onBack={() => setView(null)} />;

  return (
    <View style={{ flex: 1, backgroundColor: colors.cream }}>
      <ScrollView contentContainerStyle={{ padding: 20, paddingBottom: 40 }}>
        <Text style={st.h1}>{t.saved}</Text>
        {prefs.kundalis.map((k) => (
          <Card key={k.id} onPress={() => setView(k.id)} style={{ marginBottom: 10 }}>
            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
              <View style={{ flex: 1 }}>
                <T bold style={{ color: colors.maroon }}>📜 {k.name}</T>
                <T soft style={{ fontSize: 15 }}>{`${pad(k.d)}.${pad(k.m)}.${k.y} · ${pad(k.hh)}:${pad(k.mm)} · ${k.place}`}</T>
              </View>
              <Pressable hitSlop={10} onPress={() => Alert.alert(t.deleteConfirm, k.name, [{ text: x().kundali.delete, style: 'destructive', onPress: () => update({ kundalis: prefs.kundalis.filter((z) => z.id !== k.id) }) }, { text: '✕', style: 'cancel' }])}>
                <Text style={{ fontSize: 20, color: colors.textSoft }}>🗑</Text>
              </Pressable>
            </View>
          </Card>
        ))}
        <Button big icon="➕" label={t.make} onPress={() => setView('new')} style={{ marginTop: 8 }} />
        <Disclaimer />
      </ScrollView>
      <Banner />
    </View>
  );
}

function NumBox({ value, onChange, placeholder, w = 64, max }: { value: string; onChange: (v: string) => void; placeholder: string; w?: number; max: number }) {
  return (
    <View style={{ marginRight: 8 }}>
      <Text style={{ fontFamily: fonts.regular, fontSize: 13, color: colors.textSoft, marginBottom: 2 }}>{placeholder}</Text>
      <TextInput value={value} onChangeText={(v) => onChange(v.replace(/\D/g, '').slice(0, max))} keyboardType="number-pad" placeholder={placeholder}
        placeholderTextColor="#C9B49A" style={[st.input, { width: w, textAlign: 'center' }]} />
    </View>
  );
}

function KundaliForm({ onDone, onCancel }: { onDone: (id: string) => void; onCancel?: () => void }) {
  const { prefs, update } = usePrefs();
  const t = x().kundali;
  const [name, setName] = useState('');
  const [d, setD] = useState(''); const [m, setM] = useState(''); const [y, setY] = useState('');
  const [hh, setHh] = useState(''); const [mm, setMm] = useState(''); const [pm, setPm] = useState(false);
  const [q, setQ] = useState('');
  const [busy, setBusy] = useState(false);
  const [results, setResults] = useState<(Place & { label: string; tzGuess?: boolean })[] | null>(null);
  const [place, setPlace] = useState<(Place & { label: string; tzGuess?: boolean }) | null>(null);
  const [msg, setMsg] = useState('');

  const search = async () => {
    if (!q.trim()) return;
    setBusy(true); setMsg('');
    try {
      const r = await searchPlaces(q.trim(), +y, +m, +d);
      setResults(r); if (!r.length) setMsg(t.noPlace);
    } catch {
      setMsg(t.offline);
      setResults(OFFLINE.map((p) => ({ ...p, label: p.name })));
    } finally { setBusy(false); }
  };

  const save = async () => {
    const D = +d, M = +m, Y = +y; let H = +hh; const Mi = +(mm || 0);
    if (!D || !M || !Y || D > 31 || M > 12 || Y < 1900 || Y > 2100 || hh === '' || H > 12 || Mi > 59 || !place) { Alert.alert(t.invalid); return; }
    if (H === 12) H = 0; if (pm) H += 12;
    const k: KundaliProfile = { id: 'k' + Date.now().toString(36), name: name.trim() || t.title, y: Y, m: M, d: D, hh: H, mm: Mi, place: place.name, lat: place.lat, lon: place.lon, tz: place.tz };
    await update({ kundalis: [k, ...prefs.kundalis].slice(0, 20) });
    onDone(k.id);
  };

  return (
    <ScrollView style={{ flex: 1, backgroundColor: colors.cream }} contentContainerStyle={{ padding: 20, paddingBottom: 60 }} keyboardShouldPersistTaps="handled">
      <Text style={st.h1}>{t.title}</Text>
      <T soft style={{ fontSize: 15, marginBottom: 12 }}>{t.sub}</T>

      <Text style={st.label}>{t.name}</Text>
      <TextInput value={name} onChangeText={setName} style={st.input} maxLength={40} />

      <Text style={st.label}>{t.dob}</Text>
      <View style={{ flexDirection: 'row' }}>
        <NumBox value={d} onChange={setD} placeholder={t.day} max={2} />
        <NumBox value={m} onChange={setM} placeholder={t.month} max={2} />
        <NumBox value={y} onChange={setY} placeholder={t.year} w={96} max={4} />
      </View>

      <Text style={st.label}>{t.tob}</Text>
      <View style={{ flexDirection: 'row', alignItems: 'flex-end' }}>
        <NumBox value={hh} onChange={setHh} placeholder={t.hour} max={2} />
        <NumBox value={mm} onChange={setMm} placeholder={t.minute} max={2} />
        <Chip label="AM" selected={!pm} onPress={() => setPm(false)} />
        <Chip label="PM" selected={pm} onPress={() => setPm(true)} />
      </View>
      <T soft style={{ fontSize: 13 }}>{t.unknownTime}</T>

      <Text style={st.label}>{t.place}</Text>
      {place ? (
        <Card style={{ marginBottom: 8 }} onPress={() => { setPlace(null); setResults(null); }}>
          <T bold>📍 {place.label}</T>
          <T soft style={{ fontSize: 14 }}>{`${place.lat.toFixed(2)}, ${place.lon.toFixed(2)} · ${t.timezone} ${fmtTz(place.tz)}`}</T>
        </Card>
      ) : (
        <>
          <View style={{ flexDirection: 'row' }}>
            <TextInput value={q} onChangeText={setQ} onSubmitEditing={search} placeholder={t.placeHint} placeholderTextColor="#C9B49A" style={[st.input, { flex: 1, marginRight: 8 }]} returnKeyType="search" />
            <Button label={busy ? t.searching : t.search} onPress={search} disabled={busy} style={{ paddingHorizontal: 16 }} />
          </View>
          {busy ? <ActivityIndicator style={{ marginTop: 8 }} color={colors.saffron} /> : null}
          {msg ? <T soft style={{ marginTop: 6, fontSize: 15 }}>{msg}</T> : null}
          {results?.map((r, i) => (
            <Pressable key={i} onPress={() => setPlace(r)} style={({ pressed }) => [st.result, pressed && { backgroundColor: colors.creamDeep }]}>
              <T>{r.label}</T>
            </Pressable>
          ))}
        </>
      )}
      {place?.tzGuess ? (
        <View style={{ marginTop: 4 }}>
          <T soft style={{ fontSize: 14 }}>{t.timezone}: {fmtTz(place.tz)}</T>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', marginTop: 4 }}>
            {[-8, -5, -4, 0, 1, 2, 3, 4, 5.5, 8, 10].map((z) => <Chip key={z} label={fmtTz(z)} selected={place.tz === z} onPress={() => setPlace({ ...place, tz: z })} />)}
          </View>
        </View>
      ) : null}

      <Button big icon="📜" label={t.make} onPress={save} style={{ marginTop: 20 }} />
      {onCancel ? <Button kind="ghost" label="✕" onPress={onCancel} style={{ marginTop: 8 }} /> : null}
      <Disclaimer />
    </ScrollView>
  );
}

function KundaliResult({ k, onBack }: { k: KundaliProfile; onBack: () => void }) {
  const nav = useNavigation<any>();
  const { prefs, update } = usePrefs();
  const t = x().kundali;
  const hi = readsHindi();
  const K = useMemo(() => kundaliFor(birthMoment(k.y, k.m, k.d, k.hh, k.mm, k.tz), k.lat, k.lon), [k.id]);
  const S = Math.min(Dimensions.get('window').width - 40, 420);
  const abbr = hi ? PLANET_ABBR_HI : PLANET_ABBR;
  const rName = (i: number) => (hi ? RASHIS_HI[i] : RASHIS[i]);
  const houses: string[][] = Array.from({ length: 12 }, () => []);
  K.planets.forEach((p) => houses[p.house - 1].push(abbr[p.i] + (p.retro && p.i < 7 ? (hi ? '(व)' : '(R)') : '')));
  // Fit up to six planets into a small house by pairing them on one line.
  const fitted = houses.map((h) => (h.length > 3 ? h.reduce<string[]>((a, v, i) => (i % 2 ? (a[a.length - 1] += ' ' + v, a) : [...a, v]), []) : h));
  houses.length = 0; fitted.forEach((f) => houses.push(f));
  const { maha, antar } = currentDasha(K);
  const pn = (i: number) => (hi ? PLANETS_HI[i] : PLANETS[i]);

  return (
    <View style={{ flex: 1, backgroundColor: colors.cream }}>
      <ScrollView contentContainerStyle={{ padding: 20, paddingBottom: 40 }}>
        <Pressable onPress={onBack}><Text style={{ color: colors.saffronDark, fontFamily: fonts.medium, marginBottom: 6 }}>‹ {t.saved}</Text></Pressable>
        <Text style={st.h1}>{k.name}</Text>
        <T soft style={{ fontSize: 15 }}>{`${pad(k.d)}.${pad(k.m)}.${k.y} · ${pad(k.hh)}:${pad(k.mm)} · ${k.place}`}</T>

        <View style={{ flexDirection: 'row', flexWrap: 'wrap', marginTop: 12 }}>
          <Fact label={t.lagna} value={rName(K.lagnaSign)} />
          <Fact label={t.rashi} value={rName(K.moonSign)} />
          <Fact label={t.nakshatra} value={`${hi ? NAKSHATRAS_HI[K.moonNak] : NAKSHATRAS[K.moonNak]} · ${t.pada} ${K.moonPada}`} wide />
        </View>
        {prefs.myRashi !== K.moonSign ? (
          <Button kind="secondary" icon="🔮" label={t.useRashi} onPress={() => { update({ myRashi: K.moonSign }); nav.navigate('Rashifal'); }} style={{ marginTop: 4 }} />
        ) : null}

        <Text style={st.h2}>{t.chart}</Text>
        <View style={{ alignItems: 'center' }}><NorthChart size={S} lagnaSign={K.lagnaSign} houses={houses} /></View>
        <T soft style={{ fontSize: 13, marginTop: 4 }}>{t.retro}</T>

        <Text style={st.h2}>{t.planets}</Text>
        <View style={[{ backgroundColor: colors.card, borderRadius: radius.md, borderWidth: 1, borderColor: colors.border, overflow: 'hidden' }, shadow]}>
          <Row cells={[t.planet, t.sign, t.degree, t.house]} head />
          {K.planets.map((p) => (
            <Row key={p.i} cells={[`${pn(p.i)}${p.retro && p.i < 7 ? (hi ? ' (व)' : ' (R)') : ''}`, rName(p.sign), `${Math.floor(p.deg)}° ${pad(Math.floor((p.deg % 1) * 60))}′`, String(p.house)]} />
          ))}
        </View>

        <Text style={st.h2}>{t.dasha}</Text>
        <Card>
          {maha ? <T>{`${t.mahadasha}: `}<T bold>{pn(maha.lord)}</T>{` (${fmtDate(maha.start)} – ${fmtDate(maha.end)})`}</T> : null}
          {antar ? <T style={{ marginTop: 4 }}>{`${t.antardasha}: `}<T bold>{pn(antar.lord)}</T>{` (${fmtDate(antar.start)} – ${fmtDate(antar.end)})`}</T> : null}
          <View style={{ marginTop: 10 }}>
            {K.dashas.filter((dd) => dd.end > K.birth).slice(0, 9).map((dd, i) => (
              <T key={i} soft style={{ fontSize: 15, color: dd === maha ? colors.maroon : colors.textSoft }}>{`${dd === maha ? '▶ ' : '   '}${pn(dd.lord)}  ${fmtDate(dd.start < K.birth ? K.birth : dd.start)} – ${fmtDate(dd.end)}`}</T>
            ))}
          </View>
        </Card>

        <Text style={st.h2}>{t.manglik}</Text>
        <Card><T>{K.manglik ? t.manglikYes : t.manglikNo}</T></Card>

        <Disclaimer />
      </ScrollView>
      <Banner />
    </View>
  );
}

function Fact({ label, value, wide }: { label: string; value: string; wide?: boolean }) {
  return (
    <View style={{ width: wide ? '100%' : '48%', marginRight: wide ? 0 : '4%', backgroundColor: colors.card, borderRadius: radius.sm, padding: 12, marginBottom: 10, borderWidth: 1, borderColor: colors.border }}>
      <T soft style={{ fontSize: 13 }}>{label}</T>
      <T bold style={{ color: colors.maroon }}>{value}</T>
    </View>
  );
}
function Row({ cells, head }: { cells: string[]; head?: boolean }) {
  return (
    <View style={{ flexDirection: 'row', paddingVertical: 8, paddingHorizontal: 10, backgroundColor: head ? colors.creamDeep : undefined, borderBottomWidth: 1, borderBottomColor: colors.border }}>
      {cells.map((c, i) => <Text key={i} style={{ flex: i === 0 ? 1.4 : 1, fontFamily: head ? fonts.bold : fonts.regular, fontSize: 15, color: colors.text }}>{c}</Text>)}
    </View>
  );
}

const st = StyleSheet.create({
  h1: { fontFamily: fonts.bold, fontSize: 24, color: colors.maroon, marginBottom: 4 },
  h2: { fontFamily: fonts.bold, fontSize: 20, color: colors.maroon, marginTop: 20, marginBottom: 8 },
  label: { fontFamily: fonts.bold, fontSize: 16, color: colors.text, marginTop: 14, marginBottom: 6 },
  input: { backgroundColor: colors.white, borderRadius: radius.md, borderWidth: 1.5, borderColor: colors.border, minHeight: 52, paddingHorizontal: 14, fontSize: size.body, fontFamily: fonts.regular, color: colors.text },
  result: { paddingVertical: 12, paddingHorizontal: 8, borderBottomWidth: 1, borderBottomColor: colors.border },
});
