// "Aaj ka darshan": the deity of the day, today's tithi and a blessing, ready to share.
// Opened from the morning notification, the Bhakti hub and the Calendar. No ads on this screen.
import React, { useMemo } from 'react';
import { View, Image, Text, Dimensions, StyleSheet } from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';
import { Screen, T, Button, Card } from '../components/ui';
import { deityImages, templeAssets } from '../content/catalog';
import { darshanFor, ymd } from '../lib/dailyDarshan';
import { usePrefs } from '../lib/prefs';
import { s, fmt, readsHindi } from '../i18n';
import { colors, fonts, radius, shadow } from '../theme';

export default function TodayDarshanScreen() {
  const nav = useNavigation<any>();
  const route = useRoute<any>();
  const { prefs } = usePrefs();
  const t = s().darshan;
  const p = s().panchang;
  const date: string = /^\d{4}-\d{2}-\d{2}$/.test(route.params?.date || '') ? route.params.date : ymd(new Date());
  const x = useMemo(() => darshanFor(date, prefs), [date, prefs.region, prefs.familyDeity, prefs.language]);
  const img = deityImages(x.deityId)[0];
  const source = img?.source ?? templeAssets(x.deityId).image;
  const W = Dimensions.get('window').width - 40;

  const [y, m, d] = date.split('-').map(Number);
  const dateLabel = new Date(y, m - 1, d).toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
  const deva = readsHindi();
  const rows: [string, string][] = [
    [p.tithi, deva ? x.panchang.tithiHi : x.panchang.tithi],
    [t.paksha, x.panchang.paksha === 'Shukla' ? p.shukla : p.krishna],
    [p.month, deva ? x.panchang.monthHi : x.panchang.month],
  ];
  const fest = x.festivals.slice(0, 2).map((f) => f.name).join(', ');
  const header = `${s().defaults.morning.header} 🙏`;

  const share = () => {
    const params = img
      ? { templateId: `deity-${img.id}`, header }
      : { festivalSlug: 'general', header };
    nav.navigate('Create', { screen: 'StudioEditor', params, initial: false });
  };
  const video = () => nav.navigate('Create', { screen: 'VideoMaker', params: { deityId: x.deityId, header }, initial: false });

  return (
    <Screen>
      <Text style={st.kicker}>🙏 {t.title}</Text>
      <Text style={st.deity}>{x.deityName}</Text>
      <View style={[st.imgWrap, { width: W, height: W * 1.15 }]}>
        <Image source={source} style={{ width: W, height: W * 1.15 }} resizeMode="cover" accessibilityLabel={x.deityName} />
      </View>

      <Card style={{ marginTop: 18 }}>
        <T bold style={{ color: colors.maroon }}>{dateLabel}</T>
        {fest ? <T bold style={{ color: colors.saffronDark, marginTop: 4 }}>🪔 {fmt(t.todayIs, { f: fest })}</T> : null}
        <View style={{ marginTop: 8 }}>
          {rows.map(([k, v]) => (
            <View key={k} style={st.row}>
              <T soft>{k}</T>
              <T bold>{v}</T>
            </View>
          ))}
        </View>
        <T soft style={{ fontSize: 14, marginTop: 8 }}>{fmt(p.forCity, { city: x.panchang.city.name })}</T>
      </Card>

      <Text style={st.blessing}>{fmt(t.blessing, { deity: x.deityName })}</Text>

      <Button big icon="💬" label={t.whatsapp} onPress={share} style={{ marginTop: 20, backgroundColor: '#25A244' }} />
      <Button kind="secondary" icon="🎬" label={t.video} onPress={video} style={{ marginTop: 12 }} />
    </Screen>
  );
}

const st = StyleSheet.create({
  kicker: { fontFamily: fonts.bold, fontSize: 20, color: colors.saffronDark },
  deity: { fontFamily: fonts.bold, fontSize: 32, color: colors.maroon, marginTop: 2, marginBottom: 14 },
  imgWrap: { borderRadius: radius.md, overflow: 'hidden', backgroundColor: colors.maroon, ...shadow },
  row: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: colors.border },
  blessing: { fontFamily: fonts.bold, fontSize: 22, lineHeight: 32, color: colors.maroon, textAlign: 'center', marginTop: 22, paddingHorizontal: 8 },
});
