import React, { useEffect, useMemo, useRef, useState } from 'react';
import { View, Image, Text, TextInput, Alert, StyleSheet, Dimensions, Platform } from 'react-native';
import { useRoute } from '@react-navigation/native';
import { captureRef } from 'react-native-view-shot';
import * as MediaLibrary from 'expo-media-library';
import * as Sharing from 'expo-sharing';
import Share, { Social } from 'react-native-share';
import { Screen, Button, T } from '../components/ui';
import MicButton from '../components/MicButton';
import { templateById, templatesForFestival, deityById, festivalLabel, devotionalHeader } from '../content/catalog';
import { usePrefs } from '../lib/prefs';
import { maybeShowInterstitial } from '../lib/ads';
import { PLAY_STORE_LINK } from '../lib/config';
import { s, fmt } from '../i18n';
import { x } from '../i18n/extra';
import { colors, fonts, radius, size } from '../theme';

const EXPORT_W = 1080; // 4:5 => 1080x1350, which WhatsApp keeps without resizing

export default function StudioEditorScreen() {
  const route = useRoute<any>();
  const { prefs, update } = usePrefs();
  const t = s().studio;
  const tpl = useMemo(() => {
    if (route.params?.festivalSlug) return templatesForFestival(route.params.festivalSlug)[0];
    return templateById(route.params?.templateId, prefs.region);
  }, [route.params]);

  const defaults = useMemo(() => {
    const d = s().defaults;
    if (!tpl) return { header: '', footer: '' };
    const festivalName = route.params?.festivalName || festivalLabel(tpl.festival);
    const base = tpl.category === 'festival' ? d.festival : d[tpl.category];
    if (route.params?.header) return { header: route.params.header, footer: route.params.footer || base.footer };
    return {
      header: tpl.header || (tpl.category === 'devotional' ? devotionalHeader(tpl.deityId, base.header) : fmt(base.header, { deity: deityById(tpl.deityId)?.short || 'Krishna', festival: festivalName })),
      footer: tpl.footer || base.footer,
    };
  }, [tpl]);

  const [header, setHeader] = useState(defaults.header);
  const [footer, setFooter] = useState(defaults.footer);
  // Sender name, shown as "From {name}". Older versions kept the name in the remembered footer.
  const cleanName = (v?: string | null) => (v || '').replace(/^[\s\-–—~]+/, '').replace(/^from\s+/i, '').trim();
  const [name, setName] = useState(cleanName(prefs.senderName ?? prefs.footer));
  const fromLine = name.trim() ? fmt(x().from.line, { name: name.trim() }) : '';
  // The editor stays mounted in the Create stack; new params (e.g. from Aaj ka darshan) must refill the texts.
  const firstParams = useRef(route.params);
  useEffect(() => {
    if (route.params === firstParams.current) return;
    firstParams.current = route.params;
    setHeader(defaults.header); setFooter(defaults.footer);
  }, [route.params]);
  const [busy, setBusy] = useState(false);
  const shotRef = useRef<View>(null);
  const previewW = Dimensions.get('window').width - 40;

  if (!tpl) return <Screen><T>Template not found.</T></Screen>;

  // The app link travels as message text (tappable in WhatsApp), not baked into the picture.
  const caption = () => fmt(t.shareCaption, { link: PLAY_STORE_LINK });
  const render = () => captureRef(shotRef, { format: 'jpg', quality: 0.92, width: EXPORT_W, height: EXPORT_W * 1.25, result: 'tmpfile' });

  const afterExport = async () => {
    const n = name.trim();
    if (n !== (prefs.senderName || '')) await update({ senderName: n || null });
    maybeShowInterstitial();
  };

  const download = async () => {
    setBusy(true);
    try {
      // Android 10+ saves via MediaStore without any read permission (Play photo policy).
      if (Platform.OS !== 'android' || (Platform.Version as number) < 29) {
        const perm = await MediaLibrary.requestPermissionsAsync(true);
        if (!perm.granted) { Alert.alert(t.needPermission); return; }
      }
      const uri = await render();
      await MediaLibrary.saveToLibraryAsync(uri);
      Alert.alert(t.saved);
      await afterExport();
    } catch (e: any) { Alert.alert('Error', String(e?.message || e)); } finally { setBusy(false); }
  };

  const shareWhatsApp = async () => {
    setBusy(true);
    try {
      const uri = await render();
      try {
        await Share.shareSingle({ social: Social.Whatsapp, url: uri, type: 'image/jpeg', filename: 'bhakti', message: caption() } as any);
      } catch {
        await Share.open({ url: uri, type: 'image/jpeg', message: caption(), failOnCancel: false });
      }
      await afterExport();
    } catch {} finally { setBusy(false); }
  };

  const shareAny = async () => {
    setBusy(true);
    try {
      const uri = await render();
      try { await Share.open({ url: uri, type: 'image/jpeg', message: caption(), failOnCancel: false }); }
      catch { await Sharing.shareAsync(uri, { mimeType: 'image/jpeg' }); }
      await afterExport();
    } catch {} finally { setBusy(false); }
  };

  // Text scales with the card width so the preview matches the export exactly.
  const k = previewW / 360;
  return (
    <Screen>
      <View ref={shotRef} collapsable={false} style={{ width: previewW, height: previewW * 1.25, borderRadius: 4, overflow: 'hidden', backgroundColor: colors.maroon }}>
        <Image source={tpl.source} style={{ position: "absolute", top: 0, left: 0, width: previewW, height: previewW * 1.25 }} resizeMode="cover" />
        <View style={[st.band, { top: 0, paddingTop: 14 * k, paddingBottom: 18 * k }]}>
          <Text style={[st.header, { fontSize: 30 * k, lineHeight: 38 * k }]} numberOfLines={2}>{header}</Text>
        </View>
        <View style={[st.footerWrap, { bottom: 22 * k }]}>
          <View style={[st.footerPill, { paddingHorizontal: 14 * k, paddingVertical: 6 * k }]}>
            {footer.trim() ? <Text style={[st.footer, { fontSize: 16 * k, lineHeight: 21 * k }]} numberOfLines={2}>{footer}</Text> : null}
            {fromLine ? <Text style={[st.from, { fontSize: 18 * k, lineHeight: 24 * k }]} numberOfLines={1}>{fromLine}</Text> : null}
          </View>
        </View>
        <View style={[st.wm, { height: 18 * k }]}>
          <Text style={{ color: '#fff', fontSize: 10 * k, fontFamily: fonts.medium }} numberOfLines={1}>
            🪔 {t.watermark}
          </Text>
        </View>
      </View>

      <T bold style={{ marginTop: 18, marginBottom: 6 }}>{t.header}</T>
      <TextInput value={header} onChangeText={setHeader} style={st.input} maxLength={60} />
      <T bold style={{ marginTop: 14, marginBottom: 6 }}>{x().from.wish}</T>
      <View style={{ flexDirection: 'row', alignItems: 'center' }}>
        <TextInput value={footer} onChangeText={setFooter} style={[st.input, { flex: 1 }]} maxLength={60} />
        <MicButton onText={setFooter} />
      </View>
      <T bold style={{ marginTop: 14, marginBottom: 6 }}>{x().from.label}</T>
      <View style={{ flexDirection: 'row', alignItems: 'center' }}>
        <TextInput value={name} onChangeText={setName} placeholder={x().from.placeholder} placeholderTextColor={colors.textSoft} style={[st.input, { flex: 1 }]} maxLength={40} />
        <MicButton onText={setName} />
      </View>

      <Button big icon="⬇️" label={t.download} onPress={download} disabled={busy} style={{ marginTop: 20 }} />
      <Button icon="💬" label={t.whatsapp} onPress={shareWhatsApp} disabled={busy} style={{ marginTop: 12, backgroundColor: '#25A244' }} />
      <Button kind="secondary" icon="📤" label={t.share} onPress={shareAny} disabled={busy} style={{ marginTop: 12 }} />
    </Screen>
  );
}

const st = StyleSheet.create({
  band: { position: 'absolute', left: 0, right: 0, alignItems: 'center', backgroundColor: 'rgba(90,0,0,0.35)' },
  header: { fontFamily: fonts.bold, color: '#FFF3D6', textAlign: 'center', textShadowColor: 'rgba(0,0,0,0.6)', textShadowRadius: 6, paddingHorizontal: 12 },
  footerWrap: { position: 'absolute', left: 0, right: 0, alignItems: 'center' },
  footerPill: { backgroundColor: 'rgba(255,248,231,0.92)', borderRadius: 14, alignItems: 'center', maxWidth: '92%' },
  footer: { fontFamily: fonts.medium, color: colors.text, textAlign: 'center' },
  from: { fontFamily: fonts.bold, color: colors.maroon, textAlign: 'center' },
  wm: { position: 'absolute', left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(0,0,0,0.45)', alignItems: 'center', justifyContent: 'center' },
  input: { backgroundColor: colors.white, borderRadius: radius.md, borderWidth: 1.5, borderColor: colors.border, minHeight: 56, paddingHorizontal: 16, fontSize: size.body, fontFamily: fonts.regular, color: colors.text },
});
