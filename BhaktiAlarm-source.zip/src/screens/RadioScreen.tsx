import React, { useEffect, useState } from 'react';
import { View, Text, Pressable, ScrollView, ActivityIndicator } from 'react-native';
import { useAudioPlayer, useAudioPlayerStatus, setAudioModeAsync } from 'expo-audio';
import { useKeepAwake } from 'expo-keep-awake';
import { STATIONS, Station, streamUrl } from '../content/radio';
import { x } from '../i18n/extra';
import { colors, fonts, radius, shadow } from '../theme';

export default function RadioScreen() {
  useKeepAwake();
  const t = x().radio;
  const player = useAudioPlayer(null);
  const status = useAudioPlayerStatus(player);
  const [cur, setCur] = useState<string | null>(null);
  const [failed, setFailed] = useState<string | null>(null);

  useEffect(() => {
    setAudioModeAsync({ playsInSilentMode: true, shouldPlayInBackground: false }).catch(() => {});
    return () => { try { player.pause(); } catch (e) {} };
  }, []);

  // A stream that never starts buffering within 15 s is treated as off air.
  useEffect(() => {
    if (!cur || status.playing) return;
    const id = setTimeout(() => { if (!player.playing) { try { player.pause(); } catch (e) {} setFailed(cur); setCur(null); } }, 15000);
    return () => clearTimeout(id);
  }, [cur, status.playing]);

  const toggle = async (st: Station) => {
    setFailed(null);
    if (cur === st.id) { try { player.pause(); } catch (e) {} setCur(null); return; }
    setCur(st.id);
    try { player.replace({ uri: await streamUrl(st) }); player.play(); } catch (e) { setFailed(st.id); setCur(null); }
  };

  return (
    <ScrollView style={{ flex: 1, backgroundColor: colors.cream }} contentContainerStyle={{ padding: 16, paddingBottom: 40 }}>
      <Text style={{ fontFamily: fonts.regular, fontSize: 16, color: colors.maroon, marginBottom: 14 }}>{t.intro}</Text>
      {STATIONS.map((st) => {
        const on = cur === st.id;
        const buffering = on && !status.playing;
        return (
          <Pressable key={st.id} onPress={() => toggle(st)} accessibilityRole="button" accessibilityLabel={st.name}
            style={({ pressed }) => [{ flexDirection: 'row', alignItems: 'center', backgroundColor: on ? '#8B0000' : '#5D2E0A', borderRadius: radius.md, padding: 16, marginBottom: 12, borderWidth: on ? 2 : 0, borderColor: colors.gold, opacity: pressed ? 0.9 : 1 }, shadow]}>
            <View style={{ width: 48, alignItems: 'center', marginRight: 12 }}>
              {buffering ? <ActivityIndicator color="#FFD27A" /> : <Text style={{ fontSize: 34, color: '#FFF3D6' }}>{on ? '⏸' : '▶'}</Text>}
            </View>
            <View style={{ flex: 1 }}>
              <Text style={{ fontFamily: fonts.bold, fontSize: 19, color: '#FFF3D6' }}>{st.name}</Text>
              <Text style={{ fontFamily: fonts.regular, fontSize: 15, color: '#FFE2B8' }}>{st.desc} · {st.lang}</Text>
              {on ? <Text style={{ fontFamily: fonts.bold, fontSize: 14, color: '#FFD27A', marginTop: 4 }}>{buffering ? t.connecting : t.playing}</Text> : null}
              {failed === st.id ? <Text style={{ fontFamily: fonts.bold, fontSize: 14, color: '#FFB3A0', marginTop: 4 }}>{t.offAir}</Text> : null}
            </View>
          </Pressable>
        );
      })}
      <Text style={{ fontFamily: fonts.regular, fontSize: 13, color: '#7A5A3A', marginTop: 8 }}>{t.credit}</Text>
    </ScrollView>
  );
}
