// Builds what the home-screen widget shows. Runs in the app and in the headless widget task,
// so it reads prefs straight from AsyncStorage and uses no React context.
import AsyncStorage from '@react-native-async-storage/async-storage';
import { panchangFor, cityFor, fmtIST, fmtISTWithDay, fmtSpan } from '../lib/panchang';
import { FESTIVALS } from '../content/catalog';
import en from '../i18n/en';
import hi from '../i18n/hi';

export type WidgetData = {
  dateLine: string; tithi: string; till: string; month: string;
  sun: string; rahu: string; rahuLabel: string; festival: string | null; city: string;
};

const ymd = (x: Date) => `${x.getFullYear()}-${String(x.getMonth() + 1).padStart(2, '0')}-${String(x.getDate()).padStart(2, '0')}`;

export async function widgetData(): Promise<WidgetData> {
  let region: string | null = null, language = 'en';
  try {
    const raw = await AsyncStorage.getItem('bhakti.prefs.v1');
    if (raw) { const p = JSON.parse(raw); region = p.region ?? null; language = p.language || 'en'; }
  } catch {}
  const deva = ['hi', 'mr', 'gu', 'pa'].includes(language);
  const t = deva ? hi.panchang : en.panchang;
  const now = new Date();
  const p = panchangFor(now, cityFor(region));
  const paksha = p.paksha === 'Shukla' ? (deva ? 'शुक्ल' : 'Shukla') : (deva ? 'कृष्ण' : 'Krishna');
  const today = ymd(now);
  const fest = FESTIVALS.filter((f) => (f.date === today || (!!f.endDate && f.date <= today && today <= f.endDate)) && (f.major || f.type === 'vrat' || (region && f.regions.includes(region))))
    .map((f) => f.name).slice(0, 2).join(', ');
  const wd = t.days[now.getDay()];
  return {
    dateLine: `${wd}, ${now.getDate()} ${now.toLocaleString('en-IN', { month: 'short' })}`,
    tithi: `${paksha} ${deva ? p.tithiHi : p.tithi}`,
    till: t.till.replace('{t}', fmtISTWithDay(p.tithiEnd, now, t.days)),
    month: deva ? p.monthHi : p.month,
    sun: `☀ ${fmtIST(p.sunrise)}  ·  🌙 ${fmtIST(p.sunset)}`,
    rahu: fmtSpan(p.rahuKaal), rahuLabel: t.rahu,
    festival: fest || null, city: p.city.name,
  };
}
