import React from 'react';
import { FlexWidget, TextWidget } from 'react-native-android-widget';
import type { WidgetData } from './data';

export function PanchangWidget({ d }: { d: WidgetData }) {
  return (
    <FlexWidget
      clickAction="OPEN_APP"
      style={{
        height: 'match_parent', width: 'match_parent', flexDirection: 'column', justifyContent: 'space-between',
        backgroundGradient: { from: '#7A1400', to: '#B33A00', orientation: 'TL_BR' }, borderRadius: 20, padding: 14,
      }}
    >
      <FlexWidget style={{ flexDirection: 'row', justifyContent: 'space-between', width: 'match_parent' }}>
        <TextWidget text={`🪔 ${d.dateLine}`} style={{ fontSize: 14, color: '#FFE2B8' }} />
        <TextWidget text={d.month} style={{ fontSize: 14, color: '#FFE2B8' }} />
      </FlexWidget>
      <FlexWidget style={{ flexDirection: 'column' }}>
        <TextWidget text={d.tithi} style={{ fontSize: 22, color: '#FFFFFF', fontWeight: 'bold' }} maxLines={1} truncate="END" />
        <TextWidget text={d.till} style={{ fontSize: 14, color: '#FFD27A' }} />
      </FlexWidget>
      {d.festival ? <TextWidget text={`✨ ${d.festival}`} style={{ fontSize: 14, color: '#FFD27A', fontWeight: 'bold' }} maxLines={1} truncate="END" /> : null}
      <FlexWidget style={{ flexDirection: 'row', justifyContent: 'space-between', width: 'match_parent' }}>
        <TextWidget text={d.sun} style={{ fontSize: 12, color: '#FFF3D6' }} />
        <TextWidget text={`${d.rahuLabel} ${d.rahu}`} style={{ fontSize: 12, color: '#FFF3D6' }} maxLines={1} truncate="END" />
      </FlexWidget>
    </FlexWidget>
  );
}
