import React from 'react';
import type { WidgetTaskHandlerProps } from 'react-native-android-widget';
import { PanchangWidget } from './PanchangWidget';
import { widgetData } from './data';

export async function widgetTaskHandler(props: WidgetTaskHandlerProps) {
  if (props.widgetAction === 'WIDGET_DELETED') return;
  const d = await widgetData();
  props.renderWidget(<PanchangWidget d={d} />);
}
