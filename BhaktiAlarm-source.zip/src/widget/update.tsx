import React from 'react';
import { requestWidgetUpdate } from 'react-native-android-widget';
import { PanchangWidget } from './PanchangWidget';
import { widgetData } from './data';

/** Re-render any Panchang widgets on the home screen (no-op when none are added). */
export async function updatePanchangWidget() {
  const d = await widgetData();
  await requestWidgetUpdate({ widgetName: 'Panchang', renderWidget: () => <PanchangWidget d={d} /> });
}
