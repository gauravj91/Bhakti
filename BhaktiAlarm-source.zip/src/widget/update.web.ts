export async function updatePanchangWidget() {}
