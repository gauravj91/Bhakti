// Registers every translation. Missing keys fall back to English.
import { registerLanguage } from './index';
import hi from './hi';
import gu from './gu';
import mr from './mr';
import pa from './pa';
import bn from './bn';
import ta from './ta';
Object.entries({ hi, gu, mr, pa, bn, ta }).forEach(([k, v]) => registerLanguage(k, v));
