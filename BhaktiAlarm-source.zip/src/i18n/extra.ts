// Strings for Home, Rashifal, Kundali and the greeting "From" line (v1.1).
// Kept apart from en.ts so a missing translation falls back to English key by key.
import { getLanguage } from './index';

const en = {
  tabHome: 'Home',
  home: {
    hello: 'Jai Shree Krishna 🙏',
    alarmTitle: 'Bhakti Alarm',
    nextAlarm: 'Next alarm {time}',
    noAlarm: 'No alarm set. Wake up to aarti tomorrow',
    setAlarm: 'Set alarm',
    alarmsOn: '{n} alarms on',
    liveTitle: 'Live Aarti & Darshan',
    liveNow: 'LIVE NOW',
    liveChecking: 'Finding temples that are live…',
    liveNone: 'No temple is live this minute. Tap to see all live temples.',
    watch: 'Watch',
    allLive: 'All live temples',
    rashifalTitle: 'Aaj ka Rashifal',
    pickRashi: 'Choose your rashi to read today’s rashifal',
    kundaliTitle: 'Janam Kundali',
    kundaliSub: 'Your birth chart from date, time and place of birth',
    greetTitle: 'Send a greeting',
    greetSub: 'Good Morning, festival and devotional images',
    panchangTitle: 'Today’s Panchang',
    readMore: 'Read more',
  },
  rashifal: {
    title: 'Rashifal',
    today: 'Today', tomorrow: 'Tomorrow', weekly: 'Weekly', monthly: 'Monthly',
    yourRashi: 'Your rashi',
    change: 'Change rashi',
    chooseTitle: 'Choose your rashi',
    chooseSub: 'Don’t know your rashi? Pick by the first letter of your name, or make your Kundali.',
    career: 'Work', money: 'Money', family: 'Family & love', health: 'Health',
    color: 'Lucky colour', number: 'Lucky number', upay: 'Upay (remedy)',
    best: 'Good days', careful: 'Be careful on', planets: 'Planets this period', none: 'None',
    share: 'Share on WhatsApp',
    shareCaption: '🙏 {rashi} rashifal from Bhakti Alarm. Read yours free: {link}',
    fromKundali: 'From your Kundali',
  },
  kundali: {
    title: 'Janam Kundali',
    sub: 'Enter birth details to see the chart. Saved only on this phone.',
    name: 'Name',
    dob: 'Date of birth',
    tob: 'Time of birth',
    place: 'Place of birth',
    placeHint: 'Type city or village, e.g. Jaipur',
    search: 'Search',
    searching: 'Searching…',
    noPlace: 'Place not found. Try a nearby city.',
    offline: 'No internet. Pick a city from the list.',
    timezone: 'Time zone',
    make: 'Make Kundali',
    saved: 'Saved Kundalis',
    delete: 'Delete',
    deleteConfirm: 'Delete this Kundali?',
    lagna: 'Lagna (Ascendant)', rashi: 'Rashi (Moon sign)', nakshatra: 'Nakshatra', pada: 'Pada',
    chart: 'Lagna Chart (D1)',
    planets: 'Planets',
    planet: 'Planet', sign: 'Rashi', degree: 'Degree', house: 'House',
    retro: 'R = retrograde',
    dasha: 'Vimshottari Dasha',
    nowRunning: 'Now running',
    mahadasha: 'Mahadasha', antardasha: 'Antardasha',
    manglik: 'Mangal dosha',
    manglikYes: 'Mars is in a Manglik position. Please consult a pandit; many charts have cancellations.',
    manglikNo: 'No Mangal dosha from Lagna or Moon.',
    useRashi: 'Use this rashi for my Rashifal',
    invalid: 'Please fill in date, time and place.',
    unknownTime: 'Don’t know the time? Use 12:00, but the Lagna may be wrong.',
    month: 'Month', day: 'Day', year: 'Year', hour: 'Hour', minute: 'Min',
  },
  disclaimer: 'For guidance and entertainment only. Calculated by the app from planet positions, not by a personal astrologer. Do not take important health, money, marriage or legal decisions based on this. Please consult a qualified expert.',
  from: {
    wish: 'Bottom message',
    label: 'From (your name)',
    placeholder: 'e.g. Gaurav & Family',
    line: 'From {name}',
  },
  wallpaper: {
    title: 'Bhakti Wallpapers',
    sub: 'Set Bhagwan or a calm background on your phone, still or live with a glowing diya',
    deities: 'Bhagwan',
    backgrounds: 'Backgrounds',
    loading: 'Loading more backgrounds…',
    setOn: 'Set as wallpaper',
    home: 'Home screen',
    lock: 'Lock screen',
    both: 'Both',
    live: '✨ Live: with diya & petals',
    liveHint: 'Your phone will show a preview. Tap “Set wallpaper” there.',
    setting: 'Setting wallpaper…',
    done: 'Wallpaper set 🙏',
    failed: 'Could not set the wallpaper. Please try again.',
    offline: 'This picture needs internet. Please connect and try again.',
    close: 'Close',
  },
};
export type Extra = typeof en;
type Deep<T> = { [K in keyof T]?: T[K] extends object ? Deep<T[K]> : T[K] };

const hi: Deep<Extra> = {
  tabHome: 'होम',
  home: {
    hello: 'जय श्री कृष्ण 🙏', alarmTitle: 'भक्ति अलार्म', nextAlarm: 'अगला अलार्म {time}', noAlarm: 'कोई अलार्म नहीं। कल आरती के साथ जागें',
    setAlarm: 'अलार्म लगाएँ', alarmsOn: '{n} अलार्म चालू', liveTitle: 'लाइव आरती और दर्शन', liveNow: 'अभी लाइव',
    liveChecking: 'लाइव मंदिर खोज रहे हैं…', liveNone: 'इस समय कोई मंदिर लाइव नहीं है। सभी लाइव मंदिर देखने के लिए दबाएँ।',
    watch: 'देखें', allLive: 'सभी लाइव मंदिर', rashifalTitle: 'आज का राशिफल', pickRashi: 'आज का राशिफल पढ़ने के लिए अपनी राशि चुनें',
    kundaliTitle: 'जन्म कुंडली', kundaliSub: 'जन्म तिथि, समय और स्थान से अपनी कुंडली देखें',
    greetTitle: 'शुभकामना भेजें', greetSub: 'सुप्रभात, त्योहार और भक्ति चित्र', panchangTitle: 'आज का पंचांग', readMore: 'और पढ़ें',
  },
  rashifal: {
    title: 'राशिफल', today: 'आज', tomorrow: 'कल', weekly: 'साप्ताहिक', monthly: 'मासिक', yourRashi: 'आपकी राशि', change: 'राशि बदलें',
    chooseTitle: 'अपनी राशि चुनें', chooseSub: 'राशि नहीं पता? नाम के पहले अक्षर से चुनें या अपनी कुंडली बनाएँ।',
    career: 'कार्य', money: 'धन', family: 'परिवार और प्रेम', health: 'स्वास्थ्य', color: 'शुभ रंग', number: 'शुभ अंक', upay: 'उपाय',
    best: 'शुभ दिन', careful: 'इन दिनों सावधानी रखें', planets: 'इस समय के ग्रह', none: 'कोई नहीं', share: 'WhatsApp पर भेजें',
    shareCaption: '🙏 Bhakti Alarm से {rashi} राशिफल। अपना राशिफल मुफ़्त पढ़ें: {link}', fromKundali: 'आपकी कुंडली से',
  },
  kundali: {
    title: 'जन्म कुंडली', sub: 'कुंडली देखने के लिए जन्म की जानकारी भरें। यह सिर्फ़ इसी फ़ोन में सेव होती है।', name: 'नाम',
    dob: 'जन्म तिथि', tob: 'जन्म समय', place: 'जन्म स्थान', placeHint: 'शहर या गाँव लिखें, जैसे जयपुर', search: 'खोजें', searching: 'खोज रहे हैं…',
    noPlace: 'स्थान नहीं मिला। पास का शहर लिखें।', offline: 'इंटरनेट नहीं है। सूची से शहर चुनें।', timezone: 'टाइम ज़ोन', make: 'कुंडली बनाएँ',
    saved: 'सेव की गई कुंडलियाँ', delete: 'हटाएँ', deleteConfirm: 'यह कुंडली हटाएँ?', lagna: 'लग्न', rashi: 'राशि (चंद्र राशि)', nakshatra: 'नक्षत्र', pada: 'चरण',
    chart: 'लग्न कुंडली (D1)', planets: 'ग्रह', planet: 'ग्रह', sign: 'राशि', degree: 'अंश', house: 'भाव', retro: 'व = वक्री',
    dasha: 'विंशोत्तरी दशा', nowRunning: 'अभी चल रही', mahadasha: 'महादशा', antardasha: 'अंतर्दशा', manglik: 'मंगल दोष',
    manglikYes: 'मंगल मांगलिक स्थान में है। कृपया पंडित जी से सलाह लें, कई कुंडलियों में दोष का परिहार होता है।',
    manglikNo: 'लग्न या चंद्र से मंगल दोष नहीं है।', useRashi: 'यही राशि मेरे राशिफल के लिए रखें', invalid: 'कृपया तिथि, समय और स्थान भरें।',
    unknownTime: 'समय नहीं पता? 12:00 रखें, पर लग्न ग़लत हो सकता है।', month: 'महीना', day: 'दिन', year: 'वर्ष', hour: 'घंटा', minute: 'मिनट',
  },
  disclaimer: 'यह केवल मार्गदर्शन और मनोरंजन के लिए है। यह ग्रहों की स्थिति से ऐप द्वारा गणना है, किसी ज्योतिषी की व्यक्तिगत सलाह नहीं। स्वास्थ्य, धन, विवाह या क़ानूनी फ़ैसले इसके आधार पर न लें। कृपया योग्य विशेषज्ञ से सलाह लें।',
  from: { wish: 'नीचे का संदेश', label: 'की ओर से (आपका नाम)', placeholder: 'जैसे गौरव और परिवार', line: '{name} की ओर से' },
  wallpaper: {
    title: 'भक्ति वॉलपेपर', sub: 'फ़ोन पर भगवान या शांत बैकग्राउंड लगाएँ, स्थिर या जलते दीये के साथ लाइव', deities: 'भगवान', backgrounds: 'बैकग्राउंड',
    loading: 'और बैकग्राउंड आ रहे हैं…', setOn: 'वॉलपेपर लगाएँ', home: 'होम स्क्रीन', lock: 'लॉक स्क्रीन', both: 'दोनों',
    live: '✨ लाइव: दीया और फूलों के साथ', liveHint: 'फ़ोन पर प्रीव्यू दिखेगा। वहाँ “वॉलपेपर सेट करें” दबाएँ।',
    setting: 'वॉलपेपर लग रहा है…', done: 'वॉलपेपर लग गया 🙏', failed: 'वॉलपेपर नहीं लग पाया। कृपया फिर से कोशिश करें।',
    offline: 'इस चित्र के लिए इंटरनेट चाहिए। कृपया कनेक्ट करके फिर कोशिश करें।', close: 'बंद करें',
  },
};
const mr: Deep<Extra> = {
  wallpaper: { title: 'वॉलपेपर' },
  tabHome: 'होम',
  home: { liveTitle: 'लाइव्ह आरती व दर्शन', liveNow: 'आता लाइव्ह', rashifalTitle: 'आजचे राशीभविष्य', kundaliTitle: 'जन्म कुंडली', setAlarm: 'अलार्म लावा', watch: 'पहा', greetTitle: 'शुभेच्छा पाठवा', panchangTitle: 'आजचे पंचांग' },
  rashifal: { title: 'राशीभविष्य', today: 'आज', tomorrow: 'उद्या', weekly: 'साप्ताहिक', monthly: 'मासिक' },
  disclaimer: 'हे फक्त मार्गदर्शन व मनोरंजनासाठी आहे. ग्रहस्थितीवरून ॲपने केलेली गणना आहे, ज्योतिषाचा वैयक्तिक सल्ला नाही. आरोग्य, पैसा, विवाह किंवा कायदेशीर निर्णय यावर घेऊ नका. कृपया तज्ज्ञांचा सल्ला घ्या.',
  from: { wish: 'खालचा संदेश', label: 'कडून (तुमचे नाव)', line: '{name} यांच्याकडून' },
};
const gu: Deep<Extra> = {
  wallpaper: { title: 'વૉલપેપર' },
  tabHome: 'હોમ',
  home: { liveTitle: 'લાઇવ આરતી અને દર્શન', liveNow: 'હમણાં લાઇવ', rashifalTitle: 'આજનું રાશિફળ', kundaliTitle: 'જન્મ કુંડળી', setAlarm: 'એલાર્મ મૂકો', watch: 'જુઓ', greetTitle: 'શુભેચ્છા મોકલો', panchangTitle: 'આજનું પંચાંગ' },
  rashifal: { title: 'રાશિફળ', today: 'આજે', tomorrow: 'આવતીકાલ', weekly: 'સાપ્તાહિક', monthly: 'માસિક' },
  disclaimer: 'આ ફક્ત માર્ગદર્શન અને મનોરંજન માટે છે. ગ્રહોની સ્થિતિ પરથી એપ દ્વારા ગણતરી છે, જ્યોતિષીની વ્યક્તિગત સલાહ નથી. આરોગ્ય, પૈસા, લગ્ન કે કાનૂની નિર્ણયો આના આધારે ન લો. કૃપા કરીને નિષ્ણાતની સલાહ લો.',
  from: { wish: 'નીચેનો સંદેશ', label: 'તરફથી (તમારું નામ)', line: '{name} તરફથી' },
};
const pa: Deep<Extra> = {
  wallpaper: { title: 'ਵਾਲਪੇਪਰ' },
  tabHome: 'ਹੋਮ',
  home: { liveTitle: 'ਲਾਈਵ ਆਰਤੀ ਅਤੇ ਦਰਸ਼ਨ', liveNow: 'ਹੁਣ ਲਾਈਵ', rashifalTitle: 'ਅੱਜ ਦਾ ਰਾਸ਼ੀਫਲ', kundaliTitle: 'ਜਨਮ ਕੁੰਡਲੀ', setAlarm: 'ਅਲਾਰਮ ਲਗਾਓ', watch: 'ਦੇਖੋ', greetTitle: 'ਸ਼ੁਭਕਾਮਨਾ ਭੇਜੋ', panchangTitle: 'ਅੱਜ ਦਾ ਪੰਚਾਂਗ' },
  rashifal: { title: 'ਰਾਸ਼ੀਫਲ', today: 'ਅੱਜ', tomorrow: 'ਕੱਲ੍ਹ', weekly: 'ਹਫ਼ਤਾਵਾਰੀ', monthly: 'ਮਹੀਨਾਵਾਰ' },
  disclaimer: 'ਇਹ ਸਿਰਫ਼ ਮਾਰਗਦਰਸ਼ਨ ਅਤੇ ਮਨੋਰੰਜਨ ਲਈ ਹੈ। ਗ੍ਰਹਿਆਂ ਦੀ ਸਥਿਤੀ ਤੋਂ ਐਪ ਵੱਲੋਂ ਗਣਨਾ ਹੈ, ਕਿਸੇ ਜੋਤਸ਼ੀ ਦੀ ਨਿੱਜੀ ਸਲਾਹ ਨਹੀਂ। ਸਿਹਤ, ਪੈਸੇ, ਵਿਆਹ ਜਾਂ ਕਾਨੂੰਨੀ ਫ਼ੈਸਲੇ ਇਸ ਦੇ ਆਧਾਰ ’ਤੇ ਨਾ ਲਓ। ਕਿਰਪਾ ਕਰਕੇ ਮਾਹਿਰ ਦੀ ਸਲਾਹ ਲਓ।',
  from: { wish: 'ਹੇਠਾਂ ਦਾ ਸੁਨੇਹਾ', label: 'ਵੱਲੋਂ (ਤੁਹਾਡਾ ਨਾਮ)', line: '{name} ਵੱਲੋਂ' },
};
const bn: Deep<Extra> = {
  wallpaper: { title: 'ওয়ালপেপার' },
  tabHome: 'হোম',
  home: { liveTitle: 'লাইভ আরতি ও দর্শন', liveNow: 'এখন লাইভ', rashifalTitle: 'আজকের রাশিফল', kundaliTitle: 'জন্ম কুণ্ডলী', setAlarm: 'অ্যালার্ম দিন', watch: 'দেখুন', greetTitle: 'শুভেচ্ছা পাঠান', panchangTitle: 'আজকের পঞ্জিকা' },
  rashifal: { title: 'রাশিফল', today: 'আজ', tomorrow: 'আগামীকাল', weekly: 'সাপ্তাহিক', monthly: 'মাসিক' },
  disclaimer: 'এটি কেবল নির্দেশনা ও বিনোদনের জন্য। গ্রহের অবস্থান থেকে অ্যাপের গণনা, কোনো জ্যোতিষীর ব্যক্তিগত পরামর্শ নয়। স্বাস্থ্য, অর্থ, বিবাহ বা আইনি সিদ্ধান্ত এর ভিত্তিতে নেবেন না। অনুগ্রহ করে বিশেষজ্ঞের পরামর্শ নিন।',
  from: { wish: 'নিচের বার্তা', label: 'পক্ষ থেকে (আপনার নাম)', line: '{name}-এর পক্ষ থেকে' },
};
const ta: Deep<Extra> = {
  wallpaper: { title: 'வால்பேப்பர்' },
  tabHome: 'முகப்பு',
  home: { liveTitle: 'நேரலை ஆரத்தி & தரிசனம்', liveNow: 'இப்போது நேரலை', rashifalTitle: 'இன்றைய ராசிபலன்', kundaliTitle: 'ஜாதகம்', setAlarm: 'அலாரம் வை', watch: 'பார்க்க', greetTitle: 'வாழ்த்து அனுப்பு', panchangTitle: 'இன்றைய பஞ்சாங்கம்' },
  rashifal: { title: 'ராசிபலன்', today: 'இன்று', tomorrow: 'நாளை', weekly: 'வாராந்திர', monthly: 'மாதாந்திர' },
  disclaimer: 'இது வழிகாட்டுதல் மற்றும் பொழுதுபோக்குக்கு மட்டுமே. கிரக நிலைகளிலிருந்து செயலி கணக்கிட்டது, ஜோதிடரின் தனிப்பட்ட ஆலோசனை அல்ல. உடல்நலம், பணம், திருமணம் அல்லது சட்ட முடிவுகளை இதை வைத்து எடுக்க வேண்டாம். நிபுணரை அணுகவும்.',
  from: { wish: 'கீழ் செய்தி', label: 'அன்புடன் (உங்கள் பெயர்)', line: 'அன்புடன் {name}' },
};

const D: Record<string, Deep<Extra>> = { hi, mr, gu, pa, bn, ta };
function merge(base: any, over: any): any {
  if (!over) return base;
  const out: any = { ...base };
  for (const k of Object.keys(over)) out[k] = typeof base[k] === 'object' && !Array.isArray(base[k]) ? merge(base[k], over[k]) : over[k];
  return out;
}
let cacheLang = '', cache: Extra = en;
export function x(): Extra {
  const l = getLanguage();
  if (l !== cacheLang) { cacheLang = l; cache = l === 'en' ? en : merge(en, D[l]); }
  return cache;
}
