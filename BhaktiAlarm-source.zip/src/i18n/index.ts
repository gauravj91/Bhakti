import en, { Strings } from './en';

// Other languages register here as they are added (hi, gu, mr, pa, bn, ta).
const dictionaries: Record<string, Partial<Strings>> = { en };
let lang = 'en';
let current: Strings = en;

export const LANGUAGES = [
  { id: 'en', name: 'English' },
  { id: 'hi', name: 'हिन्दी (Hindi)' },
  { id: 'gu', name: 'ગુજરાતી (Gujarati)' },
  { id: 'mr', name: 'मराठी (Marathi)' },
  { id: 'pa', name: 'ਪੰਜਾਬੀ (Punjabi)' },
  { id: 'bn', name: 'বাংলা (Bengali)' },
  { id: 'ta', name: 'தமிழ் (Tamil)' },
];

/** Deep-merge so a missing key in a translation falls back to English. */
function merge(base: any, over: any): any {
  if (!over) return base;
  const out: any = Array.isArray(base) ? [...base] : { ...base };
  for (const k of Object.keys(over)) {
    out[k] = base && typeof base[k] === 'object' && !Array.isArray(base[k]) ? merge(base[k], over[k]) : over[k];
  }
  return out;
}
export function registerLanguage(id: string, dict: Partial<Strings>) { dictionaries[id] = dict; }
export function setLanguage(id: string) { lang = dictionaries[id] ? id : 'en'; current = lang === 'en' ? en : merge(en, dictionaries[lang]); }
export const getLanguage = () => lang;
/** Languages whose readers are comfortable with Hindi devotional text in Devanagari. */
export const readsHindi = () => ['hi', 'mr', 'gu', 'pa'].includes(lang);
export function s(): Strings { return current; }
/** Replace {key} tokens. */
export function fmt(str: string, vars: Record<string, string | number> = {}) {
  return str.replace(/\{(\w+)\}/g, (_, k) => (vars[k] !== undefined ? String(vars[k]) : `{${k}}`));
}
