// Web preview only: in-memory stand-in for the Android alarm engine.
// ?ring=1 in the URL shows the wake screen.
let alarms: any[] = [
  { id: 'a1', hour: 5, minute: 30, days: [0,1,2,3,4,5,6], enabled: true, label: 'Morning aarti', trackId: 'ganesh_aarti_01', shuffle: false, deityPool: [], vibrate: true, snoozeMinutes: 5 },
  { id: 'a2', hour: 6, minute: 15, days: [1,2,3,4,5], enabled: true, label: 'Walk', trackId: null, shuffle: true, deityPool: ['krishna','shiva'], vibrate: true, snoozeMinutes: 10 },
  { id: 'a3', hour: 19, minute: 0, days: [2,6], enabled: false, label: 'Hanuman Chalisa', trackId: 'hanuman_aarti_01', shuffle: false, deityPool: [], vibrate: false, snoozeMinutes: 5 },
];
const ring = typeof location !== 'undefined' && /ring=1/.test(location.search);
const M = {
  saveAlarm(json: string) { const a = JSON.parse(json); delete a.tracks; alarms = alarms.filter((x) => x.id !== a.id).concat(a); return Date.now() + 3600e3; },
  deleteAlarm(id: string) { alarms = alarms.filter((x) => x.id !== id); },
  getAlarms() { return JSON.stringify(alarms); },
  getRinging() { return ring ? JSON.stringify({ alarmId: 'a1', label: 'Morning aarti', trackId: 'ganesh_aarti_01', trackTitle: 'Ganesh Aarti', deityId: 'ganesh', snoozeMinutes: 5 }) : null; },
  stopRinging() {}, snooze() {}, testAlarm() {},
  canScheduleExact: () => true, canUseFullScreen: () => true, notificationsEnabled: () => true,
  openExactAlarmSettings() {}, openFullScreenSettings() {}, openAppSettings() {}, rescheduleAll() {},
  addListener() { return { remove() {} } as any; },
  async makeVideo() { await new Promise((r) => setTimeout(r, 1500)); return 'file:///preview.mp4'; },
  cancelVideo() {}, shareVideo() {}, isInstalled: () => true,
  async setLiveWallpaper() { return true; },
  async setWallpaper() { await new Promise((r) => setTimeout(r, 800)); return true; },
};
export const isAvailable = true;
export default M as any;
