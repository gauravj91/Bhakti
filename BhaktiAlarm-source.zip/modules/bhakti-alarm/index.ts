import { requireOptionalNativeModule, EventSubscription } from 'expo-modules-core';

type Native = {
  saveAlarm(json: string): number;
  deleteAlarm(id: string): void;
  getAlarms(): string;
  getRinging(): string | null;
  stopRinging(): void;
  snooze(minutes: number): void;
  testAlarm(seconds: number, json: string): void;
  canScheduleExact(): boolean;
  canUseFullScreen(): boolean;
  notificationsEnabled(): boolean;
  openExactAlarmSettings(): void;
  openFullScreenSettings(): void;
  openAppSettings(): void;
  rescheduleAll(): void;
  addListener(event: 'onRinging', cb: (e: { at: number }) => void): EventSubscription;
  addListener(event: 'onVideoProgress', cb: (e: { progress: number }) => void): EventSubscription;
  makeVideo(json: string): Promise<string>;
  cancelVideo(): void;
  shareVideo(uri: string, pkg: string, text: string): void;
  isInstalled(pkg: string): boolean;
  setWallpaper(uri: string, target: 'home' | 'lock' | 'both'): Promise<boolean>;
  setLiveWallpaper(uri: string): Promise<boolean>;
};

// Optional so the JS bundle still loads where the native module is missing (e.g. web preview).
const M = requireOptionalNativeModule<Native>('BhaktiAlarm');
export const isAvailable = !!M;
export default M;
