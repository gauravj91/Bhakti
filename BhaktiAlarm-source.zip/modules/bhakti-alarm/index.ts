import { requireOptionalNativeModule, EventSubscription } from 'expo-modules-core';

type Native = {
  saveAlarm(json: string): number;
  deleteAlarm(id: string): void;
  getAlarms(): string;
  getRinging(): string | null;
  stopRinging(): void;
  snooze(minutes: number): void;
  testAlarm(seconds: number, json: string): void;
  canScheduleExact(): boolean;
  canUseFullScreen(): boolean;
  notificationsEnabled(): boolean;
  openExactAlarmSettings(): void;
  openFullScreenSettings(): void;
  openAppSettings(): void;
  rescheduleAll(): void;
  addListener(event: 'onRinging', cb: (e: { at: number }) => void): EventSubscription;
};

// Optional so the JS bundle still loads where the native module is missing (e.g. web preview).
const M = requireOptionalNativeModule<Native>('BhaktiAlarm');
export const isAvailable = !!M;
export default M;
