package expo.modules.bhaktialarm

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.core.app.NotificationCompat
import org.json.JSONObject

/** Plays the devotional track in a foreground service so it rings even when the app is closed. */
class AlarmService : Service() {
  private var player: MediaPlayer? = null
  private var vibrator: Vibrator? = null
  private var wakeLock: PowerManager.WakeLock? = null
  private val handler = Handler(Looper.getMainLooper())
  private var volume = 0.15f

  override fun onBind(intent: Intent?): IBinder? = null

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    val payload = intent?.getStringExtra(AlarmScheduler.EXTRA_PAYLOAD)?.let { JSONObject(it) }
      ?: AlarmStore.getRinging(this)
    if (payload == null) { stopSelf(); return START_NOT_STICKY }

    ensureChannel(this)
    val notification = buildNotification(payload)
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
      startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
    } else {
      startForeground(NOTIF_ID, notification)
    }

    val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
    wakeLock?.release()
    wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "bhakti:alarm").apply { acquire(10 * 60 * 1000L) }

    startPlayback(payload.optString("uri"))
    if (payload.optBoolean("vibrate", true)) startVibration()

    // Try to open the wake screen directly too (works on most devices when screen is off).
    try { startActivity(launchIntent(this, payload)) } catch (_: Exception) {}

    // Auto-stop after 10 minutes so a forgotten phone does not ring forever.
    handler.removeCallbacksAndMessages(null)
    handler.postDelayed({ stop(this) }, 10 * 60 * 1000L)
    return START_STICKY
  }

  private fun startPlayback(uri: String) {
    releasePlayer()
    val attrs = AudioAttributes.Builder()
      .setUsage(AudioAttributes.USAGE_ALARM)
      .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
    val mp = MediaPlayer()
    try {
      mp.setAudioAttributes(attrs)
      if (uri.isNotEmpty()) mp.setDataSource(this, Uri.parse(uri))
      else mp.setDataSource(this, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM))
      mp.isLooping = true
      mp.prepare()
    } catch (e: Exception) {
      try {
        mp.reset(); mp.setAudioAttributes(attrs)
        mp.setDataSource(this, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM))
        mp.isLooping = true; mp.prepare()
      } catch (_: Exception) { return }
    }
    // Gentle fade-in: calm, not jarring.
    volume = 0.15f; mp.setVolume(volume, volume); mp.start(); player = mp
    val fade = object : Runnable {
      override fun run() {
        val p = player ?: return
        if (volume < 1f) { volume = (volume + 0.05f).coerceAtMost(1f); p.setVolume(volume, volume); handler.postDelayed(this, 1500) }
      }
    }
    handler.postDelayed(fade, 1500)
  }

  private fun startVibration() {
    @Suppress("DEPRECATION")
    val v = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator ?: return
    vibrator = v
    val pattern = longArrayOf(0, 600, 1400)
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) v.vibrate(VibrationEffect.createWaveform(pattern, 0))
    else @Suppress("DEPRECATION") v.vibrate(pattern, 0)
  }

  private fun buildNotification(payload: JSONObject): Notification {
    val full = PendingIntent.getActivity(
      this, 7001, launchIntent(this, payload),
      PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
    val stopPi = PendingIntent.getBroadcast(
      this, 7002, Intent(this, AlarmReceiver::class.java).setAction(AlarmReceiver.ACTION_STOP),
      PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
    val snoozePi = PendingIntent.getBroadcast(
      this, 7003, Intent(this, AlarmReceiver::class.java).setAction(AlarmReceiver.ACTION_SNOOZE),
      PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
    val title = payload.optString("label").ifEmpty { "Time to wake 🙏" }
    val text = payload.optString("trackTitle").ifEmpty { "Devotional alarm" }
    val icon = applicationInfo.icon.takeIf { it != 0 } ?: android.R.drawable.ic_lock_idle_alarm
    return NotificationCompat.Builder(this, CHANNEL_ID)
      .setSmallIcon(icon)
      .setContentTitle(title)
      .setContentText(text)
      .setCategory(NotificationCompat.CATEGORY_ALARM)
      .setPriority(NotificationCompat.PRIORITY_MAX)
      .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
      .setOngoing(true)
      .setFullScreenIntent(full, true)
      .setContentIntent(full)
      .addAction(0, "Snooze", snoozePi)
      .addAction(0, "Dismiss", stopPi)
      .build()
  }

  private fun releasePlayer() {
    try { player?.stop() } catch (_: Exception) {}
    player?.release(); player = null
  }

  override fun onDestroy() {
    handler.removeCallbacksAndMessages(null)
    releasePlayer()
    vibrator?.cancel()
    wakeLock?.let { if (it.isHeld) it.release() }
    super.onDestroy()
  }

  companion object {
    const val CHANNEL_ID = "bhakti_alarm_ringing"
    const val NOTIF_ID = 4242

    fun ensureChannel(ctx: Context) {
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (nm.getNotificationChannel(CHANNEL_ID) == null) {
          val ch = NotificationChannel(CHANNEL_ID, "Alarms", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "Devotional alarm ringing"
            setSound(null, null) // audio is played by the service
            enableVibration(false)
            lockscreenVisibility = Notification.VISIBILITY_PUBLIC
          }
          nm.createNotificationChannel(ch)
        }
      }
    }

    fun launchIntent(ctx: Context, payload: JSONObject): Intent {
      val i = ctx.packageManager.getLaunchIntentForPackage(ctx.packageName) ?: Intent()
      i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
      i.putExtra(AlarmScheduler.EXTRA_ALARM_ID, payload.optString("alarmId"))
      return i
    }

    fun stop(ctx: Context) {
      AlarmStore.setRinging(ctx, null)
      ctx.stopService(Intent(ctx, AlarmService::class.java))
      val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
      nm.cancel(NOTIF_ID)
    }

    fun snooze(ctx: Context, minutes: Int? = null) {
      val ringing = AlarmStore.getRinging(ctx)
      stop(ctx)
      if (ringing != null) {
        val m = minutes ?: ringing.optInt("snoozeMinutes", 5)
        val id = "snooze_" + ringing.optString("alarmId")
        ringing.put("snoozed", true)
        AlarmScheduler.scheduleAt(ctx, id, System.currentTimeMillis() + m * 60_000L, ringing)
      }
    }
  }
}
