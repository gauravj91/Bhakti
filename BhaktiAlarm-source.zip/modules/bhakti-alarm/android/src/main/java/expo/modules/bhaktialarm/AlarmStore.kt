package expo.modules.bhaktialarm

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Alarms are persisted natively so they survive reboots and fire with the app closed. */
object AlarmStore {
  private const val PREFS = "bhakti_alarm_store"
  private const val KEY_ALARMS = "alarms"
  private const val KEY_RINGING = "ringing"

  private fun prefs(ctx: Context) =
    ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

  fun all(ctx: Context): MutableList<JSONObject> {
    val raw = prefs(ctx).getString(KEY_ALARMS, "[]") ?: "[]"
    val arr = try { JSONArray(raw) } catch (e: Exception) { JSONArray() }
    return MutableList(arr.length()) { arr.getJSONObject(it) }
  }

  fun saveAll(ctx: Context, list: List<JSONObject>) {
    val arr = JSONArray(); list.forEach { arr.put(it) }
    prefs(ctx).edit().putString(KEY_ALARMS, arr.toString()).apply()
  }

  fun get(ctx: Context, id: String): JSONObject? = all(ctx).firstOrNull { it.optString("id") == id }

  fun upsert(ctx: Context, alarm: JSONObject) {
    val list = all(ctx).filter { it.optString("id") != alarm.optString("id") }.toMutableList()
    list.add(alarm); saveAll(ctx, list)
  }

  fun remove(ctx: Context, id: String) {
    saveAll(ctx, all(ctx).filter { it.optString("id") != id })
  }

  fun setRinging(ctx: Context, payload: JSONObject?) {
    prefs(ctx).edit().apply {
      if (payload == null) remove(KEY_RINGING) else putString(KEY_RINGING, payload.toString())
    }.apply()
  }

  fun getRinging(ctx: Context): JSONObject? {
    val raw = prefs(ctx).getString(KEY_RINGING, null) ?: return null
    return try { JSONObject(raw) } catch (e: Exception) { null }
  }
}
