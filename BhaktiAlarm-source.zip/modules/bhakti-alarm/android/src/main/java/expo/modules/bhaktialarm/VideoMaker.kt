package expo.modules.bhaktialarm

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.graphics.Matrix
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.core.content.FileProvider
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.MatrixTransformation
import androidx.media3.effect.Presentation
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import org.json.JSONObject
import java.io.File

/**
 * Turns one composed 1080x1920 picture + a bhajan into a vertical MP4 (H.264/AAC),
 * with a slow "darshan" zoom. Runs fully on device; must be started on the main thread.
 */
@UnstableApi
object VideoMaker {
  private var current: Transformer? = null

  fun make(ctx: Context, json: String, onProgress: (Int) -> Unit, onDone: (String) -> Unit, onError: (String) -> Unit) {
    val o = JSONObject(json)
    val imageUri = Uri.parse(o.getString("imageUri"))
    val audioUri = o.optString("audioUri", "")
    val durationMs = o.optLong("durationMs", 30_000L).coerceIn(5_000L, 180_000L)
    val w = o.optInt("width", 1080); val h = o.optInt("height", 1920)

    val dir = File(ctx.cacheDir, "videos").apply { mkdirs() }
    dir.listFiles()?.filter { System.currentTimeMillis() - it.lastModified() > 24 * 3600_000L }?.forEach { it.delete() }
    val out = File(dir, "bhakti_${System.currentTimeMillis()}.mp4")

    // Slow zoom from 100% to 112% across the whole clip.
    val zoom = MatrixTransformation { tUs ->
      val p = (tUs / 1000.0 / durationMs).coerceIn(0.0, 1.0).toFloat()
      val s = 1f + 0.12f * p
      Matrix().apply { setScale(s, s) }
    }
    val picture = EditedMediaItem.Builder(
      MediaItem.Builder().setUri(imageUri).setMimeType(MimeTypes.IMAGE_JPEG).setImageDurationMs(durationMs).build()
    )
      .setFrameRate(30)
      .setEffects(Effects(listOf(), listOf(zoom, Presentation.createForWidthAndHeight(w, h, Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP))))
      .build()

    val sequences = mutableListOf(EditedMediaItemSequence(listOf(picture)))
    if (audioUri.isNotEmpty()) {
      val audio = EditedMediaItem.Builder(MediaItem.fromUri(Uri.parse(audioUri))).setRemoveVideo(true).build()
      sequences.add(EditedMediaItemSequence(listOf(audio), /* isLooping= */ true))
    }
    val composition = Composition.Builder(sequences).experimentalSetForceAudioTrack(true).build()

    val main = Handler(Looper.getMainLooper())
    val holder = ProgressHolder()
    var finished = false
    val tick = object : Runnable {
      override fun run() {
        if (finished) return
        current?.let { if (it.getProgress(holder) == Transformer.PROGRESS_STATE_AVAILABLE) onProgress(holder.progress) }
        main.postDelayed(this, 400)
      }
    }

    val transformer = Transformer.Builder(ctx)
      .setVideoMimeType(MimeTypes.VIDEO_H264)
      .setAudioMimeType(MimeTypes.AUDIO_AAC)
      .addListener(object : Transformer.Listener {
        override fun onCompleted(composition: Composition, exportResult: ExportResult) {
          finished = true; current = null; onDone(Uri.fromFile(out).toString())
        }
        override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
          finished = true; current = null; out.delete(); onError(exportException.message ?: "Video export failed")
        }
      })
      .build()
    current = transformer
    transformer.start(composition, out.absolutePath)
    main.postDelayed(tick, 400)
  }

  fun cancel() { current?.cancel(); current = null }

  /** Share a made video straight to one app (WhatsApp / Instagram / YouTube), or the chooser when pkg is empty or missing. */
  fun share(ctx: Context, fileUri: String, pkg: String, text: String) {
    val file = File(Uri.parse(fileUri).path!!)
    val content = FileProvider.getUriForFile(ctx, ctx.packageName + ".bhaktivideo", file)
    fun intent() = Intent(Intent.ACTION_SEND).apply {
      type = "video/mp4"
      putExtra(Intent.EXTRA_STREAM, content)
      if (text.isNotEmpty()) putExtra(Intent.EXTRA_TEXT, text)
      addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
    }
    if (pkg.isNotEmpty()) {
      try { ctx.startActivity(intent().setPackage(pkg)); return } catch (_: ActivityNotFoundException) {}
    }
    ctx.startActivity(Intent.createChooser(intent(), null).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION))
  }

  fun isInstalled(ctx: Context, pkg: String): Boolean =
    try { ctx.packageManager.getPackageInfo(pkg, 0); true } catch (_: Exception) { false }
}
