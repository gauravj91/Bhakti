package expo.modules.bhaktialarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.util.Calendar

class AlarmReceiver : BroadcastReceiver() {
  override fun onReceive(context: Context, intent: Intent) {
    when (intent.action) {
      ACTION_STOP -> { AlarmService.stop(context); return }
      ACTION_SNOOZE -> { AlarmService.snooze(context); return }
    }
    val id = intent.getStringExtra(AlarmScheduler.EXTRA_ALARM_ID) ?: return
    val snoozePayload = intent.getStringExtra(AlarmScheduler.EXTRA_PAYLOAD)

    val payload: JSONObject = if (snoozePayload != null) {
      JSONObject(snoozePayload)
    } else {
      val alarm = AlarmStore.get(context, id) ?: return
      val p = buildPayload(alarm)
      // Re-arm repeating alarms, disable one-shots
      val days = alarm.optJSONArray("days")
      if (days != null && days.length() > 0) AlarmScheduler.schedule(context, alarm)
      else { alarm.put("enabled", false); AlarmStore.upsert(context, alarm) }
      p
    }
    payload.put("firedAt", System.currentTimeMillis())
    AlarmStore.setRinging(context, payload)
    val svc = Intent(context, AlarmService::class.java).putExtra(AlarmScheduler.EXTRA_PAYLOAD, payload.toString())
    ContextCompat.startForegroundService(context, svc)
  }

  companion object {
    const val ACTION_STOP = "com.gauravj.bhaktialarm.STOP"
    const val ACTION_SNOOZE = "com.gauravj.bhaktialarm.SNOOZE"

    /** Picks today's track. Shuffle = deterministic per calendar day so it's "new each day". */
    fun buildPayload(alarm: JSONObject): JSONObject {
      val tracks = alarm.optJSONArray("tracks")
      var track: JSONObject? = null
      if (tracks != null && tracks.length() > 0) {
        val idx = if (alarm.optBoolean("shuffle", false)) {
          val c = Calendar.getInstance()
          val dayKey = c.get(Calendar.YEAR) * 400 + c.get(Calendar.DAY_OF_YEAR)
          Math.floorMod((dayKey * 2654435761L).toInt() xor alarm.optString("id").hashCode(), tracks.length())
        } else 0
        track = tracks.getJSONObject(idx)
      }
      return JSONObject().apply {
        put("alarmId", alarm.optString("id"))
        put("label", alarm.optString("label", ""))
        put("vibrate", alarm.optBoolean("vibrate", true))
        put("snoozeMinutes", alarm.optInt("snoozeMinutes", 5))
        put("trackId", track?.optString("id") ?: "")
        put("trackTitle", track?.optString("title") ?: "")
        put("deityId", track?.optString("deityId") ?: "")
        put("uri", track?.optString("uri") ?: "")
      }
    }
  }
}
