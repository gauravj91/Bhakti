package expo.modules.bhaktialarm

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder
import java.io.File
import kotlin.math.sin
import kotlin.random.Random

/**
 * "Bhakti Live Wallpaper": the chosen darshan image or background, with a flickering diya
 * at the bottom and marigold petals drifting down. Draws ~20 fps, and only while visible.
 */
class BhaktiLiveWallpaperService : WallpaperService() {
  companion object {
    private const val FILE_NAME = "live_wallpaper.img"
    fun imageFile(ctx: Context) = File(ctx.filesDir, FILE_NAME)

    /** Copy the picture to app storage, then open the system preview so the user can apply it. */
    fun prepareAndOpen(ctx: Context, fileUri: String) {
      val src = WallpaperSetter.toLocalFile(ctx, fileUri)
      src.copyTo(imageFile(ctx), overwrite = true)
      val comp = ComponentName(ctx, BhaktiLiveWallpaperService::class.java)
      val intent = Intent(android.app.WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
        .putExtra(android.app.WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT, comp)
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      try { ctx.startActivity(intent) }
      catch (_: Exception) {
        ctx.startActivity(Intent(android.app.WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
      }
    }
  }

  override fun onCreateEngine(): Engine = LiveEngine()

  private inner class LiveEngine : Engine() {
    private val handler = Handler(Looper.getMainLooper())
    private var visible = false
    private var w = 0
    private var h = 0
    private var bg: Bitmap? = null
    private var bgStamp = 0L
    private val start = SystemClock.uptimeMillis()
    private val petals = ArrayList<Petal>()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val draw = Runnable { frame() }

    private inner class Petal(var x: Float, var y: Float, val speed: Float, val sway: Float, val phase: Float, val size: Float, var rot: Float, val spin: Float, val color: Int)

    private fun newPetal(top: Boolean): Petal {
      val colors = intArrayOf(0xFFFF9933.toInt(), 0xFFFFB347.toInt(), 0xFFFFC107.toInt(), 0xFFE65100.toInt())
      return Petal(
        x = Random.nextFloat() * w,
        y = if (top) -Random.nextFloat() * h * 0.3f else Random.nextFloat() * h,
        speed = h * (0.025f + Random.nextFloat() * 0.03f),   // px per second
        sway = w * (0.01f + Random.nextFloat() * 0.025f),
        phase = Random.nextFloat() * 6.28f,
        size = w * (0.012f + Random.nextFloat() * 0.012f),
        rot = Random.nextFloat() * 360f,
        spin = -40f + Random.nextFloat() * 80f,
        color = colors[Random.nextInt(colors.size)],
      )
    }

    override fun onVisibilityChanged(v: Boolean) {
      visible = v
      if (v) { loadBgIfChanged(); frame() } else handler.removeCallbacks(draw)
    }

    override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
      super.onSurfaceChanged(holder, format, width, height)
      if (width != w || height != h) {
        w = width; h = height
        bg?.recycle(); bg = null; bgStamp = 0L
        petals.clear(); repeat(14) { petals.add(newPetal(false)) }
      }
      loadBgIfChanged(); frame()
    }

    override fun onSurfaceDestroyed(holder: SurfaceHolder) {
      super.onSurfaceDestroyed(holder)
      visible = false; handler.removeCallbacks(draw)
    }

    override fun onDestroy() {
      super.onDestroy()
      handler.removeCallbacks(draw); bg?.recycle(); bg = null
    }

    private fun loadBgIfChanged() {
      if (w <= 0 || h <= 0) return
      val f = imageFile(this@BhaktiLiveWallpaperService)
      val stamp = if (f.exists()) f.lastModified() else -1L
      if (bg != null && stamp == bgStamp) return
      bgStamp = stamp
      val old = bg
      bg = try { if (f.exists()) WallpaperSetter.compose(f, w, h) else null } catch (_: Throwable) { null }
      old?.recycle()
    }

    private var last = 0L
    private fun frame() {
      handler.removeCallbacks(draw)
      if (!visible || w <= 0) return
      val now = SystemClock.uptimeMillis()
      val dt = if (last == 0L) 0f else ((now - last).coerceAtMost(200L)) / 1000f
      last = now
      val t = (now - start) / 1000f
      val holder = surfaceHolder
      var c: Canvas? = null
      try {
        c = holder.lockCanvas()
        if (c != null) render(c, t, dt)
      } catch (_: Throwable) {
      } finally {
        if (c != null) try { holder.unlockCanvasAndPost(c) } catch (_: Throwable) {}
      }
      handler.postDelayed(draw, 50)
    }

    private fun render(c: Canvas, t: Float, dt: Float) {
      val b = bg
      if (b != null) c.drawBitmap(b, null, RectF(0f, 0f, w.toFloat(), h.toFloat()), paint) else c.drawColor(Color.rgb(58, 10, 0))
      drawPetals(c, dt)
      drawDiya(c, t)
    }

    private fun drawPetals(c: Canvas, dt: Float) {
      paint.shader = null; paint.style = Paint.Style.FILL
      for (i in petals.indices) {
        val p = petals[i]
        p.y += p.speed * dt
        p.rot += p.spin * dt
        if (p.y > h + p.size * 4) { petals[i] = newPetal(true); continue }
        val x = p.x + sin(p.y / h * 6f + p.phase) * p.sway
        paint.color = p.color; paint.alpha = 215
        c.save(); c.rotate(p.rot, x, p.y)
        c.drawOval(RectF(x - p.size, p.y - p.size * 0.55f, x + p.size, p.y + p.size * 0.55f), paint)
        c.restore()
      }
      paint.alpha = 255
    }

    private fun drawDiya(c: Canvas, t: Float) {
      val cx = w / 2f
      val baseY = h * 0.88f
      val bw = w * 0.20f
      val flick = 1f + 0.08f * sin(t * 9f) + 0.05f * sin(t * 23f + 1.3f) + 0.03f * sin(t * 37f)
      val sway = w * 0.006f * sin(t * 5.3f)

      // Glow
      val glowR = w * 0.22f * flick
      paint.style = Paint.Style.FILL
      paint.shader = RadialGradient(cx, baseY - bw * 0.35f, glowR, intArrayOf(Color.argb(150, 255, 190, 80), Color.argb(0, 255, 140, 0)), null, Shader.TileMode.CLAMP)
      c.drawCircle(cx, baseY - bw * 0.35f, glowR, paint)

      // Bowl (clay diya)
      val bowl = Path().apply {
        moveTo(cx - bw / 2, baseY - bw * 0.12f)
        quadTo(cx, baseY + bw * 0.38f, cx + bw / 2, baseY - bw * 0.12f)
        quadTo(cx + bw * 0.62f, baseY - bw * 0.2f, cx + bw * 0.42f, baseY - bw * 0.16f)
        lineTo(cx - bw * 0.42f, baseY - bw * 0.16f)
        close()
      }
      paint.shader = LinearGradient(cx, baseY - bw * 0.2f, cx, baseY + bw * 0.3f, Color.rgb(196, 98, 30), Color.rgb(110, 40, 8), Shader.TileMode.CLAMP)
      c.drawPath(bowl, paint)
      paint.shader = null; paint.color = Color.rgb(230, 170, 60)
      c.drawOval(RectF(cx - bw * 0.42f, baseY - bw * 0.2f, cx + bw * 0.42f, baseY - bw * 0.1f), paint)

      // Flame
      val fh = bw * 0.55f * flick
      val fw = bw * 0.13f
      val fy = baseY - bw * 0.17f
      val flame = Path().apply {
        moveTo(cx, fy)
        cubicTo(cx - fw * 1.3f, fy - fh * 0.25f, cx - fw * 0.5f + sway, fy - fh * 0.7f, cx + sway * 1.6f, fy - fh)
        cubicTo(cx + fw * 0.5f + sway, fy - fh * 0.7f, cx + fw * 1.3f, fy - fh * 0.25f, cx, fy)
        close()
      }
      paint.shader = LinearGradient(cx, fy, cx, fy - fh, intArrayOf(Color.rgb(255, 250, 210), Color.rgb(255, 200, 40), Color.rgb(255, 110, 0)), floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP)
      c.drawPath(flame, paint)
      paint.shader = null
    }
  }
}

