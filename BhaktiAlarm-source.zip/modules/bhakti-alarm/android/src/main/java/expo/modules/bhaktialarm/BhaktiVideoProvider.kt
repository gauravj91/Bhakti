package expo.modules.bhaktialarm

import androidx.core.content.FileProvider

/** Own subclass so it never clashes with other libraries' FileProvider entries in the merged manifest. */
class BhaktiVideoProvider : FileProvider()
