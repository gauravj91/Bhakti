package expo.modules.bhaktialarm

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.app.NotificationManagerCompat
import expo.modules.kotlin.Promise
import expo.modules.kotlin.functions.Queues
import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition
import org.json.JSONArray
import org.json.JSONObject
import java.lang.ref.WeakReference

@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
class BhaktiAlarmModule : Module() {
  private val ctx: Context
    get() = appContext.reactContext ?: throw IllegalStateException("No context")

  override fun definition() = ModuleDefinition {
    Name("BhaktiAlarm")
    Events("onRinging", "onVideoProgress")

    OnCreate { instance = WeakReference(this@BhaktiAlarmModule) }

    /** Save (create or update) an alarm given as JSON and (re)schedule it. Returns next trigger ms. */
    Function("saveAlarm") { json: String ->
      val alarm = JSONObject(json)
      AlarmStore.upsert(ctx, alarm)
      AlarmScheduler.schedule(ctx, alarm)
      if (!alarm.optBoolean("enabled", true)) { AlarmScheduler.cancel(ctx, alarm.optString("id")); AlarmStore.upsert(ctx, alarm) }
      AlarmStore.get(ctx, alarm.optString("id"))?.optLong("nextTrigger", 0L)?.toDouble() ?: 0.0
    }

    Function("deleteAlarm") { id: String ->
      AlarmScheduler.cancel(ctx, id); AlarmScheduler.cancel(ctx, "snooze_$id"); AlarmStore.remove(ctx, id)
    }

    Function("getAlarms") {
      val arr = JSONArray(); AlarmStore.all(ctx).forEach { arr.put(it) }; arr.toString()
    }

    Function("getRinging") { AlarmStore.getRinging(ctx)?.toString() }

    Function("stopRinging") {
      AlarmService.stop(ctx)
      WakeListener.activity?.let { WakeListener.setShowOnLock(it, false) }
    }

    Function("snooze") { minutes: Int ->
      AlarmService.snooze(ctx, minutes)
      WakeListener.activity?.let { WakeListener.setShowOnLock(it, false) }
    }

    /** Fire a test alarm in N seconds with the given track. */
    Function("testAlarm") { seconds: Int, json: String ->
      val alarm = JSONObject(json)
      val payload = AlarmReceiver.buildPayload(alarm)
      AlarmScheduler.scheduleAt(ctx, "test_alarm", System.currentTimeMillis() + seconds * 1000L, payload)
    }

    Function("canScheduleExact") { AlarmScheduler.canScheduleExact(ctx) }

    Function("canUseFullScreen") {
      if (Build.VERSION.SDK_INT >= 34) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
        nm.canUseFullScreenIntent()
      } else true
    }

    Function("notificationsEnabled") { NotificationManagerCompat.from(ctx).areNotificationsEnabled() }

    Function("openExactAlarmSettings") {
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        ctx.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + ctx.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
      }
    }

    Function("openFullScreenSettings") {
      if (Build.VERSION.SDK_INT >= 34) {
        ctx.startActivity(Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:" + ctx.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
      } else openAppSettings()
    }

    Function("openAppSettings") { openAppSettings() }

    Function("rescheduleAll") { AlarmScheduler.rescheduleAll(ctx) }

    // ---- Video maker ----
    AsyncFunction("makeVideo") { json: String, promise: Promise ->
      try {
        VideoMaker.make(ctx, json,
          onProgress = { p -> try { sendEvent("onVideoProgress", mapOf("progress" to p)) } catch (_: Exception) {} },
          onDone = { uri -> promise.resolve(uri) },
          onError = { msg -> promise.reject("E_VIDEO", msg, null) })
      } catch (e: Exception) { promise.reject("E_VIDEO", e.message ?: "Video export failed", e) }
    }.runOnQueue(Queues.MAIN)

    Function("cancelVideo") { VideoMaker.cancel() }

    Function("shareVideo") { uri: String, pkg: String, text: String -> VideoMaker.share(ctx, uri, pkg, text) }

    Function("isInstalled") { pkg: String -> VideoMaker.isInstalled(ctx, pkg) }
  }

  private fun openAppSettings() {
    ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
  }

  companion object {
    private var instance: WeakReference<BhaktiAlarmModule>? = null
    fun emitRinging() {
      try { instance?.get()?.sendEvent("onRinging", mapOf("at" to System.currentTimeMillis())) } catch (_: Exception) {}
    }
  }
}
