package expo.modules.bhaktialarm

import android.app.WallpaperManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.net.Uri
import android.os.Build
import java.io.File

/**
 * Sets a local image file as the phone wallpaper.
 * The 4:5 artwork is fitted whole (never cropping the deity) over a soft blurred fill of itself,
 * sized to the screen and downsampled on decode so memory stays small.
 */
object WallpaperSetter {
  /** target: "home" | "lock" | "both" */
  fun set(ctx: Context, fileUri: String, target: String) {
    val path = Uri.parse(fileUri).path ?: throw IllegalArgumentException("Bad file")
    val file = File(path)
    if (!file.exists()) throw IllegalArgumentException("File not found")

    val dm = ctx.resources.displayMetrics
    val w = minOf(maxOf(dm.widthPixels, 720), 1440)
    val h = minOf(maxOf(dm.heightPixels, 1280), 3200)
    val out = compose(file, w, h)

    val wm = WallpaperManager.getInstance(ctx)
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
      val which = when (target) {
        "home" -> WallpaperManager.FLAG_SYSTEM
        "lock" -> WallpaperManager.FLAG_LOCK
        else -> WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK
      }
      wm.setBitmap(out, null, true, which)
    } else {
      wm.setBitmap(out)
    }
    out.recycle()
  }

  /** Fit the whole image over a soft blurred fill of itself, at w x h. Decodes downsampled. */
  fun compose(file: File, w: Int, h: Int): Bitmap {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(file.absolutePath, bounds)
    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) throw IllegalArgumentException("Not an image")
    var sample = 1
    while (bounds.outWidth / (sample * 2) >= w) sample *= 2
    val src = BitmapFactory.decodeFile(file.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample })
      ?: throw IllegalArgumentException("Could not read image")

    val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    val c = Canvas(out)
    val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)

    // Background: tiny copy scaled up = cheap blur, then darkened.
    val tiny = Bitmap.createScaledBitmap(src, maxOf(src.width / 24, 4), maxOf(src.height / 24, 4), true)
    val bgScale = maxOf(w.toFloat() / tiny.width, h.toFloat() / tiny.height)
    val bw = tiny.width * bgScale; val bh = tiny.height * bgScale
    c.drawBitmap(tiny, null, RectF((w - bw) / 2f, (h - bh) / 2f, (w + bw) / 2f, (h + bh) / 2f), paint)
    c.drawColor(Color.argb(90, 0, 0, 0))
    tiny.recycle()

    // Foreground: whole image, fit, centred.
    val fgScale = minOf(w.toFloat() / src.width, h.toFloat() / src.height)
    val fw = src.width * fgScale; val fh = src.height * fgScale
    c.drawBitmap(src, Rect(0, 0, src.width, src.height), RectF((w - fw) / 2f, (h - fh) / 2f, (w + fw) / 2f, (h + fh) / 2f), paint)
    src.recycle()
    return out
  }
}
