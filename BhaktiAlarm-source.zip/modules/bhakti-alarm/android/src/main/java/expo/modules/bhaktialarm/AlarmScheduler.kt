package expo.modules.bhaktialarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import org.json.JSONObject
import java.util.Calendar

object AlarmScheduler {
  const val EXTRA_ALARM_ID = "bhakti_alarm_id"
  const val EXTRA_PAYLOAD = "bhakti_payload"

  private fun requestCode(id: String) = id.hashCode()

  private fun firePendingIntent(ctx: Context, id: String, payload: JSONObject?): PendingIntent {
    val i = Intent(ctx, AlarmReceiver::class.java).apply {
      action = "com.gauravj.bhaktialarm.FIRE"
      putExtra(EXTRA_ALARM_ID, id)
      if (payload != null) putExtra(EXTRA_PAYLOAD, payload.toString())
    }
    return PendingIntent.getBroadcast(
      ctx, requestCode(id), i,
      PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
  }

  private fun showIntent(ctx: Context): PendingIntent {
    val launch = ctx.packageManager.getLaunchIntentForPackage(ctx.packageName)
      ?: Intent()
    return PendingIntent.getActivity(
      ctx, 9001, launch, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
  }

  /** days: 0=Sun..6=Sat (JS convention). Empty = one-shot. */
  fun nextTrigger(alarm: JSONObject, now: Long = System.currentTimeMillis()): Long {
    val hour = alarm.optInt("hour"); val minute = alarm.optInt("minute")
    val daysArr = alarm.optJSONArray("days")
    val days = mutableSetOf<Int>()
    if (daysArr != null) for (k in 0 until daysArr.length()) days.add(daysArr.getInt(k))
    val cal = Calendar.getInstance().apply {
      timeInMillis = now
      set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, minute)
      set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }
    for (i in 0..7) {
      val c = cal.clone() as Calendar
      c.add(Calendar.DAY_OF_YEAR, i)
      if (c.timeInMillis <= now) continue
      val dow = c.get(Calendar.DAY_OF_WEEK) - 1
      if (days.isEmpty() || days.contains(dow)) return c.timeInMillis
    }
    cal.add(Calendar.DAY_OF_YEAR, 1); return cal.timeInMillis
  }

  fun canScheduleExact(ctx: Context): Boolean {
    val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) am.canScheduleExactAlarms() else true
  }

  fun scheduleAt(ctx: Context, id: String, triggerAt: Long, payload: JSONObject? = null) {
    val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    val pi = firePendingIntent(ctx, id, payload)
    try {
      am.setAlarmClock(AlarmManager.AlarmClockInfo(triggerAt, showIntent(ctx)), pi)
    } catch (e: SecurityException) {
      am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
    }
  }

  fun cancel(ctx: Context, id: String) {
    val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    am.cancel(firePendingIntent(ctx, id, null))
  }

  fun schedule(ctx: Context, alarm: JSONObject) {
    val id = alarm.optString("id")
    cancel(ctx, id)
    if (!alarm.optBoolean("enabled", true)) return
    val t = nextTrigger(alarm)
    alarm.put("nextTrigger", t)
    AlarmStore.upsert(ctx, alarm)
    scheduleAt(ctx, id, t)
  }

  fun rescheduleAll(ctx: Context) {
    AlarmStore.all(ctx).forEach { if (it.optBoolean("enabled", true)) schedule(ctx, it) }
  }
}
