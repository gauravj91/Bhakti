package expo.modules.bhaktialarm

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import expo.modules.core.interfaces.Package
import expo.modules.core.interfaces.ReactActivityLifecycleListener

/** Lets the wake screen show over the lock screen and turn the display on, only while ringing. */
class BhaktiAlarmPackage : Package {
  override fun createReactActivityLifecycleListeners(activityContext: Context?): List<ReactActivityLifecycleListener> =
    listOf(WakeListener)
}

object WakeListener : ReactActivityLifecycleListener {
  @Volatile var activity: Activity? = null

  override fun onCreate(activity: Activity, savedInstanceState: Bundle?) {
    this.activity = activity
    apply(activity, activity.intent)
  }

  override fun onResume(activity: Activity) {
    this.activity = activity
    if (AlarmStore.getRinging(activity) != null) setShowOnLock(activity, true)
  }

  override fun onNewIntent(intent: Intent): Boolean {
    activity?.let { apply(it, intent) }
    BhaktiAlarmModule.emitRinging()
    return false
  }

  private fun apply(activity: Activity, intent: Intent?) {
    val ringing = intent?.hasExtra(AlarmScheduler.EXTRA_ALARM_ID) == true || AlarmStore.getRinging(activity) != null
    if (ringing) setShowOnLock(activity, true)
  }

  fun setShowOnLock(activity: Activity, on: Boolean) {
    activity.runOnUiThread {
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
        activity.setShowWhenLocked(on); activity.setTurnScreenOn(on)
      } else {
        @Suppress("DEPRECATION")
        val f = WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
        if (on) activity.window.addFlags(f) else activity.window.clearFlags(f)
      }
      if (on) activity.window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
      else activity.window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }
  }
}
