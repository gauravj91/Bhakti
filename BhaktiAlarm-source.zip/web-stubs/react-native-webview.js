const React = require('react');
// Web preview only: render an iframe in place of the native WebView.
function WebView({ source, style }) {
  return React.createElement('iframe', { src: source && source.uri, style: Object.assign({ border: 0 }, style), allow: 'autoplay; fullscreen' });
}
module.exports = { WebView, default: WebView };
