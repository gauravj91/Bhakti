// Web preview only.
const Share = { open: async () => ({}), shareSingle: async () => ({}), isPackageInstalled: async () => ({ isInstalled: false }) };
export const Social = { Whatsapp: 'whatsapp' };
export default Share;
